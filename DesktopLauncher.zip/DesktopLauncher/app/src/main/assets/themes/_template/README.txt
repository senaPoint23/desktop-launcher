TEMPLATE TEMA SISTEM
====================
Cara membuat tema sistem baru tanpa menyentuh kode:

1. Salin folder "_template" ini ke app/src/main/assets/themes/<idbaru>/
   (idbaru: huruf kecil, tanpa spasi, tidak berawalan "_", mis. "pelangi").
2. Ubah theme.json di folder baru (isi dan artinya ada di bawah).
3. Opsional: tambahkan gambar (lihat di bawah).
4. Build ulang. Tema muncul otomatis di Pengaturan > Personalisasi > Tema sistem.

Folder berawalan "_" (seperti ini) tidak dimuat. Berkas theme.json yang rusak diabaikan.
Memakai id yang sama dengan tema bawaan (reef, stage, blocks) menggantikan tema bawaan itu.

ISI theme.json
--------------
label     Nama yang tampil di daftar tema.
chrome    Bentuk jendela dan taskbar:
            SOFT   sudut membulat, taskbar melayang bulat
            ROYAL  sudut membulat, bingkai tebal, garis emas di bar judul
            PIXEL  sudut kotak, bingkai tebal, strip rumput di bar judul dan taskbar
scene     Wallpaper bawaan bila tidak ada gambar wallpaper. Pilih salah satu:
            Digambar khusus tema: REEF (laut), SKY (langit), VOXEL (blok)
            Wallpaper live biasa: BLOOM, AURORA, BINTANG, GELOMBANG, HUJAN, SALJU,
                                  GALAKSI, KUNANG, SENJA, SYNTHWAVE
frame     Warna bingkai jendela dan taskbar. Bila dihapus, memakai warna accent.
mark      Dua warna untuk layar pemuatan saat tema diterapkan.
palette   Warna antarmuka:
            wallpaper  dua warna (dipakai sebagai cadangan)
            panel      Start Menu, panel, bar judul jendela
            bar        taskbar
            window     isi jendela
            text       teks utama
            sub        teks sekunder
            accent     warna aksen (tombol, pilihan aktif)
            line       garis tipis pemisah

Format warna: "#RRGGBB" atau "#AARRGGBB" (AA = transparansi, FF = tidak transparan).
Untuk tema terang, pakai text gelap dan window terang; untuk tema gelap sebaliknya.

GAMBAR OPSIONAL (taruh di folder tema yang sama)
------------------------------------------------
  wallpaper.jpg      wallpaper (juga .png / .webp), dipotong agar memenuhi layar
  taskbar.png        latar taskbar
  titlebar.png       latar bar judul jendela (tinggi 36dp)
  icons/<nama>.png   ikon pengganti, persegi, disarankan 256x256 transparan

Nama ikon:
  pc files browser settings terminal apps windows widgets weather
  search bell signal volume battery chevron
  bt brush account time shield update doc image
Berkas yang tidak ada diganti tampilan bawaan, jadi boleh mengganti satu per satu.
