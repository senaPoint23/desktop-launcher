Aset tema sistem "Dunia Blok" (id: blocks). Semua berkas OPSIONAL: yang tidak ada diganti tampilan bawaan.

  wallpaper.jpg      gambar wallpaper (juga .png / .webp); dipotong otomatis agar memenuhi layar
  taskbar.png        gambar latar taskbar (ditarik selebar taskbar)
  titlebar.png       gambar latar bar judul jendela (tinggi 36dp)
  icons/<nama>.png   ikon pengganti, persegi, disarankan 256x256 transparan

Nama ikon yang dikenali:
  pc files browser settings terminal apps windows widgets weather
  search bell signal volume battery chevron
  bt brush account time shield update doc image

Contoh: icons/pc.png menggantikan ikon "PC Ini" di desktop dan "Sistem" di Pengaturan.
Setelah berkas ditaruh di folder ini, build ulang aplikasi lalu pilih tema di
Pengaturan > Personalisasi > Tema sistem.
