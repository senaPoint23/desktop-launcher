package com.example.desktoplauncher;

import android.view.Surface;

// Dijalankan oleh Shizuku dengan hak akses shell (UserService).
interface IPrivilegedService {
    // Wajib untuk Shizuku UserService.
    void destroy() = 16777114;

    int createDisplay(in Surface surface, int width, int height, int dpi, String name) = 1;
    void setDisplaySurface(int displayId, in Surface surface) = 2;
    void releaseDisplay(int displayId) = 3;
    String startActivity(int displayId, String component) = 4;
    oneway void injectTouch(int displayId, int action, int count, in int[] ids, in float[] xs, in float[] ys, long downTime, long eventTime) = 5;
    oneway void injectKey(int displayId, int keyCode, boolean down) = 6;
    String lastError() = 7;
}
