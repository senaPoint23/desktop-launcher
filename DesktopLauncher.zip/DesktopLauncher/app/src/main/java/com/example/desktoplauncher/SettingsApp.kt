package com.example.desktoplauncher

import android.content.Intent
import android.os.Build
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.launch
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val pages = listOf(
    Triple("sys", "Sistem", "pc"),
    Triple("bt", "Bluetooth & perangkat", "bt"),
    Triple("per", "Personalisasi", "brush"),
    Triple("app", "Aplikasi", "apps"),
    Triple("acc", "Akun", "account"),
    Triple("time", "Waktu & bahasa", "time"),
    Triple("priv", "Privasi & keamanan", "shield"),
    Triple("upd", "Pembaruan PC", "update"),
)

@Composable
fun SettingsApp(state: DesktopState) {
    val pal = LocalPalette.current
    var page by remember { mutableStateOf("sys") }
    var sub by remember { mutableStateOf<String?>(null) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 460.dp
        Row(Modifier.fillMaxSize()) {
            // Sidebar: hanya ikon jika window sempit.
            Column(
                Modifier.width(if (compact) 52.dp else 180.dp).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                pages.forEach { (id, label, icon) ->
                    val sel = page == id
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                            .background(if (sel) pal.text.copy(alpha = .08f) else Color.Transparent)
                            .clickable { page = id; sub = null }
                            .padding(horizontal = 6.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.width(3.dp).height(16.dp).clip(CircleShape).background(if (sel) pal.accent else Color.Transparent))
                        Spacer(Modifier.width(6.dp))
                        Glyph(icon, 20.dp, pal.text)
                        if (!compact) Text(label, color = pal.text, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            }
            Column(
                Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(start = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                val title = pages.first { it.first == page }.second
                Row(Modifier.padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                        color = if (sub != null) pal.sub else pal.text,
                        modifier = Modifier.clickable(enabled = sub != null) { sub = null },
                    )
                    if (sub != null) {
                        Text("  ›  ", color = pal.sub, fontSize = 22.sp)
                        Text("Tampilan", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = pal.text)
                    }
                }
                when (page) {
                    "sys" -> if (sub == "display") DisplayPage(state) else SystemList(state) { sub = "display" }
                    "bt" -> {
                        LinkCard("bt", "Bluetooth", "Kelola perangkat Bluetooth", Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        LinkCard("signal", "Internet", "Wi-Fi dan data seluler", internetIntent())
                    }
                    "per" -> PersonalPage(state)
                    "app" -> {
                        ShizukuSettings(state)
                        FloatSettings(state)
                        LinkCard("apps", "Launcher bawaan", "Pilih Desktop sebagai layar utama", Intent(Settings.ACTION_HOME_SETTINGS))
                        LinkCard("apps", "Aplikasi terpasang", "Kelola semua aplikasi", Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS))
                        LinkCard("apps", "Aplikasi default", "Browser, telepon, dan lainnya", Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                    }
                    "acc" -> {
                        SCard("account", Build.MODEL, "Akun lokal")
                        LinkCard("account", "Akun & sinkronisasi", "Akun Google dan lainnya", Intent(Settings.ACTION_SYNC_SETTINGS))
                    }
                    "time" -> {
                        LinkCard("time", "Tanggal & waktu", "Zona waktu dan format jam", Intent(Settings.ACTION_DATE_SETTINGS))
                        LinkCard("time", "Bahasa", "Bahasa tampilan perangkat", Intent(Settings.ACTION_LOCALE_SETTINGS))
                    }
                    "priv" -> {
                        LinkCard("bell", "Akses notifikasi", "Izinkan Desktop membaca notifikasi", Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        LinkCard("shield", "Keamanan", "Kunci layar dan perlindungan", Intent(Settings.ACTION_SECURITY_SETTINGS))
                        LinkCard("shield", "Lokasi", "Izin dan layanan lokasi", Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }
                    else -> {
                        SCard("update", "Desktop Launcher", "Versi 0.1 · Developer: Riyo")
                        SCard("update", "Tampilkan sambutan", "Lihat lagi layar selamat datang", onClick = { state.replayWelcome() })
                        LinkCard("update", "Tentang ponsel & pembaruan", "Periksa pembaruan sistem Android", Intent(Settings.ACTION_DEVICE_INFO_SETTINGS))
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemList(state: DesktopState, onDisplay: () -> Unit) {
    val ctx = LocalContext.current
    SCard("o_scale", "Tampilan", "Skala, orientasi, navigasi, bilah status", onClick = onDisplay) { Chev() }
    LinkCard("volume", "Suara", "Volume dan nada", Intent(Settings.ACTION_SOUND_SETTINGS))
    LinkCard("bell", "Notifikasi", "Akses notifikasi untuk panel", Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    LinkCard("battery", "Daya & baterai", "Penghemat baterai", Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
    LinkCard("pc", "Penyimpanan", "Ruang penyimpanan perangkat", Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
    SCard("pc", "Tentang", "Spesifikasi perangkat", onClick = { state.open("pc", "PC Ini", "🖥️") }) { Chev() }
}

@Composable
private fun ThemeDesigner(state: DesktopState) {
    val pal = LocalPalette.current
    var prompt by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    SectionTitle("AI Layout Designer")
    Text(
        "Tulis tema yang kamu inginkan. Versi ini memakai template lokal yang aman; tema akan mengubah palet desktop dan wallpaper mengikuti tema.",
        color = pal.sub, fontSize = 12.sp,
    )
    OutlinedTextField(
        value = prompt,
        onValueChange = { prompt = it },
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Contoh: SpongeBob, Minecraft, cyberpunk, Furina") },
        singleLine = false,
        minLines = 2,
        maxLines = 3,
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("SpongeBob", "Minecraft", "Furina").forEach { preset ->
            Pill(preset, prompt.equals(preset, ignoreCase = true)) { prompt = preset }
        }
    }
    SCard("brush", "Buat & terapkan tema", "Mengubah tampilan desktop tanpa menghapus pengaturan lain", onClick = {
        if (!state.themeLoading && prompt.isNotBlank()) {
            val chosen = resolveThemePrompt(prompt)
            scope.launch {
                state.closeOverlays()
                state.themeLoading = true
                state.themeLoadingProgress = 0.12f
                state.themeLoadingLabel = "Menganalisis permintaan"
                kotlinx.coroutines.delay(350)
                state.themeLoadingProgress = 0.38f
                state.themeLoadingLabel = "Menyiapkan palet dan layout"
                kotlinx.coroutines.delay(400)
                state.themeLoadingProgress = 0.68f
                state.themeLoadingLabel = "Menerapkan wallpaper dan komponen"
                state.applyThemeProfile(chosen, prompt.trim().replaceFirstChar { it.uppercase() })
                kotlinx.coroutines.delay(350)
                state.themeLoadingProgress = 1f
                state.themeLoadingLabel = "Tema siap"
                kotlinx.coroutines.delay(350)
                state.themeLoading = false
            }
        }
    }) { Glyph("brush", 18.dp, pal.accent) }
    Text("Tema aktif: ${state.themeProfileName}", color = pal.sub, fontSize = 11.sp)
}

private fun resolveThemePrompt(raw: String): ThemeMode {
    val q = raw.lowercase()
    return when {
        "sponge" in q || "bikini bottom" in q || "bawah laut" in q -> ThemeMode.SPONGEBOB
        "minecraft" in q || "blok" in q || "creeper" in q -> ThemeMode.MINECRAFT
        "cyberpunk" in q || "neon" in q || "futuristik" in q -> ThemeMode.CYBERPUNK
        "furina" in q || "genshin" in q -> ThemeMode.FURINA
        "sakura" in q || "pink" in q -> ThemeMode.SAKURA
        "hutan" in q || "forest" in q || "alam" in q -> ThemeMode.FOREST
        "samudra" in q || "laut" in q || "ocean" in q -> ThemeMode.OCEAN
        "senja" in q || "sunset" in q || "jingga" in q -> ThemeMode.SUNSET
        "gelap" in q || "dark" in q || "amoled" in q -> ThemeMode.DARK
        "terang" in q || "light" in q || "minimal" in q -> ThemeMode.LIGHT
        else -> ThemeMode.OCEAN
    }
}

@Composable
private fun PersonalPage(state: DesktopState) {
    ThemeDesigner(state)
    SectionTitle("Tema")
    ThemeMode.values().toList().chunked(4).forEach { row ->
        Row(Modifier.padding(bottom = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { m -> Pill(m.label, state.theme == m) { state.changeTheme(m) } }
        }
    }
    SectionTitle("Wallpaper")
    WallpaperStyle.values().filter { it != WallpaperStyle.SAYA }.chunked(3).forEach { row ->
        Row(Modifier.padding(bottom = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { w -> Pill(w.label, state.wallpaper == w) { state.chooseWallpaper(w) } }
        }
    }
    SCard("update", "Animasi wallpaper", "Jeda otomatis saat window layar penuh", onClick = { state.updateWallAnim(!state.wallAnim) }) {
        SwitchView(state.wallAnim) { state.updateWallAnim(it) }
    }
    CustomWallpapers(state)
    SectionTitle("Layar jeda")
    val idleOpts = listOf("Mati" to 0, "1 menit" to 60, "90 detik" to 90, "2 menit" to 120, "5 menit" to 300)
    val idleLabel = idleOpts.firstOrNull { it.second == state.idleSec }?.first ?: "${state.idleSec} detik"
    ChoiceCard(
        "o_lock", "Kunci layar otomatis", "Tampilkan jam di atas wallpaper saat tidak disentuh",
        idleLabel, idleOpts.map { it.first },
    ) { v -> idleOpts.firstOrNull { it.first == v }?.let { state.updateIdle(it.second) } }
    SectionTitle("Desktop")
    SCard("widgets", "Widget jam", "Tampilkan jam besar di desktop", onClick = { state.setWidget(!state.widgetOn) }) {
        SwitchView(state.widgetOn) { state.setWidget(it) }
    }
}

/** Halaman Sistem > Tampilan. */
@Composable
private fun DisplayPage(state: DesktopState) {
    val ctx = LocalContext.current
    val act = remember { ctx.findActivity() }
    val apply = { act?.let { DisplayControl.apply(it, state) }; Unit }

    SectionTitle("Skala & tata letak")
    ScaleCard(state)
    val orientLabel = when (state.orient) { "portrait" -> "Potret"; "auto" -> "Otomatis"; else -> "Lanskap" }
    ChoiceCard("o_rotate", "Orientasi tampilan", null, orientLabel, listOf("Lanskap", "Potret", "Otomatis")) { v ->
        state.updateOrient(when (v) { "Potret" -> "portrait"; "Otomatis" -> "auto"; else -> "landscape" })
        apply()
    }
    SCard("o_lock", "Kunci rotasi", onClick = { state.updateRotLock(!state.rotLock); apply() }) {
        SwitchView(state.rotLock) { state.updateRotLock(it); apply() }
    }
    SectionTitle("Navigasi")
    SCard("o_nav", "Sembunyikan navigasi perangkat", "Alihkan visibilitas navigasi bawah/lunak", onClick = { state.updateHideNav(!state.hideNav); apply() }) {
        SwitchView(state.hideNav) { state.updateHideNav(it); apply() }
    }
    ChoiceCard(
        "o_status", "Bilah Status", "Konfigurasi cara Bilah Status ditampilkan di layar",
        if (state.hideStatus) "Tersembunyi" else "Tampil", listOf("Tampil", "Tersembunyi"),
    ) { v -> state.updateHideStatus(v == "Tersembunyi"); apply() }
}

@Composable
private fun ScaleCard(state: DesktopState) {
    val pal = LocalPalette.current
    val presets = listOf(40, 50, 60, 75, 90, 100, 110, 125, 150)
    val pct = (state.uiScale * 100).roundToInt()
    var open by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf(state.uiScale) }
    Column {
        SCard("o_scale", "Skala", "Ubah ukuran teks, antarmuka, dan item lainnya", onClick = { open = !open }) {
            ValueChip(if (pct in presets) "$pct%" else "Kustom", open)
        }
        AnimatedVisibility(visible = open) {
            Column(Modifier.padding(start = 12.dp, top = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.forEach { p -> Pill("$p%", p == pct) { state.setScale(p / 100f); pending = p / 100f } }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Kustom", color = pal.sub, fontSize = 12.sp)
                    Slider(
                        value = pending,
                        onValueChange = { pending = it },
                        onValueChangeFinished = { state.setScale((pending * 20f).roundToInt() / 20f) },
                        valueRange = 0.4f..1.6f,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                        colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.line),
                    )
                    Text("${(pending * 100).roundToInt()}%", color = pal.text, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ChoiceCard(
    icon: String, title: String, subtitle: String?, value: String,
    options: List<String>, onSelect: (String) -> Unit,
) {
    val pal = LocalPalette.current
    var open by remember { mutableStateOf(false) }
    Column {
        SCard(icon, title, subtitle, onClick = { open = !open }) { ValueChip(value, open) }
        AnimatedVisibility(visible = open) {
            Column(Modifier.padding(start = 12.dp, top = 4.dp)) {
                options.forEach { o ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                            .clickable { onSelect(o); open = false }.padding(horizontal = 10.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(10.dp).clip(CircleShape)
                                .background(if (o == value) pal.accent else Color.Transparent)
                                .border(1.dp, if (o == value) pal.accent else pal.sub, CircleShape)
                        )
                        Text(o, color = pal.text, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SCard(
    icon: String, title: String, subtitle: String? = null,
    onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {},
) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(8.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(pal.text.copy(alpha = .05f)).border(1.dp, pal.line, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Glyph(icon, 22.dp, pal.text)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, color = pal.text, fontSize = 14.sp)
            if (subtitle != null) Text(subtitle, color = pal.sub, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
private fun LinkCard(icon: String, title: String, subtitle: String, intent: Intent) {
    val ctx = LocalContext.current
    SCard(icon, title, subtitle, onClick = { ctx.launch(intent) }) { Chev() }
}

@Composable
private fun SectionTitle(text: String) {
    val pal = LocalPalette.current
    Text(text, color = pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
}

@Composable
private fun Chev() {
    val pal = LocalPalette.current
    Box(Modifier.graphicsLayer { rotationZ = 90f }) { Glyph("chevron", 14.dp, pal.sub) }
}

@Composable
private fun ValueChip(text: String, open: Boolean) {
    val pal = LocalPalette.current
    Row(
        Modifier.clip(RoundedCornerShape(6.dp)).background(pal.text.copy(alpha = .08f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = pal.text, fontSize = 13.sp)
        Box(Modifier.padding(start = 8.dp).graphicsLayer { rotationZ = if (open) 0f else 180f }) {
            Glyph("chevron", 12.dp, pal.sub)
        }
    }
}

@Composable
private fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.clip(shape)
            .background(if (selected) pal.accent.copy(alpha = .15f) else Color.Transparent)
            .border(1.dp, if (selected) pal.accent else pal.line, shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    ) { Text(text, color = if (selected) pal.accent else pal.text, fontSize = 13.sp) }
}

@Composable
private fun SwitchView(checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPalette.current
    val knob by animateDpAsState(if (checked) 24.dp else 4.dp, label = "knob")
    Box(
        Modifier.size(44.dp, 22.dp).clip(CircleShape)
            .background(if (checked) pal.accent else Color.Transparent)
            .border(1.dp, if (checked) pal.accent else pal.sub, CircleShape)
            .clickable { onChange(!checked) },
    ) {
        Box(
            Modifier.offset(x = knob).align(Alignment.CenterStart).size(if (checked) 14.dp else 12.dp)
                .clip(CircleShape).background(if (checked) Color.Black else pal.sub)
        )
    }
}

/** Wallpaper milik pengguna: tambah dari penyimpanan (video, GIF/WebP animasi, gambar). */
@Composable
private fun CustomWallpapers(state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(WallpaperFiles.list(ctx)) }
    var msg by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            msg = "Menyalin wallpaper…"
            scope.launch {
                val n = WallpaperFiles.importFrom(ctx, uri)
                if (n != null) {
                    files = WallpaperFiles.list(ctx)
                    state.chooseCustom(n)
                    msg = null
                } else msg = "Gagal menambahkan wallpaper"
            }
        }
    }
    SectionTitle("Wallpaper saya")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AddWallCard { picker.launch(arrayOf("video/*", "image/*")) }
        files.forEach { f ->
            WallThumb(
                f = f,
                selected = state.wallpaper == WallpaperStyle.SAYA && state.customWall == f.name,
                onPick = { state.chooseCustom(f.name) },
                onDelete = {
                    WallpaperFiles.delete(ctx, f)
                    files = WallpaperFiles.list(ctx)
                    if (state.wallpaper == WallpaperStyle.SAYA && state.customWall == f.name) {
                        state.chooseWallpaper(WallpaperStyle.BLOOM)
                    }
                },
            )
        }
    }
    Text(
        msg ?: "Mendukung video (MP4, WebM), GIF atau WebP animasi, dan gambar biasa. Video diputar tanpa suara.",
        color = pal.sub, fontSize = 12.sp,
    )
}

@Composable
private fun AddWallCard(onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier.size(112.dp, 64.dp).clip(shape).border(1.dp, pal.sub, shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("＋ Tambah", color = pal.text, fontSize = 13.sp) }
}

@Composable
private fun WallThumb(f: java.io.File, selected: Boolean, onPick: () -> Unit, onDelete: () -> Unit) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, f.absolutePath) { value = WallpaperFiles.thumbnail(ctx, f) }
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier.size(112.dp, 64.dp).clip(shape).background(pal.text.copy(alpha = .08f))
            .border(2.dp, if (selected) pal.accent else Color.Transparent, shape)
            .clickable(onClick = onPick),
    ) {
        bmp?.let { Image(it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Text(
            f.nameWithoutExtension, color = Color.White, fontSize = 10.sp, maxLines = 1,
            modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0x88000000))
                .padding(horizontal = 4.dp, vertical = 2.dp),
        )
        Text(
            "×", color = Color.White, fontSize = 14.sp,
            modifier = Modifier.align(Alignment.TopEnd).padding(3.dp).clip(CircleShape)
                .background(Color(0x88000000)).clickable(onClick = onDelete)
                .padding(horizontal = 7.dp, vertical = 1.dp),
        )
    }
}

@Composable
private fun FloatSettings(state: DesktopState) {
    val ctx = LocalContext.current
    val ok = remember { AppLauncher.freeformAvailable(ctx) }
    SectionTitle("Jendela sistem (eksperimental)")
    SCard(
        "apps", "Jendela sistem untuk aplikasi", "Eksperimental: memakai fitur freeform Android, tidak semua HP mendukung",
        onClick = { state.updateFloat(!state.floatApps) },
    ) { SwitchView(state.floatApps) { state.updateFloat(it) } }
    SCard(
        "o_scale",
        if (ok) "Dukungan freeform: aktif" else "Dukungan freeform: belum aktif",
        if (ok) "Aplikasi yang mendukung ubah ukuran akan terbuka mengambang"
        else "Di Opsi pengembang, aktifkan \"Jendela freeform\" dan \"Paksa aktivitas agar dapat diubah ukurannya\", lalu mulai ulang HP",
        onClick = { ctx.launch(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) },
    ) { Chev() }
    SectionTitle("Pengaturan sistem")
}

@Composable
private fun ShizukuSettings(state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    SectionTitle("Jendela sungguhan (Shizuku, eksperimental)")
    SCard(
        "apps", "Buka aplikasi di jendela desktop", "Aplikasi terpasang berjalan di dalam jendela seperti Browser",
        onClick = { state.updateShizuku(!state.shizukuWin) },
    ) { SwitchView(state.shizukuWin) { state.updateShizuku(it) } }
    SCard(
        "update", "Status: " + ShizukuBridge.status, "Ketuk untuk menghubungkan atau meminta izin Shizuku",
        onClick = { ShizukuBridge.connect() },
    ) { Chev() }
    SCard(
        "apps", "Buka aplikasi Shizuku", "Mulai Shizuku lewat Debugging nirkabel (Android 11+)",
        onClick = {
            val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (i != null) ctx.startActivity(i)
            else ctx.launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
        },
    ) { Chev() }
    Text(
        "Langkah: 1) Pasang Shizuku. 2) Opsi pengembang > Debugging nirkabel: aktifkan. " +
            "3) Di Shizuku, pilih Mulai lewat Debugging nirkabel dan pasangkan. " +
            "4) Kembali ke sini, ketuk Status untuk menghubungkan, lalu nyalakan saklar di atas. " +
            "Perlu diulang setelah HP dimulai ulang.",
        color = pal.sub, fontSize = 12.sp,
    )
}
