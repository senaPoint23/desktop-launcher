package com.example.desktoplauncher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp

/**
 * Ikon bergaya Windows 11, digambar langsung (tanpa file gambar).
 * Ikon berwarna: pc, files, settings, apps, windows, widgets, weather.
 * Ikon satu warna (pakai tint): search, bell, signal, volume, battery, chevron.
 */
@Composable
fun Glyph(kind: String, sz: Dp, tint: Color = Color.White, level: Float = 1f) {
    Canvas(Modifier.size(sz)) {
        val s = this.size.minDimension
        when (kind) {
            "pc" -> monitor(s)
            "files" -> folder(s)
            "settings" -> gear(s)
            "apps" -> appsGrid(s)
            "windows" -> winLogo(s)
            "widgets" -> widgets(s)
            "weather" -> weather(s)
            "search" -> search(s, tint)
            "bell" -> bell(s, tint)
            "signal" -> signal(s, tint)
            "volume" -> volume(s, tint)
            "battery" -> battery(s, tint, level)
            "chevron" -> chevron(s, tint)
            "bt" -> bluetooth(s)
            "brush" -> brush(s)
            "account" -> account(s)
            "time" -> timeIcon(s)
            "shield" -> shield(s)
            "update" -> update(s)
            "o_scale" -> oScale(s, tint)
            "o_rotate" -> oRotate(s, tint)
            "o_lock" -> oLock(s, tint)
            "o_nav" -> oNav(s, tint)
            "o_status" -> oStatus(s, tint)
            else -> rr(Color(0x66FFFFFF), .1f, .1f, .8f, .8f, .2f, s)
        }
    }
}

private fun DrawScope.rr(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float, s: Float) =
    drawRoundRect(c, Offset(x * s, y * s), Size(w * s, h * s), CornerRadius(r * s))

private fun DrawScope.rrb(b: Brush, x: Float, y: Float, w: Float, h: Float, r: Float, s: Float) =
    drawRoundRect(b, Offset(x * s, y * s), Size(w * s, h * s), CornerRadius(r * s))

private fun DrawScope.monitor(s: Float) {
    rr(Color(0xFF2A3340), .06f, .10f, .88f, .62f, .06f, s)
    rrb(Brush.linearGradient(listOf(Color(0xFF7DE8F8), Color(0xFF18A4D6)), Offset(0f, 0f), Offset(s, s)), .10f, .14f, .80f, .54f, .04f, s)
    rr(Color(0xFF9AA5B1), .42f, .72f, .16f, .10f, .01f, s)
    rr(Color(0xFF9AA5B1), .28f, .82f, .44f, .06f, .03f, s)
}

private fun DrawScope.folder(s: Float) {
    rr(Color(0xFFD98E1F), .06f, .16f, .42f, .22f, .05f, s)
    rrb(Brush.verticalGradient(listOf(Color(0xFFFFD35E), Color(0xFFF0A92B)), .28f * s, .86f * s), .06f, .28f, .88f, .58f, .07f, s)
    rr(Color(0x2EFFFFFF), .06f, .28f, .88f, .08f, .04f, s)
}

private fun DrawScope.gear(s: Float) {
    val c = Offset(s / 2, s / 2)
    val grey = Color(0xFF9AA5B1)
    for (i in 0 until 8) {
        rotate(i * 45f, c) {
            drawRoundRect(grey, Offset(c.x - .07f * s, c.y - .46f * s), Size(.14f * s, .22f * s), CornerRadius(.03f * s))
        }
    }
    drawCircle(grey, .34f * s, c)
    drawCircle(Color(0xFF2B7CD3), .17f * s, c)
    drawCircle(Color(0xFFEAF2FF), .07f * s, c)
}

private fun DrawScope.appsGrid(s: Float) {
    rr(Color(0xFF2B2F3A), .04f, .04f, .92f, .92f, .16f, s)
    val cols = listOf(0xFF4CC2FF, 0xFFFF8A3D, 0xFF7BE06A, 0xFFB57BFF, 0xFFFFD35E, 0xFFFF6B8B, 0xFF4C8DFF, 0xFF3DDBC0, 0xFFE8F0FF)
    for (i in 0 until 9) {
        rr(Color(cols[i]), .16f + (i % 3) * .25f, .16f + (i / 3) * .25f, .2f, .2f, .05f, s)
    }
}

private fun DrawScope.winLogo(s: Float) {
    val g = .06f
    val q = (1f - 2 * .08f - g) / 2f
    val b = Brush.linearGradient(listOf(Color(0xFF5CC8FF), Color(0xFF1E88FF)), Offset.Zero, Offset(s, s))
    rrb(b, .08f, .08f, q, q, .02f, s)
    rrb(b, .08f + q + g, .08f, q, q, .02f, s)
    rrb(b, .08f, .08f + q + g, q, q, .02f, s)
    rrb(b, .08f + q + g, .08f + q + g, q, q, .02f, s)
}

private fun DrawScope.widgets(s: Float) {
    rrb(Brush.verticalGradient(listOf(Color(0xFF4C8DFF), Color(0xFF1E4FD8)), .12f * s, .88f * s), .08f, .12f, .40f, .76f, .08f, s)
    rr(Color(0xFFEAF2FF), .54f, .12f, .38f, .35f, .08f, s)
    rr(Color(0xFF4CC2FF), .54f, .53f, .38f, .35f, .08f, s)
}

private fun DrawScope.weather(s: Float) {
    val cloud = Color(0xFFF5F7FA)
    drawCircle(Color(0xFFFFB020), .28f * s, Offset(.40f * s, .38f * s))
    drawCircle(cloud, .20f * s, Offset(.55f * s, .62f * s))
    drawCircle(cloud, .16f * s, Offset(.72f * s, .66f * s))
    rr(cloud, .35f, .62f, .45f, .2f, .1f, s)
}

private fun DrawScope.search(s: Float, t: Color) {
    drawCircle(t, radius = .26f * s, center = Offset(.42f * s, .42f * s), style = Stroke(.09f * s))
    drawLine(t, Offset(.62f * s, .62f * s), Offset(.86f * s, .86f * s), strokeWidth = .09f * s, cap = StrokeCap.Round)
}

private fun DrawScope.bell(s: Float, t: Color) {
    val st = Stroke(.07f * s, cap = StrokeCap.Round)
    drawArc(t, 180f, 180f, false, Offset(.22f * s, .12f * s), Size(.56f * s, .56f * s), style = st)
    drawLine(t, Offset(.22f * s, .40f * s), Offset(.16f * s, .70f * s), strokeWidth = .07f * s, cap = StrokeCap.Round)
    drawLine(t, Offset(.78f * s, .40f * s), Offset(.84f * s, .70f * s), strokeWidth = .07f * s, cap = StrokeCap.Round)
    drawLine(t, Offset(.14f * s, .72f * s), Offset(.86f * s, .72f * s), strokeWidth = .07f * s, cap = StrokeCap.Round)
    drawArc(t, 0f, 180f, false, Offset(.40f * s, .76f * s), Size(.20f * s, .14f * s), style = st)
}

private fun DrawScope.signal(s: Float, t: Color) {
    for (i in 0 until 4) {
        val h = .25f + i * .17f
        rr(t.copy(alpha = if (i < 3) 1f else .35f), .12f + i * .2f, .85f - h, .12f, h, .03f, s)
    }
}

private fun DrawScope.volume(s: Float, t: Color) {
    val p = Path().apply {
        moveTo(.10f * s, .38f * s); lineTo(.30f * s, .38f * s); lineTo(.52f * s, .18f * s)
        lineTo(.52f * s, .82f * s); lineTo(.30f * s, .62f * s); lineTo(.10f * s, .62f * s); close()
    }
    drawPath(p, t)
    val st = Stroke(.07f * s, cap = StrokeCap.Round)
    drawArc(t, -45f, 90f, false, Offset(.40f * s, .34f * s), Size(.32f * s, .32f * s), style = st)
    drawArc(t, -50f, 100f, false, Offset(.28f * s, .22f * s), Size(.56f * s, .56f * s), style = st)
}

private fun DrawScope.battery(s: Float, t: Color, level: Float) {
    val col = if (level <= .2f) Color(0xFFFF5252) else Color(0xFF6BDB6B)
    drawRoundRect(t, Offset(.06f * s, .28f * s), Size(.76f * s, .44f * s), CornerRadius(.08f * s), style = Stroke(.06f * s))
    rr(t, .85f, .42f, .07f, .16f, .02f, s)
    rr(col, .12f, .34f, .64f * level.coerceIn(0f, 1f), .32f, .04f, s)
}

private fun DrawScope.chevron(s: Float, t: Color) {
    drawLine(t, Offset(.22f * s, .62f * s), Offset(.50f * s, .34f * s), strokeWidth = .09f * s, cap = StrokeCap.Round)
    drawLine(t, Offset(.50f * s, .34f * s), Offset(.78f * s, .62f * s), strokeWidth = .09f * s, cap = StrokeCap.Round)
}

private fun DrawScope.bluetooth(s: Float) {
    drawCircle(Color(0xFF2B7CD3), .44f * s, Offset(s / 2, s / 2))
    val p = Path().apply {
        moveTo(.34f * s, .38f * s); lineTo(.62f * s, .64f * s); lineTo(.48f * s, .78f * s)
        lineTo(.48f * s, .22f * s); lineTo(.62f * s, .36f * s); lineTo(.34f * s, .62f * s)
    }
    drawPath(p, Color.White, style = Stroke(.06f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.brush(s: Float) {
    drawLine(Color(0xFFC9803A), Offset(.82f * s, .18f * s), Offset(.42f * s, .58f * s), strokeWidth = .12f * s, cap = StrokeCap.Round)
    drawCircle(Color(0xFF4C8DFF), .13f * s, Offset(.30f * s, .70f * s))
}

private fun DrawScope.account(s: Float) {
    val c = Color(0xFF2DBFA0)
    drawCircle(c, .18f * s, Offset(.5f * s, .32f * s))
    drawArc(c, 180f, 180f, true, Offset(.2f * s, .5f * s), Size(.6f * s, .6f * s))
}

private fun DrawScope.timeIcon(s: Float) {
    drawCircle(Color(0xFF4CA6FF), .40f * s, Offset(.5f * s, .5f * s))
    drawLine(Color.White, Offset(.5f * s, .5f * s), Offset(.5f * s, .26f * s), strokeWidth = .06f * s, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(.5f * s, .5f * s), Offset(.68f * s, .58f * s), strokeWidth = .06f * s, cap = StrokeCap.Round)
}

private fun DrawScope.shield(s: Float) {
    val p = Path().apply {
        moveTo(.5f * s, .10f * s); lineTo(.84f * s, .22f * s); lineTo(.84f * s, .52f * s)
        lineTo(.70f * s, .76f * s); lineTo(.5f * s, .92f * s); lineTo(.30f * s, .76f * s)
        lineTo(.16f * s, .52f * s); lineTo(.16f * s, .22f * s); close()
    }
    drawPath(p, Color(0xFFA9B4C2))
}

private fun DrawScope.update(s: Float) {
    val c = Color(0xFF2B9BF0)
    val st = Stroke(.11f * s, cap = StrokeCap.Round)
    drawArc(c, 200f, 140f, false, Offset(.2f * s, .2f * s), Size(.6f * s, .6f * s), style = st)
    drawArc(c, 20f, 140f, false, Offset(.2f * s, .2f * s), Size(.6f * s, .6f * s), style = st)
}

private fun DrawScope.oScale(s: Float, t: Color) {
    val st = Stroke(.07f * s, cap = StrokeCap.Round)
    drawRoundRect(t, Offset(.12f * s, .12f * s), Size(.40f * s, .40f * s), CornerRadius(.08f * s), style = st)
    drawRoundRect(t, Offset(.40f * s, .40f * s), Size(.48f * s, .48f * s), CornerRadius(.08f * s), style = st)
}

private fun DrawScope.oRotate(s: Float, t: Color) {
    val st = Stroke(.07f * s, cap = StrokeCap.Round)
    drawRoundRect(t, Offset(.10f * s, .34f * s), Size(.50f * s, .42f * s), CornerRadius(.08f * s), style = st)
    drawArc(t, -90f, 200f, false, Offset(.42f * s, .10f * s), Size(.42f * s, .42f * s), style = st)
}

private fun DrawScope.oLock(s: Float, t: Color) {
    drawRoundRect(t, Offset(.22f * s, .45f * s), Size(.56f * s, .40f * s), CornerRadius(.08f * s))
    drawArc(t, 180f, 180f, false, Offset(.32f * s, .15f * s), Size(.36f * s, .60f * s), style = Stroke(.07f * s, cap = StrokeCap.Round))
}

private fun DrawScope.oNav(s: Float, t: Color) {
    drawRoundRect(t, Offset(.12f * s, .14f * s), Size(.76f * s, .72f * s), CornerRadius(.10f * s), style = Stroke(.07f * s))
    rr(t, .30f, .68f, .40f, .06f, .03f, s)
}

private fun DrawScope.oStatus(s: Float, t: Color) {
    drawRoundRect(t, Offset(.12f * s, .14f * s), Size(.76f * s, .72f * s), CornerRadius(.10f * s), style = Stroke(.07f * s))
    rr(t, .30f, .26f, .40f, .06f, .03f, s)
}
