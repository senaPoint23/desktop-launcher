package com.example.desktoplauncher

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Menerapkan pengaturan Tampilan ke Activity: orientasi, bilah status, dan navigasi. */
object DisplayControl {
    fun apply(act: Activity, s: DesktopState) {
        applyOrientation(act, s)
        applyBars(act, s)
    }

    fun applyOrientation(act: Activity, s: DesktopState) {
        act.requestedOrientation = when {
            s.rotLock -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
            s.orient == "portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            s.orient == "auto" -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    fun applyBars(act: Activity, s: DesktopState) {
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (s.hideNav) c.hide(WindowInsetsCompat.Type.navigationBars()) else c.show(WindowInsetsCompat.Type.navigationBars())
        if (s.hideStatus) c.hide(WindowInsetsCompat.Type.statusBars()) else c.show(WindowInsetsCompat.Type.statusBars())
    }
}
