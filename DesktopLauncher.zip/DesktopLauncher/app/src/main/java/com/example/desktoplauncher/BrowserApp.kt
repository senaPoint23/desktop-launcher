package com.example.desktoplauncher

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.view.ViewGroup
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.net.URLEncoder

/** Satu tab browser: WebView beserta status yang ditampilkan di UI. */
@SuppressLint("SetJavaScriptEnabled")
class BrowserTab(val id: Int, private val ctx: Context, desktop: Boolean) {
    var title by mutableStateOf("Tab baru")
    var url by mutableStateOf("")
    var progress by mutableStateOf(100)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    val web: WebView = WebView(ctx)

    init {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
                url = u ?: url
                sync()
            }

            override fun onPageFinished(view: WebView?, u: String?) {
                url = u ?: url
                title = view?.title?.takeIf { it.isNotBlank() } ?: url
                sync()
            }

            override fun doUpdateVisitedHistory(view: WebView?, u: String?, isReload: Boolean) {
                url = u ?: url
                sync()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return false
                val s = target.toString()
                if (s.startsWith("http://") || s.startsWith("https://") || s.startsWith("about:") || s.startsWith("file:")) return false
                // Skema lain (mailto:, tel:, intent:) dibuka oleh aplikasi yang sesuai.
                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) { progress = newProgress }
            override fun onReceivedTitle(view: WebView?, t: String?) { if (!t.isNullOrBlank()) title = t }
        }
        web.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        applyDesktop(desktop, reload = false)
    }

    private fun sync() {
        canBack = web.canGoBack()
        canForward = web.canGoForward()
    }

    /** Mode desktop: User-Agent seperti Chrome di Linux, sehingga situs menampilkan versi PC. */
    fun applyDesktop(on: Boolean, reload: Boolean = true) {
        web.settings.userAgentString = if (on) BrowserSession.DESKTOP_UA else null
        if (reload && url.isNotEmpty()) web.reload()
    }

    private fun download(u: String, ua: String?, cd: String?, mime: String?) {
        runCatching {
            val name = URLUtil.guessFileName(u, cd, mime)
            val req = DownloadManager.Request(Uri.parse(u))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            if (!ua.isNullOrEmpty()) req.addRequestHeader("User-Agent", ua)
            (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            BrowserSession.note = "Mengunduh $name"
        }.onFailure { BrowserSession.note = "Gagal mengunduh" }
    }
}

/** Sesi browser yang tetap hidup saat window di-minimize; dihentikan saat window ditutup. */
object BrowserSession {
    const val HOME = "https://www.google.com"
    const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    val tabs = mutableStateListOf<BrowserTab>()
    var currentId by mutableStateOf(0)
    var desktop by mutableStateOf(false)
    var note by mutableStateOf<String?>(null)
    private var nextId = 1
    private var appCtx: Context? = null

    fun ensure(ctx: Context) {
        appCtx = ctx.applicationContext
        if (tabs.isEmpty()) newTab(HOME)
    }

    fun current(): BrowserTab? = tabs.firstOrNull { it.id == currentId } ?: tabs.firstOrNull()

    fun select(id: Int) { currentId = id }

    fun newTab(url: String?) {
        val ctx = appCtx ?: return
        val t = BrowserTab(nextId++, ctx, desktop)
        tabs.add(t)
        currentId = t.id
        if (!url.isNullOrEmpty()) t.web.loadUrl(url)
    }

    fun closeTab(t: BrowserTab) {
        val i = tabs.indexOf(t)
        tabs.remove(t)
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        t.web.destroy()
        if (tabs.isEmpty()) newTab(HOME)
        else if (currentId == t.id) currentId = tabs[(i - 1).coerceAtLeast(0)].id
    }

    fun updateDesktop(on: Boolean) {
        desktop = on
        current()?.applyDesktop(on)
    }

    fun shutdown() {
        tabs.toList().forEach { t ->
            runCatching {
                (t.web.parent as? ViewGroup)?.removeView(t.web)
                t.web.destroy()
            }
        }
        tabs.clear()
    }
}

private fun normalizeUrl(q: String): String {
    val s = q.trim()
    return when {
        s.isEmpty() -> BrowserSession.HOME
        s.startsWith("http://") || s.startsWith("https://") || s.startsWith("file://") -> s
        !s.contains(' ') && s.contains('.') -> "https://$s"
        else -> "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
    }
}

@Composable
fun BrowserApp() {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    LaunchedEffect(Unit) { BrowserSession.ensure(ctx) }
    val tab = BrowserSession.current()
    if (tab == null) {
        Text("Memuat browser…", color = pal.sub, fontSize = 13.sp)
        return
    }

    // Jeda WebView saat window tidak terlihat.
    DisposableEffect(tab.id) {
        tab.web.onResume()
        onDispose { tab.web.onPause() }
    }
    var text by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    LaunchedEffect(tab.id, tab.url, focused) { if (!focused) text = tab.url }
    LaunchedEffect(BrowserSession.note) {
        if (BrowserSession.note != null) { delay(2500); BrowserSession.note = null }
    }

    Column(Modifier.fillMaxSize()) {
        // Tab
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BrowserSession.tabs.forEach { t ->
                val sel = t.id == tab.id
                Row(
                    Modifier.width(150.dp).height(32.dp).clip(RoundedCornerShape(8.dp))
                        .background(if (sel) pal.text.copy(alpha = .12f) else pal.text.copy(alpha = .04f))
                        .clickable { BrowserSession.select(t.id) }.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(t.title, color = pal.text, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    Text(
                        "×", color = pal.sub, fontSize = 16.sp,
                        modifier = Modifier.clickable { BrowserSession.closeTab(t) }.padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                }
            }
            Text(
                "＋", color = pal.text, fontSize = 16.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .clickable { BrowserSession.newTab(BrowserSession.HOME) }.padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }

        // Toolbar
        Row(
            Modifier.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            NavBtn("back", tab.canBack) { tab.web.goBack() }
            NavBtn("fwd", tab.canForward) { tab.web.goForward() }
            NavBtn("reload", true) { if (tab.progress < 100) tab.web.stopLoading() else tab.web.reload() }
            NavBtn("home", true) { tab.web.loadUrl(BrowserSession.HOME) }
            val shape = RoundedCornerShape(17.dp)
            Box(
                Modifier.weight(1f).height(34.dp).clip(shape).background(pal.text.copy(alpha = .08f))
                    .border(1.dp, if (focused) pal.accent else pal.line, shape).padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                BasicTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    textStyle = TextStyle(color = pal.text, fontSize = 13.sp),
                    cursorBrush = SolidColor(pal.accent),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        tab.web.loadUrl(normalizeUrl(text))
                        focus.clearFocus()
                    }),
                    modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
                )
            }
            Text(
                "PC", fontSize = 12.sp,
                color = if (BrowserSession.desktop) pal.accent else pal.text,
                modifier = Modifier.padding(start = 4.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (BrowserSession.desktop) pal.accent.copy(alpha = .15f) else pal.text.copy(alpha = .08f))
                    .clickable { BrowserSession.updateDesktop(!BrowserSession.desktop) }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
            )
        }

        // Progres pemuatan
        if (tab.progress in 0..99) {
            Box(Modifier.fillMaxWidth().height(2.dp).background(pal.line)) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(tab.progress / 100f).background(pal.accent))
            }
        } else Spacer(Modifier.height(2.dp))

        BrowserSession.note?.let { Text(it, color = pal.accent, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }

        // Halaman web
        AndroidView(
            factory = { c -> FrameLayout(c) },
            update = { fl ->
                val wv = tab.web
                if (fl.getChildAt(0) !== wv) {
                    fl.removeAllViews()
                    (wv.parent as? ViewGroup)?.removeView(wv)
                    fl.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(6.dp)),
        )
    }
}

@Composable
private fun NavBtn(kind: String, enabled: Boolean, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val tint = if (enabled) pal.text else pal.sub.copy(alpha = .4f)
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        when (kind) {
            "back" -> Box(Modifier.graphicsLayer { rotationZ = -90f }) { Glyph("chevron", 16.dp, tint) }
            "fwd" -> Box(Modifier.graphicsLayer { rotationZ = 90f }) { Glyph("chevron", 16.dp, tint) }
            else -> Glyph(kind, 18.dp, tint)
        }
    }
}
