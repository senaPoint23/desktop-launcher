package com.example.desktoplauncher

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import rikka.shizuku.Shizuku

/** Mengurus koneksi ke Shizuku dan layanan berhak shell. */
object ShizukuBridge {
    var status by mutableStateOf("Belum terhubung")
    var ready by mutableStateOf(false)
    var service: IPrivilegedService? = null

    private const val REQ = 4711
    private var inited = false
    private var appCtx: Context? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IPrivilegedService.Stub.asInterface(binder) else null
            ready = service != null
            status = if (ready) "Terhubung" else "Gagal terhubung ke layanan"
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            ready = false
            status = "Layanan terputus"
        }
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        appCtx = ctx.applicationContext
        Shizuku.addBinderReceivedListenerSticky(Shizuku.OnBinderReceivedListener { check(false) })
        Shizuku.addBinderDeadListener(Shizuku.OnBinderDeadListener {
            service = null
            ready = false
            status = "Shizuku berhenti"
        })
        Shizuku.addRequestPermissionResultListener(Shizuku.OnRequestPermissionResultListener { _, result ->
            if (result == PackageManager.PERMISSION_GRANTED) bind() else status = "Izin Shizuku ditolak"
        })
    }

    /** Dipanggil dari tombol di Pengaturan: periksa Shizuku, minta izin, lalu hubungkan. */
    fun connect() = check(true)

    private fun check(requestPermission: Boolean) {
        try {
            if (!Shizuku.pingBinder()) {
                status = "Shizuku belum berjalan"
                ready = false
                return
            }
            if (Shizuku.isPreV11()) {
                status = "Versi Shizuku terlalu lama"
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                status = "Perlu izin Shizuku"
                if (requestPermission) {
                    if (Shizuku.shouldShowRequestPermissionRationale()) status = "Izin ditolak. Berikan lewat aplikasi Shizuku"
                    else Shizuku.requestPermission(REQ)
                }
                return
            }
            if (!ready) bind()
        } catch (t: Throwable) {
            status = "Kesalahan: " + t.message
        }
    }

    private fun bind() {
        val ctx = appCtx ?: return
        status = "Menghubungkan…"
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, PrivilegedService::class.java.name))
            .daemon(false)
            .processNameSuffix("priv")
            .version(1)
        try {
            Shizuku.bindUserService(args, conn)
        } catch (t: Throwable) {
            status = "Gagal menghubungkan: " + t.message
        }
    }
}
