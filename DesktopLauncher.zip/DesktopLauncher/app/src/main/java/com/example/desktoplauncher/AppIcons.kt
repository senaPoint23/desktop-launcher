package com.example.desktoplauncher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.roundToInt

/** Menu yang muncul saat ikon aplikasi di desktop ditahan. */
data class AppMenu(val pkg: String, val label: String, val at: Offset)

/** Ikon asli aplikasi terpasang. */
@Composable
fun AppIconImage(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) Image(bmp, contentDescription = null, modifier = Modifier.size(size))
    else Glyph("apps", size)
}

/**
 * Membuka aplikasi terpasang. Jika "jendela mengambang" aktif, aplikasi diminta terbuka
 * dalam jendela freeform berukuran sedang. Android hanya mengizinkannya bila fitur freeform
 * diaktifkan di perangkat (Opsi pengembang); jika tidak, aplikasi terbuka seperti biasa.
 */
object AppLauncher {
    private var cascade = 0
    private var hinted = false

    fun freeformAvailable(ctx: Context): Boolean {
        if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)) return true
        return runCatching {
            Settings.Global.getInt(ctx.contentResolver, "enable_freeform_support", 0) == 1
        }.getOrDefault(false)
    }

    fun launch(ctx: Context, state: DesktopState, pkg: String) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        state.closeOverlays()
        // Jendela sungguhan: aplikasi berjalan di layar virtual dan tampil di dalam jendela desktop (Shizuku).
        if (state.shizukuWin) {
            if (ShizukuBridge.ready) {
                val label = runCatching {
                    ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
                }.getOrDefault(pkg)
                state.open("vd:" + pkg, label, "")
                return
            }
            Toast.makeText(ctx, "Shizuku belum terhubung (" + ShizukuBridge.status + "). Aplikasi dibuka layar penuh.", Toast.LENGTH_LONG).show()
        }
        // Jendela sistem hanya dicoba bila diaktifkan DAN freeform didukung HP; selain itu layar penuh.
        val floating = state.floatApps && freeformAvailable(ctx)
        if (!floating) {
            runCatching { ctx.startActivity(intent) }
            if (state.floatApps && !hinted) {
                hinted = true
                Toast.makeText(ctx, "Jendela sistem butuh fitur freeform Android. Aplikasi dibuka layar penuh.", Toast.LENGTH_LONG).show()
            }
            return
        }
        val dm = ctx.resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val w = (sw * 0.6f).toInt()
        val h = (sh * 0.8f).toInt()
        val step = (28 * dm.density).toInt()
        val n = cascade++ % 5
        val l = ((sw - w) / 2 + (n - 2) * step).coerceIn(0, sw - w)
        val t = (sh * 0.05f).toInt() + n * step / 2
        val b = (t + h).coerceAtMost(sh - (60 * dm.density).toInt())
        val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, b))
        runCatching { ctx.startActivity(intent, opts.toBundle()) }.onFailure {
            runCatching { ctx.startActivity(intent) }
        }
    }
}

/** Menu konteks untuk aplikasi yang disematkan di desktop. */
@Composable
fun AppContextMenu(state: DesktopState) {
    val m = state.appMenu ?: return
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val onTask = m.pkg in state.taskPins
    val maxX = ((state.areaW - 210f) * state.density).toInt().coerceAtLeast(0)
    val maxY = ((state.areaH - 190f) * state.density).toInt().coerceAtLeast(0)
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .offset { IntOffset((m.at.x + 40f * state.density).roundToInt().coerceIn(0, maxX), m.at.y.roundToInt().coerceIn(0, maxY)) }
            .width(200.dp).clip(shape).background(pal.panel).border(1.dp, pal.line, shape).padding(6.dp)
    ) {
        AppMenuItem("Buka") { AppLauncher.launch(ctx, state, m.pkg) }
        AppMenuItem("Lepas dari desktop") { state.unpinDesktop(m.pkg); state.closeOverlays() }
        AppMenuItem(if (onTask) "Lepas dari taskbar" else "Sematkan ke taskbar") {
            if (onTask) state.unpinTaskbar(m.pkg) else state.pinTaskbar(m.pkg)
            state.closeOverlays()
        }
        AppMenuItem("Info aplikasi") {
            state.closeOverlays()
            ctx.launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + m.pkg)))
        }
    }
}

@Composable
private fun AppMenuItem(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Text(
        label, color = pal.text, fontSize = 14.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 11.dp),
    )
}
