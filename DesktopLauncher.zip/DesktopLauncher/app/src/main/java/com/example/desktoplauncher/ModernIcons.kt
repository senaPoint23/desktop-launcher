package com.example.desktoplauncher

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Gaya ikon: true = modern (kotak membulat bergradien), false = klasik. Diatur di Pengaturan > Personalisasi. */
val LocalModernIcons = compositionLocalOf { true }

/** Ikon berwarna yang punya versi modern. Ikon satu warna (search, bell, dll.) tetap sama. */
internal val ModernKinds = setOf(
    "pc", "files", "settings", "apps", "windows", "widgets", "weather", "bt", "brush",
    "account", "time", "shield", "update", "doc", "terminal", "browser", "image",
)

private val W = Color.White

private fun DrawScope.tile(s: Float, top: Color, bottom: Color) {
    val o = s * .04f
    val sz = Size(s - 2 * o, s - 2 * o)
    val r = CornerRadius(s * .26f)
    drawRoundRect(Brush.verticalGradient(listOf(top, bottom), startY = o, endY = s - o), Offset(o, o), sz, r)
    // Kilau lembut di bagian atas dan garis tepi tipis, supaya terlihat seperti kaca.
    drawRoundRect(Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color.Transparent), startY = o, endY = s * .6f), Offset(o, o), sz, r)
    drawRoundRect(Color(0x26FFFFFF), Offset(o, o), sz, r, style = Stroke(s * .012f))
}

/** Menggambar ikon modern: ubin gradien + simbol putih. Semua koordinat 0..1 dikali ukuran s. */
internal fun DrawScope.modernIcon(kind: String, s: Float) {
    fun mr(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float) =
        drawRoundRect(c, Offset(x * s, y * s), Size(w * s, h * s), CornerRadius(r * s))
    fun ln(c: Color, x1: Float, y1: Float, x2: Float, y2: Float, w: Float) =
        drawLine(c, Offset(x1 * s, y1 * s), Offset(x2 * s, y2 * s), strokeWidth = w * s, cap = StrokeCap.Round)
    fun poly(c: Color, w: Float, vararg p: Float) {
        val path = Path()
        for (i in 0 until p.size / 2) {
            val x = p[i * 2] * s
            val y = p[i * 2 + 1] * s
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, c, style = Stroke(w * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    val c = Offset(s / 2, s / 2)

    when (kind) {
        "windows" -> {
            val b = Brush.linearGradient(listOf(Color(0xFF67E8F9), Color(0xFF3B82F6)), Offset(0f, 0f), Offset(s, s))
            for (i in 0 until 4) {
                drawRoundRect(
                    b, Offset((.12f + (i % 2) * .4f) * s, (.12f + (i / 2) * .4f) * s),
                    Size(.36f * s, .36f * s), CornerRadius(.09f * s),
                )
            }
        }
        "pc" -> {
            tile(s, Color(0xFF38BDF8), Color(0xFF2563EB))
            mr(W, .2f, .26f, .6f, .38f, .06f)
            mr(Color(0x80BFDBFE), .24f, .3f, .52f, .3f, .04f)
            mr(Color(0xE6FFFFFF), .46f, .64f, .08f, .08f, .01f)
            mr(W, .34f, .72f, .32f, .05f, .025f)
        }
        "files" -> {
            tile(s, Color(0xFFFBBF24), Color(0xFFF59E0B))
            mr(Color(0xFFFFF3C4), .2f, .28f, .26f, .12f, .04f)
            mr(W, .2f, .35f, .6f, .4f, .06f)
        }
        "settings" -> {
            tile(s, Color(0xFF94A3B8), Color(0xFF475569))
            for (i in 0 until 8) {
                rotate(i * 45f, c) {
                    drawRoundRect(W, Offset(c.x - s * .04f, c.y - s * .3f), Size(s * .08f, s * .13f), CornerRadius(s * .02f))
                }
            }
            drawCircle(W, s * .22f, c)
            drawCircle(Color(0xFF64748B), s * .09f, c)
        }
        "apps" -> {
            tile(s, Color(0xFFA78BFA), Color(0xFF7C3AED))
            for (row in 0 until 3) for (col in 0 until 3) {
                mr(if (row == 1 && col == 1) W else Color(0xE6FFFFFF), .23f + col * .2f, .23f + row * .2f, .14f, .14f, .04f)
            }
        }
        "widgets" -> {
            tile(s, Color(0xFF60A5FA), Color(0xFF4F46E5))
            mr(Color(0xF2FFFFFF), .2f, .22f, .3f, .56f, .06f)
            mr(Color(0xD9FFFFFF), .54f, .22f, .26f, .26f, .06f)
            mr(Color(0x99FFFFFF), .54f, .52f, .26f, .26f, .06f)
        }
        "weather" -> {
            tile(s, Color(0xFF60A5FA), Color(0xFF2563EB))
            drawCircle(Color(0xFFFDE047), s * .13f, Offset(s * .4f, s * .4f))
            mr(W, .28f, .54f, .5f, .18f, .09f)
            drawCircle(W, s * .11f, Offset(s * .45f, s * .55f))
            drawCircle(W, s * .14f, Offset(s * .6f, s * .52f))
        }
        "bt" -> {
            tile(s, Color(0xFF3B82F6), Color(0xFF1D4ED8))
            poly(W, .06f, .38f, .36f, .62f, .64f, .5f, .76f, .5f, .24f, .62f, .36f, .38f, .64f)
        }
        "brush" -> {
            tile(s, Color(0xFFFB7185), Color(0xFFF97316))
            ln(W, .72f, .26f, .4f, .58f, .1f)
            drawCircle(Color(0xE6FFFFFF), s * .1f, Offset(s * .34f, s * .66f))
        }
        "account" -> {
            tile(s, Color(0xFF2DD4BF), Color(0xFF0D9488))
            drawCircle(W, s * .12f, Offset(s * .5f, s * .4f))
            drawOval(W, Offset(s * .28f, s * .58f), Size(s * .44f, s * .3f))
        }
        "time" -> {
            tile(s, Color(0xFF818CF8), Color(0xFF4F46E5))
            drawCircle(W, s * .26f, c, style = Stroke(s * .06f))
            ln(W, .5f, .5f, .5f, .34f, .05f)
            ln(W, .5f, .5f, .62f, .57f, .05f)
        }
        "shield" -> {
            tile(s, Color(0xFF4ADE80), Color(0xFF16A34A))
            val body = Path().apply {
                moveTo(s * .5f, s * .2f)
                lineTo(s * .76f, s * .3f)
                cubicTo(s * .76f, s * .56f, s * .66f, s * .72f, s * .5f, s * .8f)
                cubicTo(s * .34f, s * .72f, s * .24f, s * .56f, s * .24f, s * .3f)
                close()
            }
            drawPath(body, W)
            poly(Color(0xFF16A34A), .05f, .4f, .5f, .48f, .58f, .62f, .42f)
        }
        "update" -> {
            tile(s, Color(0xFF22D3EE), Color(0xFF0891B2))
            val r = s * .24f
            drawArc(
                color = W, startAngle = -40f, sweepAngle = 270f, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
                style = Stroke(s * .06f, cap = StrokeCap.Round),
            )
            // Kepala panah di ujung busur (sudut 230 derajat).
            val th = 230f * (PI.toFloat() / 180f)
            val e = Offset(c.x + r * cos(th), c.y + r * sin(th))
            val tx = -sin(th)
            val ty = cos(th)
            val nx = cos(th)
            val ny = sin(th)
            val head = Path().apply {
                moveTo(e.x + tx * s * .1f, e.y + ty * s * .1f)
                lineTo(e.x + nx * s * .08f, e.y + ny * s * .08f)
                lineTo(e.x - nx * s * .08f, e.y - ny * s * .08f)
                close()
            }
            drawPath(head, W)
        }
        "doc" -> {
            tile(s, Color(0xFF60A5FA), Color(0xFF2563EB))
            mr(Color(0xF2FFFFFF), .28f, .2f, .44f, .6f, .05f)
            mr(Color(0x802563EB), .36f, .34f, .28f, .04f, .02f)
            mr(Color(0x802563EB), .36f, .46f, .28f, .04f, .02f)
            mr(Color(0x802563EB), .36f, .58f, .2f, .04f, .02f)
        }
        "terminal" -> {
            tile(s, Color(0xFF334155), Color(0xFF0F172A))
            poly(Color(0xFF4ADE80), .06f, .28f, .36f, .46f, .5f, .28f, .64f)
            mr(Color(0xD9FFFFFF), .5f, .62f, .2f, .05f, .025f)
        }
        "browser" -> {
            tile(s, Color(0xFF38BDF8), Color(0xFF2563EB))
            drawCircle(W, s * .27f, c, style = Stroke(s * .05f))
            drawOval(W, Offset(s * .38f, s * .23f), Size(s * .24f, s * .54f), style = Stroke(s * .04f))
            ln(W, .23f, .5f, .77f, .5f, .04f)
        }
        "image" -> {
            tile(s, Color(0xFFF472B6), Color(0xFFA855F7))
            val hills = Path().apply {
                moveTo(s * .2f, s * .72f); lineTo(s * .4f, s * .45f); lineTo(s * .54f, s * .62f)
                lineTo(s * .64f, s * .5f); lineTo(s * .8f, s * .72f); close()
            }
            drawPath(hills, Color(0xF2FFFFFF))
            drawCircle(Color(0xE6FFFFFF), s * .07f, Offset(s * .66f, s * .34f))
        }
        else -> {}
    }
}
