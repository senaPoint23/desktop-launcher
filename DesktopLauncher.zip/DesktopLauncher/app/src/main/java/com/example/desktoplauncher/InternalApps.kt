package com.example.desktoplauncher

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Isi window untuk aplikasi internal. Tambahkan aplikasi baru di sini. */
@Composable
fun WindowContent(id: String, state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    when (id) {
        "settings" -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Tema", color = pal.sub, fontSize = 13.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.values().forEach { m ->
                    val sel = state.theme == m
                    val shape = RoundedCornerShape(20.dp)
                    Box(
                        Modifier.clip(shape)
                            .background(if (sel) pal.accent.copy(alpha = .15f) else Color.Transparent)
                            .border(1.dp, if (sel) pal.accent else pal.line, shape)
                            .clickable { state.setTheme(m) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(m.label, color = if (sel) pal.accent else pal.text) }
                }
            }
            Button(onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } }) {
                Text("Pilih launcher default")
            }
        }
        "files" -> Text("File Manager akan memakai Storage Access Framework (Fase 4).", color = pal.text)
        else -> Text(id, color = pal.text)
    }
}
