package com.example.desktoplauncher

import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Isi window untuk aplikasi internal. Tambahkan aplikasi baru di sini. */
@Composable
fun WindowContent(id: String, state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    when (id) {
        "settings" -> SettingsApp(state)
        "pc" -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val free = runCatching {
                Formatter.formatFileSize(ctx, StatFs(Environment.getDataDirectory().path).availableBytes)
            }.getOrDefault("-")
            Text("Spesifikasi perangkat", color = pal.text, fontWeight = FontWeight.SemiBold)
            listOf(
                "Perangkat" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                "Prosesor" to Build.HARDWARE,
                "Penyimpanan bebas" to free,
                "Launcher" to "Desktop Launcher 0.1, Developer: Riyo",
            ).forEach { (k, v) ->
                Row {
                    Text(k, color = pal.sub, fontSize = 13.sp, modifier = Modifier.weight(0.4f))
                    Text(v, color = pal.text, fontSize = 13.sp, modifier = Modifier.weight(0.6f))
                }
            }
        }
        "files" -> FilesApp()
        "terminal" -> TerminalApp()
        "browser" -> BrowserApp()
        else -> if (id.startsWith("vd:")) VirtualAppWindow(id.removePrefix("vd:")) else Text(id, color = pal.text)
    }
}
