package com.example.desktoplauncher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class Stats(
    val bat: Int, val charging: Boolean, val tempC: Float,
    val storUsed: Long, val storTotal: Long, val ramUsed: Long, val ramTotal: Long,
)

private fun readStats(ctx: Context): Stats {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
    val bat = if (level >= 0 && scale > 0) level * 100 / scale else -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    val st = StatFs(Environment.getDataDirectory().path)
    val total = st.blockCountLong * st.blockSizeLong
    val free = st.availableBlocksLong * st.blockSizeLong
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    return Stats(bat, charging, temp, total - free, total, mi.totalMem - mi.availMem, mi.totalMem)
}

/** Panel kiri (tombol widget di taskbar): jam, baterai, penyimpanan, dan memori. */
@Composable
fun WidgetsPanel(state: DesktopState, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    AnimatedVisibility(
        visible = state.panel == Panel.WIDGETS,
        modifier = modifier,
        enter = fadeIn(tween(150)) + slideInHorizontally(spring(stiffness = Spring.StiffnessMediumLow)) { -it / 4 },
        exit = fadeOut(tween(120)) + slideOutHorizontally(tween(150)) { -it / 4 },
    ) {
        val ctx = LocalContext.current
        val stats by produceState(readStats(ctx)) {
            while (true) { delay(5000); value = readStats(ctx) }
        }
        val shape = RoundedCornerShape(18.dp)
        Column(
            Modifier.padding(8.dp).width(340.dp).fillMaxHeight().clip(shape)
                .background(pal.panel).border(1.dp, pal.line, shape)
                .verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Widget", color = pal.text, fontWeight = FontWeight.SemiBold)
            ClockCard(state)
            WCard("Baterai") {
                Text(if (stats.bat >= 0) "${stats.bat}%" else "—", color = pal.text, fontSize = 28.sp)
                Text(
                    (if (stats.charging) "Sedang mengisi daya" else "Tidak mengisi daya") +
                        " · " + String.format(Locale("id", "ID"), "%.1f", stats.tempC) + " °C",
                    color = pal.sub, fontSize = 12.sp,
                )
                Bar(if (stats.bat >= 0) stats.bat / 100f else 0f, if (stats.bat in 0..20) Color(0xFFFF5252) else Color(0xFF6BDB6B))
            }
            WCard("Penyimpanan") {
                Text(
                    Formatter.formatShortFileSize(ctx, stats.storUsed) + " dari " + Formatter.formatShortFileSize(ctx, stats.storTotal),
                    color = pal.text, fontSize = 14.sp,
                )
                Bar(if (stats.storTotal > 0) stats.storUsed.toFloat() / stats.storTotal else 0f, pal.accent)
            }
            WCard("Memori (RAM)") {
                Text(
                    Formatter.formatShortFileSize(ctx, stats.ramUsed) + " dari " + Formatter.formatShortFileSize(ctx, stats.ramTotal),
                    color = pal.text, fontSize = 14.sp,
                )
                Bar(if (stats.ramTotal > 0) stats.ramUsed.toFloat() / stats.ramTotal else 0f, pal.accent)
            }
        }
    }
}

@Composable
private fun ClockCard(state: DesktopState) {
    val pal = LocalPalette.current
    val loc = remember { Locale("id", "ID") }
    val time by produceState("") { while (true) { value = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm")); delay(1000) } }
    val date by produceState("") { while (true) { value = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", loc)); delay(30_000) } }
    WCard("Jam") {
        Text(time, color = pal.text, fontSize = 36.sp, fontWeight = FontWeight.Light)
        Text(date, color = pal.sub, fontSize = 12.sp)
        Text(
            if (state.widgetOn) "Lepas dari desktop" else "Pasang di desktop",
            color = pal.accent, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { state.setWidget(!state.widgetOn) }.padding(vertical = 4.dp),
        )
    }
}

@Composable
private fun WCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(pal.text.copy(alpha = .05f)).border(1.dp, pal.line, shape).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(title, color = pal.sub, fontSize = 12.sp)
        content()
    }
}

@Composable
private fun Bar(fraction: Float, color: Color) {
    val pal = LocalPalette.current
    val v by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(400), label = "bar")
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(pal.line)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(v).background(color))
    }
}
