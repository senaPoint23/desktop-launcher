package com.example.desktoplauncher

import android.content.AttributionSource
import android.content.Context
import android.content.ContextWrapper
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Build
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface

/**
 * Berjalan di proses terpisah dengan hak akses shell (lewat Shizuku UserService).
 * Membuat layar virtual, membuka aplikasi di dalamnya, dan menyuntikkan sentuhan,
 * mirip cara kerja scrcpy. Memakai API tersembunyi lewat refleksi.
 */
class PrivilegedService() : IPrivilegedService.Stub() {
    private var base: Context? = null
    private var shell: Context? = null
    private var inputManager: Any? = null
    private val displays = HashMap<Int, VirtualDisplay>()
    private var err = ""

    constructor(context: Context) : this() { base = context }

    override fun destroy() { System.exit(0) }

    override fun lastError(): String = err

    private fun fail(where: String, t: Throwable) {
        err = where + ": " + (t.cause ?: t).toString()
        Log.e("PrivilegedService", err, t)
    }

    /** Context yang mengaku sebagai paket shell, agar DisplayManager menerima panggilan ini. */
    private class ShellContext(b: Context) : ContextWrapper(b) {
        override fun getPackageName(): String = "com.android.shell"
        override fun getOpPackageName(): String = "com.android.shell"
        override fun getApplicationContext(): Context = this
        override fun getAttributionSource(): AttributionSource =
            AttributionSource.Builder(2000).setPackageName("com.android.shell").build()
    }

    private fun shellContext(): Context {
        shell?.let { return it }
        val b = base ?: run {
            if (Looper.getMainLooper() == null) Looper.prepareMainLooper()
            val at = Class.forName("android.app.ActivityThread")
            val sys = at.getMethod("systemMain").invoke(null)
            at.getMethod("getSystemContext").invoke(sys) as Context
        }
        return ShellContext(b).also { shell = it }
    }

    private fun displayFlags(): Int {
        var f = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
            DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION or
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY or
            (1 shl 6) or (1 shl 7) or (1 shl 8)               // SUPPORTS_TOUCH, ROTATES_WITH_CONTENT, DESTROY_CONTENT_ON_REMOVAL
        if (Build.VERSION.SDK_INT >= 33) f = f or (1 shl 10) or (1 shl 11) or (1 shl 12) or (1 shl 13) // TRUSTED, OWN_DISPLAY_GROUP, ALWAYS_UNLOCKED, TOUCH_FEEDBACK_DISABLED
        if (Build.VERSION.SDK_INT >= 34) f = f or (1 shl 14) or (1 shl 15)                           // OWN_FOCUS, DEVICE_DISPLAY_GROUP
        return f
    }

    override fun createDisplay(surface: Surface?, width: Int, height: Int, dpi: Int, name: String?): Int {
        return try {
            val ctor = DisplayManager::class.java.getDeclaredConstructor(Context::class.java)
            ctor.isAccessible = true
            val dm = ctor.newInstance(shellContext())
            val vd = dm.createVirtualDisplay(name ?: "desktop-app", width, height, dpi, surface, displayFlags())
            if (vd == null) {
                err = "createVirtualDisplay mengembalikan null"
                -1
            } else {
                val id = vd.display.displayId
                displays[id] = vd
                id
            }
        } catch (t: Throwable) {
            fail("createDisplay", t)
            -1
        }
    }

    override fun setDisplaySurface(displayId: Int, surface: Surface?) {
        try { displays[displayId]?.surface = surface } catch (t: Throwable) { fail("setDisplaySurface", t) }
    }

    override fun releaseDisplay(displayId: Int) {
        try { displays.remove(displayId)?.release() } catch (t: Throwable) { fail("releaseDisplay", t) }
    }

    override fun startActivity(displayId: Int, component: String?): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("am", "start", "--display", displayId.toString(), "-n", component ?: ""))
            val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
            p.waitFor()
            out.trim().take(500)
        } catch (t: Throwable) {
            fail("startActivity", t)
            "Error: " + t.message
        }
    }

    private fun inputManager(): Any {
        inputManager?.let { return it }
        val c = Class.forName("android.hardware.input.InputManager")
        val m = c.getDeclaredMethod("getInstance")
        m.isAccessible = true
        return m.invoke(null)!!.also { inputManager = it }
    }

    private fun inject(ev: InputEvent, displayId: Int) {
        InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType).invoke(ev, displayId)
        val im = inputManager()
        im.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType).invoke(im, ev, 0)
    }

    override fun injectTouch(
        displayId: Int, action: Int, count: Int,
        ids: IntArray?, xs: FloatArray?, ys: FloatArray?, downTime: Long, eventTime: Long,
    ) {
        try {
            if (ids == null || xs == null || ys == null) return
            val props = Array(count) { i ->
                MotionEvent.PointerProperties().apply { id = ids[i]; toolType = MotionEvent.TOOL_TYPE_FINGER }
            }
            val coords = Array(count) { i ->
                MotionEvent.PointerCoords().apply { x = xs[i]; y = ys[i]; pressure = 1f; size = 1f }
            }
            val ev = MotionEvent.obtain(
                downTime, eventTime, action, count, props, coords,
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0,
            )
            inject(ev, displayId)
            ev.recycle()
        } catch (t: Throwable) {
            fail("injectTouch", t)
        }
    }

    override fun injectKey(displayId: Int, keyCode: Int, down: Boolean) {
        try {
            val now = SystemClock.uptimeMillis()
            val ev = KeyEvent(now, now, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, keyCode, 0, 0, -1, 0, 0, InputDevice.SOURCE_KEYBOARD)
            inject(ev, displayId)
        } catch (t: Throwable) {
            fail("injectKey", t)
        }
    }
}
