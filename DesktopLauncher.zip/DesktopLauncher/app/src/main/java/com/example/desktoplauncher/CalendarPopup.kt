package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/** Kalender bulanan yang muncul saat jam di taskbar diketuk. */
@Composable
fun CalendarPopup(state: DesktopState, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    AnimatedVisibility(
        visible = state.panel == Panel.CALENDAR,
        modifier = modifier,
        enter = fadeIn(tween(150)) + slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it / 5 },
        exit = fadeOut(tween(120)) + slideOutVertically(tween(150)) { it / 6 },
    ) {
        var ym by remember { mutableStateOf(YearMonth.now()) }
        val today = remember { LocalDate.now() }
        val loc = remember { Locale("id", "ID") }
        val shape = RoundedCornerShape(18.dp)
        val offset = ym.atDay(1).dayOfWeek.value - 1
        val days = ym.lengthOfMonth()

        Column(
            Modifier.padding(8.dp).width(300.dp).clip(shape)
                .background(pal.panel).border(1.dp, pal.line, shape).padding(14.dp)
        ) {
            Text(today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", loc)), color = pal.sub, fontSize = 12.sp)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavBtn("‹") { ym = ym.minusMonths(1) }
                Text(
                    ym.month.getDisplayName(TextStyle.FULL, loc).replaceFirstChar { it.uppercase() } + " " + ym.year,
                    color = pal.text, fontWeight = FontWeight.SemiBold,
                )
                NavBtn("›") { ym = ym.plusMonths(1) }
            }
            Row(Modifier.fillMaxWidth()) {
                listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEach {
                    Text(it, modifier = Modifier.weight(1f), color = pal.sub, fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
            for (r in 0 until 6) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val d = r * 7 + c - offset + 1
                        val isToday = today.year == ym.year && today.monthValue == ym.monthValue && today.dayOfMonth == d
                        DayCell(if (d in 1..days) d else 0, isToday, Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun NavBtn(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Box(Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = pal.text, fontSize = 20.sp)
    }
}

@Composable
private fun DayCell(day: Int, today: Boolean, modifier: Modifier) {
    val pal = LocalPalette.current
    Box(modifier.height(30.dp), contentAlignment = Alignment.Center) {
        if (day > 0) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(if (today) pal.accent else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) { Text("$day", color = if (today) Color.Black else pal.text, fontSize = 13.sp) }
        }
    }
}
