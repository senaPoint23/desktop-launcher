package com.example.desktoplauncher

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

/** Menu yang muncul saat area kosong desktop ditahan. */
@Composable
fun DesktopContextMenu(state: DesktopState) {
    val at = state.menuAt ?: return
    val pal = LocalPalette.current
    val maxX = ((state.areaW - 210f) * state.density).toInt().coerceAtLeast(0)
    val maxY = ((state.areaH - 200f) * state.density).toInt().coerceAtLeast(0)
    val shape = RoundedCornerShape(14.dp)
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val sc by animateFloatAsState(if (shown) 1f else 0.9f, spring(dampingRatio = 0.6f), label = "menuPop")

    Column(
        Modifier
            .offset { IntOffset(at.x.roundToInt().coerceIn(0, maxX), at.y.roundToInt().coerceIn(0, maxY)) }
            .graphicsLayer { scaleX = sc; scaleY = sc; alpha = ((sc - 0.9f) / 0.1f).coerceIn(0f, 1f) }
            .width(200.dp).clip(shape).background(pal.panel).border(1.dp, pal.line, shape).padding(6.dp)
    ) {
        MenuItem("🎨  Ganti tema") {
            val all = ThemeMode.values()
            state.changeTheme(all[(state.theme.ordinal + 1) % all.size])
            state.closeOverlays()
        }
        MenuItem("🧹  Rapikan ikon") { state.arrangeIcons(); state.closeOverlays() }
        MenuItem(if (state.widgetOn) "🕒  Sembunyikan jam" else "🕒  Tampilkan jam") {
            state.setWidget(!state.widgetOn); state.closeOverlays()
        }
        MenuItem("⚙️  Pengaturan") { state.open("settings", "Settings", "⚙️") }
    }
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Text(
        label, color = pal.text, fontSize = 14.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 11.dp),
    )
}

/** Widget jam besar di pojok kanan atas desktop. */
@Composable
fun ClockWidget(state: DesktopState, modifier: Modifier = Modifier) {
    if (!state.widgetOn) return
    val now by produceState(LocalDateTime.now()) {
        while (true) { delay(15_000); value = LocalDateTime.now() }
    }
    val loc = remember { Locale("id", "ID") }
    Column(modifier, horizontalAlignment = Alignment.End) {
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", loc)), color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
    }
}
