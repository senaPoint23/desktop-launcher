package com.example.desktoplauncher

import android.content.Intent
import android.content.pm.PackageManager

/** emoji != null berarti aplikasi internal (dibuka sebagai window di desktop). */
data class AppInfo(val label: String, val pkg: String, val emoji: String? = null)

object AppRepository {
    val internal = listOf(
        AppInfo("PC Ini", "pc", "🖥️"),
        AppInfo("Files", "files", "📁"),
        AppInfo("Pengaturan", "settings", "⚙️"),
    )

    fun load(pm: PackageManager, self: String): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != self }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}
