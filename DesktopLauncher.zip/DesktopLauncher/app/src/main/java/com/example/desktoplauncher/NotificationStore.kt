package com.example.desktoplauncher

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateListOf

data class NotifItem(
    val key: String,
    val app: String,
    val title: String,
    val text: String,
    val intent: PendingIntent?,
)

/** Daftar notifikasi aktif yang dibaca oleh NotifService dan ditampilkan di panel. */
object NotificationStore {
    val items = mutableStateListOf<NotifItem>()
    fun dismiss(key: String) { NotifService.instance?.cancelNotification(key) }
    fun dismissAll() { NotifService.instance?.cancelAllNotifications() }
}

class NotifService : NotificationListenerService() {
    companion object { var instance: NotifService? = null }

    override fun onListenerConnected() { instance = this; refresh() }
    override fun onListenerDisconnected() { instance = null; NotificationStore.items.clear() }
    override fun onNotificationPosted(sbn: StatusBarNotification) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { refresh() }

    private fun refresh() {
        val active = runCatching { activeNotifications }.getOrNull() ?: return
        val list = active
            .filter { it.packageName != packageName && !it.isOngoing }
            .filter { (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .sortedByDescending { it.postTime }
            .map { sbn ->
                val ex = sbn.notification.extras
                val app = runCatching {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
                }.getOrDefault(sbn.packageName)
                NotifItem(
                    key = sbn.key,
                    app = app,
                    title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
                    text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
                    intent = sbn.notification.contentIntent,
                )
            }
        NotificationStore.items.clear()
        NotificationStore.items.addAll(list)
    }
}
