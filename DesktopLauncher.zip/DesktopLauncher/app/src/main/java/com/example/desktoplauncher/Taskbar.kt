package com.example.desktoplauncher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private fun timeText(): String = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))

private fun batteryPercent(ctx: Context): Int {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (l < 0 || s <= 0) -1 else l * 100 / s
}

@Composable
fun Taskbar(state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    // Satu timer 15 detik untuk jam dan baterai, tanpa receiver permanen.
    val info by produceState(timeText() to batteryPercent(ctx)) {
        while (true) { delay(15_000); value = timeText() to batteryPercent(ctx) }
    }

    Row(
        Modifier.fillMaxWidth().height(48.dp).background(pal.bar).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TaskBtn("⊞", on = state.startOpen, running = false) {
            val o = !state.startOpen
            state.closeOverlays()
            state.startOpen = o
        }
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
            state.windows.sortedBy { it.seq }.forEach { w ->
                TaskBtn(w.emoji, on = state.activeId == w.id && !w.minimized, running = true) { state.toggle(w.id) }
            }
        }
        val bat = if (info.second >= 0) "🔋${info.second}%  " else ""
        Text(
            bat + info.first, color = pal.text, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { state.openPanel(Panel.CALENDAR) }
                .padding(horizontal = 8.dp, vertical = 8.dp),
        )
        TaskBtn("🔔", on = state.panel == Panel.NOTIF, running = false) { state.openPanel(Panel.NOTIF) }
    }
}

@Composable
private fun TaskBtn(label: String, on: Boolean, running: Boolean, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pressed) 0.86f else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "taskPress",
    )
    Box(
        Modifier.size(46.dp, 40.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(10.dp))
            .background(if (on) pal.accent.copy(alpha = .14f) else Color.Transparent)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 20.sp, color = pal.text)
        if (running) {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp).size(18.dp, 3.dp)
                    .clip(RoundedCornerShape(2.dp)).background(if (on) pal.accent else pal.sub)
            )
        }
    }
}
