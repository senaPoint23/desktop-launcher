package com.example.desktoplauncher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private data class ClockInfo(val time: String, val date: String, val bat: Int)

private fun batteryPercent(ctx: Context): Int {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (l < 0 || s <= 0) -1 else l * 100 / s
}

private fun clockInfo(ctx: Context): ClockInfo {
    val n = LocalDateTime.now()
    return ClockInfo(
        n.format(DateTimeFormatter.ofPattern("HH:mm")),
        n.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")),
        batteryPercent(ctx),
    )
}

@Composable
fun Taskbar(state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    // Satu timer 15 detik untuk jam dan baterai, tanpa receiver permanen.
    val info by produceState(clockInfo(ctx)) {
        while (true) { delay(15_000); value = clockInfo(ctx) }
    }
    val pinned = listOf("files", "settings", "terminal")
    val extra = state.windows.filter { it.id !in pinned }.sortedBy { it.seq }

    Box(Modifier.fillMaxWidth().height(52.dp).background(pal.bar)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(pal.line))
        // Strip tipis di ujung kanan: tampilkan desktop (sembunyikan/kembalikan semua window).
        Box(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(10.dp)
                .background(pal.text.copy(alpha = .06f))
                .clickable { state.toggleDesktop() },
        )

        Row(
            Modifier.align(Alignment.CenterStart)
                .windowInsetsPadding(WindowInsets.displayCutout.only(WindowInsetsSides.Start))
                .padding(start = 10.dp),
        ) {
            TaskBtn("widgets", on = state.panel == Panel.WIDGETS, running = false) { state.openPanel(Panel.WIDGETS) }
        }

        Row(
            Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TaskBtn("windows", on = state.startOpen, running = false) {
                val o = !state.startOpen
                state.closeOverlays()
                state.startOpen = o
            }
            SearchPill { state.closeOverlays(); state.startOpen = true }
            pinned.forEach { id -> AppBtn(id, state) }
            extra.forEach { w -> AppBtn(w.id, state) }
        }

        Row(
            Modifier.align(Alignment.CenterEnd)
                .windowInsetsPadding(WindowInsets.displayCutout.only(WindowInsetsSides.End))
                .padding(end = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Glyph("chevron", 16.dp, pal.text)
            Row(
                Modifier.clip(RoundedCornerShape(8.dp)).clickable { state.openPanel(Panel.NOTIF) }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Glyph("signal", 18.dp, pal.text)
                Glyph("volume", 20.dp, pal.text)
                Glyph("battery", 22.dp, pal.text, if (info.bat >= 0) info.bat / 100f else 1f)
            }
            Column(
                Modifier.clip(RoundedCornerShape(8.dp)).clickable { state.openPanel(Panel.CALENDAR) }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.End,
            ) {
                Text(info.time, color = pal.text, fontSize = 13.sp)
                Text(info.date, color = pal.text, fontSize = 12.sp)
            }
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).clickable { state.openPanel(Panel.NOTIF) },
                contentAlignment = Alignment.Center,
            ) {
                Glyph("bell", 20.dp, pal.text)
                if (NotificationStore.items.isNotEmpty()) {
                    Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(8.dp).clip(CircleShape).background(Color(0xFFFF5252)))
                }
            }
        }
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.width(150.dp).height(36.dp).clip(shape)
            .background(pal.text.copy(alpha = .08f)).border(1.dp, pal.line, shape)
            .clickable(onClick = onClick).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Glyph("search", 18.dp, pal.text)
        Text("Cari", color = pal.sub, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
        Glyph("weather", 18.dp)
    }
}

@Composable
private fun AppBtn(id: String, state: DesktopState) {
    val w = state.windows.find { it.id == id && !it.closing }
    TaskBtn(id, on = w != null && state.activeId == id && !w.minimized, running = w != null) {
        if (w != null) state.toggle(id)
        else AppRepository.internal.find { it.pkg == id }?.let { state.open(it.pkg, it.label, it.emoji ?: "") }
    }
}

@Composable
private fun TaskBtn(kind: String, on: Boolean, running: Boolean, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pressed) 0.86f else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "taskPress",
    )
    val indicator by animateDpAsState(if (on) 16.dp else 6.dp, label = "indicator")
    Box(
        Modifier.size(46.dp, 40.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(RoundedCornerShape(8.dp))
            .background(if (on) pal.text.copy(alpha = .10f) else Color.Transparent)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Glyph(kind, 24.dp, pal.text)
        if (running) {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp).size(indicator, 3.dp)
                    .clip(RoundedCornerShape(2.dp)).background(if (on) pal.accent else pal.sub)
            )
        }
    }
}
