package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime

private fun greeting(): String = when (LocalTime.now().hour) {
    in 5..10 -> "Selamat pagi"
    in 11..14 -> "Selamat siang"
    in 15..17 -> "Selamat sore"
    else -> "Selamat malam"
}

private val welcomeTips = listOf(
    "Start" to "Ketuk tombol Start untuk mencari dan membuka aplikasi.",
    "Menu desktop" to "Tahan area kosong di desktop untuk membuka menu.",
    "Jendela" to "Seret judul jendela ke tepi layar untuk snap separuh atau penuh.",
    "Kalender" to "Ketuk jam di taskbar untuk membuka kalender.",
)

/** Sambutan: muncul sekali setelah layar pemuatan pertama; bisa ditampilkan lagi dari Pengaturan. */
@Composable
fun WelcomeScreen(state: DesktopState) {
    val pal = LocalPalette.current
    AnimatedVisibility(
        visible = state.showWelcome,
        enter = fadeIn(tween(400)) + scaleIn(tween(400), initialScale = 0.92f),
        exit = fadeOut(tween(250)),
    ) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = .55f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            contentAlignment = Alignment.Center,
        ) {
            val shape = RoundedCornerShape(16.dp)
            Column(
                Modifier.widthIn(max = 420.dp).clip(shape).background(pal.window)
                    .border(1.dp, pal.line, shape)
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Glyph("windows", 56.dp, pal.accent)
                Spacer(Modifier.height(12.dp))
                Text(greeting(), color = pal.sub, fontSize = 14.sp)
                Text("Selamat datang di Desktop Launcher", color = pal.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))
                welcomeTips.forEach { (title, body) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
                        Box(Modifier.padding(top = 6.dp).size(8.dp).clip(CircleShape).background(pal.accent))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(title, color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(body, color = pal.sub, fontSize = 13.sp)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(pal.accent)
                        .clickable { state.dismissWelcome() }.padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Mulai", color = Color(0xFF0B1220), fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}
