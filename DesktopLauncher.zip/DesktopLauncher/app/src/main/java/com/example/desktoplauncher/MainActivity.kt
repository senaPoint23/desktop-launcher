package com.example.desktoplauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: DesktopViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DesktopScreen(vm.state) }
        DisplayControl.apply(this, vm.state)
        ShizukuBridge.init(this)
    }

    // Wallpaper live dijeda saat launcher tidak terlihat.
    override fun onStart() { super.onStart(); vm.state.inForeground = true; vm.state.touch() }
    override fun onStop() { super.onStop(); vm.state.inForeground = false }

    // Bilah sistem yang disembunyikan bisa muncul lagi setelah fokus berpindah.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) DisplayControl.applyBars(this, vm.state)
    }
}
