package com.example.desktoplauncher

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val label: String, val light: Boolean = false) {
    BLOOM("Bloom"), DARK("Gelap"), LIGHT("Terang", true), AMOLED("AMOLED"), GLASS("Kaca"), MINIMAL("Minimal", true),
    OCEAN("Samudra"), SUNSET("Jingga"), FOREST("Hutan"), NEBULA("Nebula"), SAKURA("Sakura", true), MINT("Mint", true),
    SPONGEBOB("SpongeBob", true), MINECRAFT("Minecraft"), CYBERPUNK("Cyberpunk"), FURINA("Furina")
}

data class Palette(
    val wallpaper: List<Color>, val panel: Color, val bar: Color, val window: Color,
    val text: Color, val sub: Color, val accent: Color, val line: Color,
)

fun paletteFor(m: ThemeMode): Palette = when (m) {
    ThemeMode.BLOOM -> Palette(listOf(Color(0xFF0A1B3D), Color(0xFF030814)), Color(0xEB262629), Color(0xF21E1E21), Color(0xFF202023), Color(0xFFF5F5F7), Color(0xFFA0A0A8), Color(0xFF60CDFF), Color(0x24FFFFFF))
    ThemeMode.DARK -> Palette(listOf(Color(0xFF0F766E), Color(0xFF1E3A8A)), Color(0xE0182030), Color(0xE0121924), Color(0xFF1A232F), Color(0xFFE8EEF4), Color(0xFF93A3B3), Color(0xFF2DD4BF), Color(0x1FFFFFFF))
    ThemeMode.LIGHT -> Palette(listOf(Color(0xFF5EEAD4), Color(0xFF93C5FD)), Color(0xE0FFFFFF), Color(0xE6FFFFFF), Color.White, Color(0xFF14202B), Color(0xFF5A6B7A), Color(0xFF0D9488), Color(0x1F14202B))
    ThemeMode.AMOLED -> Palette(listOf(Color.Black, Color.Black), Color(0xEB000000), Color.Black, Color.Black, Color(0xFFF1F5F9), Color(0xFF8B98A5), Color(0xFF2DD4BF), Color(0x29FFFFFF))
    ThemeMode.GLASS -> Palette(listOf(Color(0xFF7C2D12), Color(0xFFBE185D), Color(0xFF312E81)), Color(0x29FFFFFF), Color(0x24FFFFFF), Color(0x8C1E293B), Color.White, Color(0xFFD5E2EF), Color(0xFF5EEAD4), Color(0x47FFFFFF))
    ThemeMode.MINIMAL -> Palette(listOf(Color(0xFF475569), Color(0xFF475569)), Color(0xFFF4F5F7), Color(0xFFF4F5F7), Color.White, Color(0xFF1F2933), Color(0xFF6B7785), Color(0xFF2563EB), Color(0xFFD8DDE3))
    ThemeMode.OCEAN -> Palette(listOf(Color(0xFF0E7490), Color(0xFF0C4A6E)), Color(0xE0102838), Color(0xE00B1D2B), Color(0xFF12293A), Color(0xFFE6F4FA), Color(0xFF8FB0C2), Color(0xFF22D3EE), Color(0x1FFFFFFF))
    ThemeMode.SUNSET -> Palette(listOf(Color(0xFFEA580C), Color(0xFFBE185D), Color(0xFF4C1D95)), Color(0xE02A1830), Color(0xE0201226), Color(0xFF2B1A33), Color(0xFFFDEFF4), Color(0xFFC9A3B5), Color(0xFFFB923C), Color(0x24FFFFFF))
    ThemeMode.FOREST -> Palette(listOf(Color(0xFF166534), Color(0xFF064E3B)), Color(0xE0142A22), Color(0xE00D1F18), Color(0xFF16291F), Color(0xFFE8F5EC), Color(0xFF90B3A0), Color(0xFF4ADE80), Color(0x1FFFFFFF))
    ThemeMode.NEBULA -> Palette(listOf(Color(0xFF4C1D95), Color(0xFF1E1B4B), Color(0xFF701A75)), Color(0xE0201A38), Color(0xE0161230), Color(0xFF1E1A36), Color(0xFFF1ECFF), Color(0xFFAA9FCB), Color(0xFFC084FC), Color(0x24FFFFFF))
    ThemeMode.SAKURA -> Palette(listOf(Color(0xFFFBCFE8), Color(0xFFC7D2FE)), Color(0xE6FFFFFF), Color(0xE6FFF5F9), Color.White, Color(0xFF3B1F2B), Color(0xFF8A6577), Color(0xFFDB2777), Color(0x1F3B1F2B))
    ThemeMode.MINT -> Palette(listOf(Color(0xFFA7F3D0), Color(0xFFBAE6FD)), Color(0xE6FFFFFF), Color(0xE6F3FFFA), Color.White, Color(0xFF12302A), Color(0xFF55766E), Color(0xFF059669), Color(0x1F12302A))
    ThemeMode.SPONGEBOB -> Palette(listOf(Color(0xFF00A9D6), Color(0xFF007F9E), Color(0xFF74D7E8)), Color(0xE8FFF8D6), Color(0xF2FFE98A), Color(0xFFFFFBE8), Color(0xFF173B50), Color(0xFF557987), Color(0xFFFFC928), Color(0x553A8BA0))
    ThemeMode.MINECRAFT -> Palette(listOf(Color(0xFF315C35), Color(0xFF182E20)), Color(0xE0213025), Color(0xF018241B), Color(0xFF24372A), Color(0xFFF1F8EE), Color(0xFFA5B8A0), Color(0xFF78C850), Color(0x24FFFFFF))
    ThemeMode.CYBERPUNK -> Palette(listOf(Color(0xFF170C36), Color(0xFF321052), Color(0xFF071D36)), Color(0xE0201635), Color(0xF016102B), Color(0xFF25183B), Color(0xFFF8F2FF), Color(0xFFB9A8D4), Color(0xFFFF3BC8), Color(0x33FF3BC8))
    ThemeMode.FURINA -> Palette(listOf(Color(0xFFB9E8FF), Color(0xFF4389C5), Color(0xFF183A72)), Color(0xE8F5FBFF), Color(0xF2E3F5FF), Color(0xFFF9FCFF), Color(0xFF183858), Color(0xFF587B9C), Color(0xFF258CCB), Color(0x33258CCB))
}

val LocalPalette = compositionLocalOf { paletteFor(ThemeMode.BLOOM) }

@Composable
private fun animC(v: Color): Color = animateColorAsState(v, tween(300), label = "c").value

/** Warna panel/teks berpindah halus saat tema diganti. */
@Composable
fun animatePalette(t: Palette): Palette = Palette(
    t.wallpaper, animC(t.panel), animC(t.bar), animC(t.window),
    animC(t.text), animC(t.sub), animC(t.accent), animC(t.line),
)
