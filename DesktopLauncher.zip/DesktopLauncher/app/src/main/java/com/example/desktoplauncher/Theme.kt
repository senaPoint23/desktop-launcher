package com.example.desktoplauncher

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val label: String) {
    DARK("Gelap"), LIGHT("Terang"), AMOLED("AMOLED"), GLASS("Kaca"), MINIMAL("Minimal")
}

data class Palette(
    val wallpaper: List<Color>, val panel: Color, val bar: Color, val window: Color,
    val text: Color, val sub: Color, val accent: Color, val line: Color,
)

fun paletteFor(m: ThemeMode): Palette = when (m) {
    ThemeMode.DARK -> Palette(listOf(Color(0xFF0F766E), Color(0xFF1E3A8A)), Color(0xE0182030), Color(0xE0121924), Color(0xFF1A232F), Color(0xFFE8EEF4), Color(0xFF93A3B3), Color(0xFF2DD4BF), Color(0x1FFFFFFF))
    ThemeMode.LIGHT -> Palette(listOf(Color(0xFF5EEAD4), Color(0xFF93C5FD)), Color(0xE0FFFFFF), Color(0xE6FFFFFF), Color.White, Color(0xFF14202B), Color(0xFF5A6B7A), Color(0xFF0D9488), Color(0x1F14202B))
    ThemeMode.AMOLED -> Palette(listOf(Color.Black, Color.Black), Color(0xEB000000), Color.Black, Color.Black, Color(0xFFF1F5F9), Color(0xFF8B98A5), Color(0xFF2DD4BF), Color(0x29FFFFFF))
    ThemeMode.GLASS -> Palette(listOf(Color(0xFF7C2D12), Color(0xFFBE185D), Color(0xFF312E81)), Color(0x29FFFFFF), Color(0x24FFFFFF), Color(0x8C1E293B), Color.White, Color(0xFFD5E2EF), Color(0xFF5EEAD4), Color(0x47FFFFFF))
    ThemeMode.MINIMAL -> Palette(listOf(Color(0xFF475569), Color(0xFF475569)), Color(0xFFF4F5F7), Color(0xFFF4F5F7), Color.White, Color(0xFF1F2933), Color(0xFF6B7785), Color(0xFF2563EB), Color(0xFFD8DDE3))
}

val LocalPalette = compositionLocalOf { paletteFor(ThemeMode.DARK) }
