package com.example.desktoplauncher

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * TEMA SISTEM: satu paket yang mengganti sekaligus palet warna, wallpaper, ikon, bingkai jendela,
 * bar judul, dan taskbar. Gambar tiap paket (opsional) ditaruh di app/src/main/assets/themes/<id>/ :
 *   wallpaper.(jpg|png|webp)   taskbar.png   titlebar.png   icons/<nama>.png
 * Berkas yang tidak ada diganti tampilan bawaan (digambar lewat kode), jadi paket selalu bisa dipakai.
 */
enum class Chrome(val radius: Int, val border: Int) { SOFT(16, 1), ROYAL(18, 2), PIXEL(0, 3) }

enum class Scene { REEF, SKY, VOXEL }

class ThemePack(
    val id: String,
    val label: String,
    val palette: Palette,
    val frame: Color,        // warna bingkai jendela dan taskbar
    val chrome: Chrome,      // bentuk jendela/taskbar
    val scene: Scene,        // wallpaper bawaan bila wallpaper.* tidak ada
    val mark: List<Color>,   // dua warna khas untuk layar pemuatan
)

val themePacks = listOf(
    ThemePack(
        "reef", "Dasar Laut",
        Palette(
            listOf(Color(0xFF38BDF8), Color(0xFF0369A1)), Color(0xE6EAF7FF), Color(0xE6E6F6FF), Color(0xF2F0FAFF),
            Color(0xFF0B3A66), Color(0xFF4F7FA3), Color(0xFF0284C7), Color(0x330B3A66),
        ),
        Color(0xFF38BDF8), Chrome.SOFT, Scene.REEF, listOf(Color(0xFFFACC15), Color(0xFF0369A1)),
    ),
    ThemePack(
        "stage", "Panggung Biru",
        Palette(
            listOf(Color(0xFF93C5FD), Color(0xFFDBEAFE)), Color(0xE6EAF2FF), Color(0xE6E8F0FF), Color(0xF2F4F8FF),
            Color(0xFF1E3A8A), Color(0xFF5B72B0), Color(0xFF2F54D6), Color(0x331E3A8A),
        ),
        Color(0xFFC9A227), Chrome.ROYAL, Scene.SKY, listOf(Color(0xFFC9A227), Color(0xFF1E3A8A)),
    ),
    ThemePack(
        "blocks", "Dunia Blok",
        Palette(
            listOf(Color(0xFF1E3A5F), Color(0xFFB45309)), Color(0xF2262A2B), Color(0xFF4A3322), Color(0xFF2B2F31),
            Color(0xFFF2F2F2), Color(0xFFB0B5B8), Color(0xFF5DAE30), Color(0xFF3F4446),
        ),
        Color(0xFF6B4423), Chrome.PIXEL, Scene.VOXEL, listOf(Color(0xFF5DAE30), Color(0xFF6B4423)),
    ),
)

val LocalPack = compositionLocalOf<ThemePack?> { null }

// ---------- Aset gambar paket ----------

object PackAssets {
    private val cache = HashMap<String, ImageBitmap?>()
    private val exts = listOf("png", "webp", "jpg", "jpeg")

    /** Nama ikon yang bisa diganti: icons/<nama>.png */
    val iconKinds = listOf(
        "pc", "files", "browser", "settings", "terminal", "apps", "windows", "widgets", "weather",
        "search", "bell", "signal", "volume", "battery", "chevron",
        "bt", "brush", "account", "time", "shield", "update", "doc", "image",
    )

    /** Null bila berkas tidak ada. Hasil (termasuk "tidak ada") disimpan agar tidak dibaca ulang. */
    fun image(ctx: Context, id: String, name: String, maxDim: Int = 256): ImageBitmap? {
        val key = "$id/$name"
        synchronized(cache) { if (cache.containsKey(key)) return cache[key] }
        val bmp = load(ctx, id, name, maxDim)
        synchronized(cache) { cache[key] = bmp }
        return bmp
    }

    private fun load(ctx: Context, id: String, name: String, maxDim: Int): ImageBitmap? {
        for (e in exts) {
            val path = "themes/$id/$name.$e"
            val b = runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
                var s = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / (s * 2) >= maxDim) s *= 2
                val o = BitmapFactory.Options().apply { inSampleSize = s }
                ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, o) }
            }.getOrNull()
            if (b != null) return b.asImageBitmap()
        }
        return null
    }

    /** Dipanggil di thread IO saat layar pemuatan tema, supaya UI tidak tersendat setelah tema diterapkan. */
    fun preload(ctx: Context, id: String) {
        image(ctx, id, "wallpaper", 2560)
        image(ctx, id, "taskbar", 2560)
        image(ctx, id, "titlebar", 1600)
        iconKinds.forEach { image(ctx, id, "icons/$it") }
    }
}

// ---------- Bingkai jendela dan taskbar ----------

@Composable
fun taskbarModifier(): Modifier {
    val pk = LocalPack.current
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val img = remember(pk?.id) { pk?.let { PackAssets.image(ctx, it.id, "taskbar", 2560) } }
    val paint = if (img != null) Modifier.paint(BitmapPainter(img), contentScale = ContentScale.FillBounds) else Modifier
    return if (pk == null) {
        Modifier.fillMaxWidth().height(52.dp).background(pal.bar)
    } else if (pk.chrome == Chrome.PIXEL) {
        Modifier.fillMaxWidth().height(52.dp).background(pal.bar).then(paint).then(
            if (img == null) Modifier.drawBehind {
                val g = 6.dp.toPx()
                drawRect(Color(0xFF5DAE30), Offset.Zero, Size(size.width, g))
                drawRect(Color(0xFF3F7D20), Offset(0f, g), Size(size.width, 3.dp.toPx()))
            } else Modifier
        )
    } else {
        val s = RoundedCornerShape(26.dp)
        Modifier.fillMaxWidth().padding(horizontal = 8.dp).padding(bottom = 5.dp).height(52.dp)
            .clip(s).background(pal.bar).then(paint).border(1.dp, pk.frame.copy(alpha = .6f), s)
    }
}

@Composable
fun titleBarDeco(): Modifier {
    val pk = LocalPack.current
    val ctx = LocalContext.current
    val img = remember(pk?.id) { pk?.let { PackAssets.image(ctx, it.id, "titlebar", 1600) } }
    return when {
        pk == null -> Modifier
        img != null -> Modifier.paint(BitmapPainter(img), contentScale = ContentScale.FillBounds)
        pk.chrome == Chrome.PIXEL -> Modifier.drawBehind {
            drawRect(Color(0xFF5DAE30), Offset.Zero, Size(size.width, 6.dp.toPx()))
            drawRect(Color(0xFF3F7D20), Offset(0f, 6.dp.toPx()), Size(size.width, 2.dp.toPx()))
        }
        pk.chrome == Chrome.ROYAL -> Modifier.drawBehind {
            val t = 1.5.dp.toPx()
            drawRect(Color(0xFFC9A227).copy(alpha = .8f), Offset(0f, size.height - t), Size(size.width, t))
        }
        else -> Modifier
    }
}

// ---------- Wallpaper paket ----------

@Composable
fun PackWallpaper(pk: ThemePack, time: () -> Float) {
    val ctx = LocalContext.current
    val img = remember(pk.id) { PackAssets.image(ctx, pk.id, "wallpaper", 2560) }
    if (img != null) {
        Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Canvas(Modifier.fillMaxSize()) {
            when (pk.scene) {
                Scene.REEF -> drawReef(time())
                Scene.SKY -> drawSky(time())
                Scene.VOXEL -> drawVoxel(time())
            }
        }
    }
}

private class Bub(val x: Float, val sp: Float, val r: Float, val off: Float, val sw: Float)

private val bubs = Random(3).let { r ->
    List(30) { Bub(r.nextFloat(), .5f + r.nextFloat(), 3f + r.nextFloat() * 9f, r.nextFloat(), .5f + r.nextFloat()) }
}

private fun DrawScope.drawReef(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF7DD3FC), Color(0xFF0EA5E9), Color(0xFF0369A1))))
    for (i in 0 until 4) {
        val x0 = w * (.1f + i * .24f) + w * .03f * sin(t * .3f + i)
        val ray = Path().apply {
            moveTo(x0, 0f); lineTo(x0 + w * .08f, 0f); lineTo(x0 + w * .22f, h); lineTo(x0 + w * .02f, h); close()
        }
        drawPath(ray, Color(0x14FFFFFF))
    }
    bubs.forEach { b ->
        val p = (b.off + t * b.sp * .05f) % 1f
        val y = h * (1.05f - p * 1.15f)
        val x = b.x * w + sin(t * b.sw + b.off * 6f) * 10f * u
        val r = b.r * u
        drawCircle(Color(0x22FFFFFF), r, Offset(x, y))
        drawCircle(Color(0x66FFFFFF), r, Offset(x, y), style = Stroke(1.2f * u))
        drawCircle(Color(0x99FFFFFF), r * .22f, Offset(x - r * .35f, y - r * .35f))
    }
    drawOval(Color(0xFFF2D18A), Offset(-w * .1f, h * .86f), Size(w * 1.2f, h * .4f))
    drawOval(Color(0xFFE6BF72), Offset(w * .2f, h * .93f), Size(w * .9f, h * .3f))
    for (i in 0 until 9) {
        val bx = w * (.04f + i * .115f)
        val sway = sin(t * .9f + i) * 10f * u
        val blade = Path().apply {
            moveTo(bx, h * .93f)
            quadraticBezierTo(bx + sway, h * .83f, bx + sway * 1.6f, h * .74f - (i % 3) * h * .03f)
        }
        drawPath(blade, Color(0xFF15803D), style = Stroke(4f * u, cap = StrokeCap.Round))
    }
}

private class Cloud(val x: Float, val y: Float, val s: Float, val sp: Float)

private val clouds = listOf(
    Cloud(.0f, .12f, 1f, .008f), Cloud(.3f, .28f, .8f, .011f), Cloud(.55f, .08f, 1.2f, .007f),
    Cloud(.8f, .22f, .9f, .010f), Cloud(.15f, .50f, .7f, .012f),
)

private fun DrawScope.drawSky(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF60A5FA), Color(0xFFBFDBFE), Color(0xFFEFF6FF))))
    clouds.forEach { c ->
        val x = ((c.x + t * c.sp) % 1.5f - .25f) * w
        val y = h * c.y
        drawOval(Color(0xD9FFFFFF), Offset(x, y), Size(w * .18f * c.s, h * .07f * c.s))
        drawOval(Color(0xD9FFFFFF), Offset(x + w * .05f * c.s, y - h * .035f * c.s), Size(w * .12f * c.s, h * .07f * c.s))
        drawOval(Color(0xB3FFFFFF), Offset(x + w * .09f * c.s, y + h * .01f * c.s), Size(w * .14f * c.s, h * .05f * c.s))
    }
    // Gelembung bening melayang dan kilau emas.
    bubs.forEachIndexed { i, b ->
        val p = (b.off + t * b.sp * .03f) % 1f
        val y = h * (1.05f - p * 1.15f)
        val x = b.x * w + sin(t * b.sw * .6f + b.off * 6f) * 12f * u
        val r = b.r * u * 1.3f
        drawCircle(Color(0x1FFFFFFF), r, Offset(x, y))
        drawCircle(Color(0x77FFFFFF), r, Offset(x, y), style = Stroke(1.2f * u))
        if (i % 4 == 0) {
            val a = .3f + .7f * (.5f + .5f * sin(t * 2f + b.off * 9f))
            drawCircle(Color(0xFFFDE68A).copy(alpha = a), 2f * u, Offset(w - x * .6f, y * .8f))
        }
    }
}

private fun DrawScope.drawVoxel(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF1D3F8F), Color(0xFF6D5BB0), Color(0xFFF59E0B), Color(0xFFFDBA74))))
    val sun = Offset(w * .58f, h * .42f)
    drawCircle(Brush.radialGradient(listOf(Color(0x88FFD79A), Color.Transparent), center = sun, radius = h * .4f), h * .4f, sun)
    drawRect(Color(0xFFFFF1B0), Offset(sun.x - h * .07f, sun.y - h * .07f), Size(h * .14f, h * .14f))
    for (i in 0 until 6) {
        val x = ((i * .21f + t * .004f * (1f + i % 3)) % 1.3f - .15f) * w
        drawRect(Color(0x66FFB38A), Offset(x, h * (.08f + (i % 3) * .1f)), Size(w * .12f, h * .04f))
        drawRect(Color(0x44FFFFFF), Offset(x + w * .02f, h * (.08f + (i % 3) * .1f) - h * .02f), Size(w * .07f, h * .025f))
    }
    drawRect(Color(0xFF1B3A66), Offset(0f, h * .66f), Size(w, h * .2f))
    drawRect(Color(0x55FDBA74), Offset(sun.x - h * .05f, h * .66f), Size(h * .1f, h * .2f))
    val b = 14f * u
    var x = 0f
    while (x < w) {
        val n = sin(x / w * 5f) + sin(x / w * 11f + 1f)
        val y = (h * .8f - ((n * h * .04f) / b).toInt() * b)
        drawRect(Color(0xFF6B4423), Offset(x, y + b), Size(b, h - y))
        drawRect(Color(0xFF4C8C2A), Offset(x, y), Size(b, b))
        drawRect(Color(0xFF6BBF3A), Offset(x, y), Size(b, b * .4f))
        x += b
    }
}

// ---------- Layar pemuatan saat ganti tema sistem ----------

private fun DrawScope.drawEmblem(pk: ThemePack, phase: Float) {
    val u = size.minDimension
    val c = center
    when (pk.chrome) {
        Chrome.SOFT -> {
            for (i in 0 until 5) {
                rotate(i * 72f + phase * 2f, c) {
                    drawOval(pk.mark[0].copy(alpha = .9f), Offset(c.x - u * .09f, c.y - u * .44f), Size(u * .18f, u * .36f))
                }
            }
            drawCircle(pk.mark[1], u * .1f, c)
        }
        Chrome.ROYAL -> {
            val crown = Path().apply {
                moveTo(u * .14f, u * .72f); lineTo(u * .1f, u * .3f); lineTo(u * .3f, u * .5f); lineTo(u * .5f, u * .2f)
                lineTo(u * .7f, u * .5f); lineTo(u * .9f, u * .3f); lineTo(u * .86f, u * .72f); close()
            }
            drawPath(crown, Brush.verticalGradient(listOf(pk.mark[0], Color(0xFFFFE9A6), pk.mark[0])))
            drawRect(pk.mark[1], Offset(u * .14f, u * .72f), Size(u * .72f, u * .1f))
            drawCircle(Color(0xFF60A5FA), u * .04f, Offset(u * .5f, u * .6f))
        }
        Chrome.PIXEL -> {
            val cell = u * .17f
            val x0 = c.x - cell * 2.5f
            val y0 = c.y - cell * 2.5f
            for (y in 0 until 5) for (x in 0 until 5) {
                val col = if (y < 2) {
                    if ((x + y) % 2 == 0) Color(0xFF5DAE30) else Color(0xFF4C8C2A)
                } else {
                    if ((x * 3 + y) % 3 == 0) Color(0xFF6B4423) else Color(0xFF8B5A2B)
                }
                drawRect(col, Offset(x0 + x * cell, y0 + y * cell), Size(cell, cell))
            }
        }
    }
}

/** Menutupi layar, memuat aset paket, menerapkan tema di balik layar, lalu memudar. */
@Composable
fun ThemeLoadingOverlay(state: DesktopState) {
    val ctx = LocalContext.current
    val target = themePacks.find { it.id == state.packTarget }
    var progress by remember { mutableStateOf(0f) }
    var step by remember { mutableStateOf("") }
    LaunchedEffect(state.packBusy) {
        if (!state.packBusy) return@LaunchedEffect
        progress = 0f
        delay(350) // tunggu layar tertutup penuh
        step = "Memuat ikon"; progress = .2f
        target?.let { withContext(Dispatchers.IO) { PackAssets.preload(ctx, it.id) } }
        delay(300)
        step = "Menyiapkan wallpaper"; progress = .45f; delay(350)
        step = "Menyusun jendela"; progress = .7f
        state.commitPack(); delay(350)
        step = "Menerapkan taskbar"; progress = .9f; delay(350)
        step = "Selesai"; progress = 1f; delay(400)
        state.packBusy = false
    }
    AnimatedVisibility(visible = state.packBusy, enter = fadeIn(tween(300)), exit = fadeOut(tween(450))) {
        val mark = target?.mark ?: listOf(Color(0xFF60CDFF), Color(0xFF8B5CF6))
        val inf = rememberInfiniteTransition(label = "packLoad")
        val bob by inf.animateFloat(
            initialValue = -6f, targetValue = 6f,
            animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "bob",
        )
        val p by animateFloatAsState(progress, tween(350), label = "packProgress")
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF050A14), lerp(Color(0xFF050A14), mark[1], .5f))))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(130.dp).graphicsLayer { translationY = bob }, contentAlignment = Alignment.Center) {
                    if (target == null) Glyph("windows", 100.dp, mark[0])
                    else Canvas(Modifier.fillMaxSize()) { drawEmblem(target, bob) }
                }
                Spacer(Modifier.height(16.dp))
                Text("Menerapkan tema", color = Color(0xFFA0A0A8), fontSize = 13.sp)
                Text(
                    target?.label ?: "Klasik", color = Color.White,
                    fontSize = 22.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp,
                )
                Spacer(Modifier.height(24.dp))
                Box(Modifier.width(220.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x22FFFFFF))) {
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(p.coerceIn(0f, 1f))
                            .background(Brush.horizontalGradient(listOf(mark[0], mark[1])))
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(step, color = Color(0xFFA0A0A8), fontSize = 13.sp)
            }
        }
    }
}
