package com.example.desktoplauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.view.TextureView
import android.widget.ImageView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Mengelola berkas wallpaper milik pengguna di penyimpanan internal aplikasi. */
object WallpaperFiles {
    private val videoExt = setOf("mp4", "webm", "mkv", "3gp", "mov", "m4v")

    fun dir(ctx: Context): File = File(ctx.filesDir, "wallpapers").apply { mkdirs() }

    fun kind(f: File): String = if (f.extension.lowercase() in videoExt) "video" else "image"

    fun list(ctx: Context): List<File> =
        (dir(ctx).listFiles()?.toList() ?: emptyList()).filter { it.isFile }.sortedByDescending { it.lastModified() }

    fun delete(ctx: Context, f: File) {
        f.delete()
        File(File(ctx.filesDir, "wallpaper_thumbs"), f.name + ".jpg").delete()
    }

    /** Salin berkas pilihan pengguna ke penyimpanan aplikasi. Mengembalikan nama berkas, atau null jika gagal. */
    suspend fun importFrom(ctx: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val cr = ctx.contentResolver
            val display = cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "wallpaper"
            val safe = display.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            val d = dir(ctx)
            val name = if (File(d, safe).exists()) System.currentTimeMillis().toString() + "_" + safe else safe
            File(d, name).outputStream().use { out ->
                cr.openInputStream(uri)!!.use { it.copyTo(out) }
            }
            name
        }.getOrNull()
    }

    fun decodeScaled(f: File, maxDim: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= maxDim && o.outHeight / (s * 2) >= maxDim) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    /** Thumbnail kecil (disimpan sebagai cache) untuk daftar di Pengaturan. */
    suspend fun thumbnail(ctx: Context, f: File): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val tdir = File(ctx.filesDir, "wallpaper_thumbs").apply { mkdirs() }
            val tf = File(tdir, f.name + ".jpg")
            if (tf.exists() && tf.lastModified() >= f.lastModified()) return@runCatching BitmapFactory.decodeFile(tf.path)
            val bmp: Bitmap? = if (kind(f) == "video") {
                val r = MediaMetadataRetriever()
                try { r.setDataSource(f.path); r.getFrameAtTime(0) } finally { r.release() }
            } else decodeScaled(f, 480)
            bmp?.let { b ->
                val sc = 320f / b.width
                val small = if (sc < 1f) Bitmap.createScaledBitmap(b, 320, (b.height * sc).toInt().coerceAtLeast(1), true) else b
                tf.outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                small
            }
        }.getOrNull()
    }
}

/** Wallpaper dari berkas pengguna: video (looping, tanpa suara), GIF/WebP animasi, atau gambar. */
@Composable
fun CustomWallpaper(name: String?, running: Boolean) {
    val ctx = LocalContext.current
    val file = remember(name) { if (name.isNullOrEmpty()) null else File(WallpaperFiles.dir(ctx), name) }
    if (file == null || !file.exists()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF030814), Color(0xFF0A1B3D)))))
        return
    }
    key(file.absolutePath) {
        if (WallpaperFiles.kind(file) == "video") VideoWallpaper(file, running) else ImageWallpaper(file, running)
    }
}

@Composable
private fun VideoWallpaper(f: File, running: Boolean) {
    val ctx = LocalContext.current
    val player = remember(f.absolutePath) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(f)))
            repeatMode = Player.REPEAT_MODE_ALL
            volume = 0f
            trackSelectionParameters = trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
            prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    // Jeda saat tidak terlihat (window layar penuh, aplikasi di latar, atau animasi dimatikan).
    LaunchedEffect(running, player) { player.playWhenReady = running }

    AndroidView(
        factory = { c ->
            TextureView(c).also { tv ->
                var vw = 0
                var vh = 0
                // Isi layar tanpa memelintir gambar (center-crop).
                fun crop() {
                    if (vw <= 0 || vh <= 0 || tv.width <= 0 || tv.height <= 0) return
                    val va = vw.toFloat() / vh
                    val ta = tv.width.toFloat() / tv.height
                    val m = Matrix()
                    if (va > ta) m.setScale(va / ta, 1f, tv.width / 2f, tv.height / 2f)
                    else m.setScale(1f, ta / va, tv.width / 2f, tv.height / 2f)
                    tv.setTransform(m)
                }
                player.setVideoTextureView(tv)
                player.addListener(object : Player.Listener {
                    override fun onVideoSizeChanged(videoSize: VideoSize) {
                        vw = (videoSize.width * videoSize.pixelWidthHeightRatio).toInt()
                        vh = videoSize.height
                        crop()
                    }
                })
                tv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> crop() }
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}

private fun loadDrawable(ctx: Context, f: File): Drawable? = runCatching {
    if (Build.VERSION.SDK_INT >= 28) {
        ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
            val m = maxOf(info.size.width, info.size.height)
            if (m > 1920) {
                val sc = 1920f / m
                dec.setTargetSize((info.size.width * sc).toInt(), (info.size.height * sc).toInt())
            }
        }.also { d -> if (d is AnimatedImageDrawable) d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE }
    } else {
        WallpaperFiles.decodeScaled(f, 1920)?.let { BitmapDrawable(ctx.resources, it) }
    }
}.getOrNull()

@Composable
private fun ImageWallpaper(f: File, running: Boolean) {
    val ctx = LocalContext.current
    val drawable = remember(f.absolutePath) { loadDrawable(ctx, f) }
    AndroidView(
        factory = { c ->
            ImageView(c).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageDrawable(drawable)
            }
        },
        update = { iv ->
            if (Build.VERSION.SDK_INT >= 28) {
                (iv.drawable as? AnimatedImageDrawable)?.let {
                    if (running) { if (!it.isRunning) it.start() } else it.stop()
                }
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}
