package com.example.desktoplauncher

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlin.math.roundToInt

private data class Tile(val emoji: String, val label: String, val on: Boolean, val action: () -> Unit)


/** Panel kanan: pengaturan cepat, slider volume/kecerahan, dan daftar notifikasi. */
@Composable
fun QuickPanel(state: DesktopState, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    AnimatedVisibility(
        visible = state.panel == Panel.NOTIF,
        modifier = modifier,
        enter = fadeIn(tween(150)) + slideInHorizontally(spring(stiffness = Spring.StiffnessMediumLow)) { it / 4 },
        exit = fadeOut(tween(120)) + slideOutHorizontally(tween(150)) { it / 4 },
    ) {
        val ctx = LocalContext.current
        val shape = RoundedCornerShape(18.dp)
        val dark = state.theme != ThemeMode.LIGHT && state.theme != ThemeMode.MINIMAL
        val granted = remember { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }

        val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
        val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
        var vol by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
        val act = remember { ctx.findActivity() }
        var bright by remember {
            mutableStateOf(act?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.7f)
        }

        val tiles = listOf(
            Tile("📶", "Internet", false) { ctx.launch(internetIntent()) },
            Tile("🔵", "Bluetooth", false) { ctx.launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            Tile("✈️", "Pesawat", false) { ctx.launch(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) },
            Tile("🌙", "Mode gelap", dark) { state.changeTheme(if (dark) ThemeMode.LIGHT else ThemeMode.DARK) },
            Tile("🖥️", "Layar", false) { ctx.launch(Intent(Settings.ACTION_DISPLAY_SETTINGS)) },
            Tile("🔋", "Baterai", false) { ctx.launch(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) },
        )

        Column(
            Modifier.padding(8.dp).width(340.dp).fillMaxHeight()
                .clip(shape).background(pal.panel).border(1.dp, pal.line, shape)
                .verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Pengaturan cepat", color = pal.text, fontWeight = FontWeight.SemiBold)
            tiles.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { t -> TileView(t, Modifier.weight(1f)) }
                }
            }
            SliderRow("🔊", vol, 0f..maxVol.toFloat()) { v ->
                vol = v
                runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, v.roundToInt(), 0) }
            }
            SliderRow("☀️", bright, 0.05f..1f) { v ->
                bright = v
                act?.window?.let { w -> w.attributes = w.attributes.also { a -> a.screenBrightness = v } }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Notifikasi", color = pal.text, fontWeight = FontWeight.SemiBold)
                if (granted && NotificationStore.items.isNotEmpty()) {
                    Text(
                        "Hapus semua", color = pal.accent, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { NotificationStore.dismissAll() }.padding(6.dp),
                    )
                }
            }
            if (!granted) {
                Text("Izinkan akses notifikasi agar launcher bisa menampilkannya.", color = pal.sub, fontSize = 13.sp)
                Button(
                    onClick = { ctx.launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                    colors = ButtonDefaults.buttonColors(containerColor = pal.accent, contentColor = Color.Black),
                ) { Text("Izinkan akses") }
            } else if (NotificationStore.items.isEmpty()) {
                Text("Tidak ada notifikasi", color = pal.sub, fontSize = 13.sp)
            } else {
                NotificationStore.items.forEach { n -> key(n.key) { NotifCard(n) } }
            }
        }
    }
}

@Composable
private fun TileView(t: Tile, modifier: Modifier) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier.clip(shape)
            .background(if (t.on) pal.accent.copy(alpha = .18f) else pal.line)
            .border(1.dp, if (t.on) pal.accent else Color.Transparent, shape)
            .clickable(onClick = t.action).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(t.emoji, fontSize = 20.sp)
        Text(t.label, color = if (t.on) pal.accent else pal.text, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun SliderRow(icon: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    val pal = LocalPalette.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 18.sp)
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            modifier = Modifier.weight(1f).padding(start = 8.dp),
            colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent, inactiveTrackColor = pal.line),
        )
    }
}

@Composable
private fun NotifCard(n: NotifItem) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(pal.window).border(1.dp, pal.line, shape)
            .clickable { n.intent?.let { runCatching { it.send() } } }
            .padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(n.app, color = pal.sub, fontSize = 11.sp, maxLines = 1)
            if (n.title.isNotEmpty()) Text(n.title, color = pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (n.text.isNotEmpty()) Text(n.text, color = pal.sub, fontSize = 13.sp, maxLines = 2)
        }
        Text(
            "×", color = pal.sub, fontSize = 20.sp,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { NotificationStore.dismiss(n.key) }.padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}
