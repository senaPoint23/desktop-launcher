package com.example.desktoplauncher

import android.content.Context
import android.graphics.SurfaceTexture
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/** Sesi aplikasi pihak ketiga yang berjalan di layar virtual, ditampilkan di jendela desktop. */
object VirtualApps {
    const val VW = 1280
    const val VH = 720
    const val DPI = 240

    private class Session(val pkg: String) {
        var displayId = -1
        var launched = false
        var surface: Surface? = null
    }

    private val sessions = HashMap<String, Session>()
    private val main = Handler(Looper.getMainLooper())

    private fun component(ctx: Context, pkg: String): String =
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString() ?: pkg

    fun attach(ctx: Context, key: String, pkg: String, surface: Surface, onMsg: (String) -> Unit) {
        val svc = ShizukuBridge.service
        if (svc == null) { onMsg("Shizuku belum terhubung"); return }
        val s = sessions.getOrPut(key) { Session(pkg) }
        s.surface = surface
        val comp = component(ctx, pkg)
        onMsg("Menyiapkan layar virtual…")
        Thread {
            val m: String = runCatching {
                if (s.displayId < 0) {
                    s.displayId = svc.createDisplay(surface, VW, VH, DPI, "desktop-$pkg")
                    if (s.displayId < 0) return@runCatching "Gagal membuat layar virtual: " + svc.lastError()
                } else {
                    svc.setDisplaySurface(s.displayId, surface)
                }
                if (!s.launched) {
                    val out = svc.startActivity(s.displayId, comp)
                    s.launched = true
                    if (out.contains("Error", ignoreCase = true)) "Gagal membuka aplikasi: $out" else ""
                } else ""
            }.getOrElse { "Kesalahan: ${it.message}" }
            main.post { onMsg(m) }
        }.start()
    }

    /** Window di-minimize: lepas Surface, aplikasi tetap hidup di layar virtual. */
    fun detach(key: String) {
        val s = sessions[key] ?: return
        val svc = ShizukuBridge.service
        val id = s.displayId
        if (svc != null && id >= 0) Thread { runCatching { svc.setDisplaySurface(id, null) } }.start()
        s.surface?.release()
        s.surface = null
    }

    fun release(key: String) {
        val s = sessions.remove(key) ?: return
        val svc = ShizukuBridge.service
        val id = s.displayId
        if (svc != null && id >= 0) Thread { runCatching { svc.releaseDisplay(id) } }.start()
        s.surface?.release()
    }

    fun touch(key: String, ev: MotionEvent, vw: Int, vh: Int) {
        val s = sessions[key] ?: return
        val svc = ShizukuBridge.service ?: return
        if (s.displayId < 0 || vw <= 0 || vh <= 0) return
        val n = ev.pointerCount
        val ids = IntArray(n) { ev.getPointerId(it) }
        val xs = FloatArray(n) { ev.getX(it) * VW / vw }
        val ys = FloatArray(n) { ev.getY(it) * VH / vh }
        runCatching { svc.injectTouch(s.displayId, ev.action, n, ids, xs, ys, ev.downTime, ev.eventTime) }
    }

    fun key(key: String, code: Int) {
        val s = sessions[key] ?: return
        val svc = ShizukuBridge.service ?: return
        if (s.displayId < 0) return
        runCatching {
            svc.injectKey(s.displayId, code, true)
            svc.injectKey(s.displayId, code, false)
        }
    }

    fun relaunch(ctx: Context, key: String) {
        val s = sessions[key] ?: return
        val svc = ShizukuBridge.service ?: return
        if (s.displayId < 0) return
        val comp = component(ctx, s.pkg)
        Thread { runCatching { svc.startActivity(s.displayId, comp) } }.start()
    }
}

@Composable
fun VirtualAppWindow(pkg: String) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val key = "vd:$pkg"
    var msg by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Chip("Kembali") { VirtualApps.key(key, KeyEvent.KEYCODE_BACK) }
            Chip("Buka ulang") { VirtualApps.relaunch(ctx, key) }
            Text("Layar virtual 1280×720", color = pal.sub, fontSize = 11.sp, modifier = Modifier.padding(start = 4.dp))
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(top = 6.dp).background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(
                factory = { c ->
                    TextureView(c).apply {
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                                st.setDefaultBufferSize(VirtualApps.VW, VirtualApps.VH)
                                VirtualApps.attach(ctx, key, pkg, Surface(st)) { m -> msg = m }
                            }

                            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}

                            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                                VirtualApps.detach(key)
                                return true
                            }

                            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                        }
                        setOnTouchListener { v, ev ->
                            VirtualApps.touch(key, ev, v.width, v.height)
                            true
                        }
                    }
                },
                modifier = Modifier.aspectRatio(VirtualApps.VW.toFloat() / VirtualApps.VH),
            )
            if (msg.isNotEmpty()) {
                Text(msg, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(12.dp))
            }
        }
    }
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Text(
        label, color = pal.text, fontSize = 12.sp, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(pal.text.copy(alpha = .08f))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}
