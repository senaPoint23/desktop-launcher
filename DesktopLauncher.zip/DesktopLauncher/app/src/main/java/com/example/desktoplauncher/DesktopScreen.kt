package com.example.desktoplauncher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private data class DeskIcon(val id: String, val label: String, val emoji: String)

private val deskIcons = listOf(
    DeskIcon("files", "Files", "📁"),
    DeskIcon("settings", "Settings", "⚙️"),
    DeskIcon("apps", "Apps", "📱"),
)

@Composable
fun DesktopScreen(state: DesktopState) {
    val pal = paletteFor(state.theme)
    val ctx = LocalContext.current
    val installed = remember { AppRepository.load(ctx.packageManager, ctx.packageName) }

    // Launcher tidak boleh keluar saat Back: tutup menu, lalu minimize window aktif.
    BackHandler {
        if (state.startOpen) state.startOpen = false
        else state.activeId?.let { state.minimize(it) }
    }

    CompositionLocalProvider(LocalPalette provides pal) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(pal.wallpaper))) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    val d = LocalDensityScale()
                    deskIcons.forEachIndexed { i, ic ->
                        DeskIconView(ic, androidx.compose.ui.geometry.Offset(12f * d, (12f + i * 92f) * d), state) {
                            if (ic.id == "apps") state.startOpen = true
                            else state.open(ic.id, ic.label, ic.emoji)
                        }
                    }
                    for (w in state.windows) key(w.id) { WindowFrame(w, state) }
                    if (state.startOpen) {
                        Box(
                            Modifier.fillMaxSize().clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { state.startOpen = false }
                        )
                    }
                    StartMenu(state, installed, Modifier.align(Alignment.BottomStart))
                }
                Taskbar(state)
            }
        }
    }
}

@Composable
private fun LocalDensityScale(): Float = androidx.compose.ui.platform.LocalDensity.current.density

@Composable
private fun DeskIconView(
    icon: DeskIcon,
    default: androidx.compose.ui.geometry.Offset,
    state: DesktopState,
    onOpen: () -> Unit,
) {
    var off by remember {
        mutableStateOf(state.prefs.pos(icon.id)?.let { androidx.compose.ui.geometry.Offset(it.first, it.second) } ?: default)
    }
    Column(
        Modifier
            .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
            .width(76.dp)
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = { state.prefs.savePos(icon.id, off.x, off.y) }) { c, d ->
                    c.consume(); off += d
                }
            }
            .clickable(onClick = onOpen)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .18f)),
            contentAlignment = Alignment.Center,
        ) { Text(icon.emoji, fontSize = 28.sp) }
        Spacer(Modifier.height(4.dp))
        Text(icon.label, color = Color.White, fontSize = 12.sp, maxLines = 1)
    }
}
