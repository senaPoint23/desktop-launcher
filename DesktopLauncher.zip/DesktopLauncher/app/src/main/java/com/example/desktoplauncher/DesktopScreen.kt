package com.example.desktoplauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import android.os.SystemClock
import androidx.compose.ui.input.pointer.PointerEventPass
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private data class DeskIcon(val id: String, val label: String)

private val deskIcons = listOf(
    DeskIcon("pc", "PC Ini"),
    DeskIcon("files", "Files"),
    DeskIcon("settings", "Pengaturan"),
    DeskIcon("terminal", "Terminal"),
    DeskIcon("apps", "Aplikasi"),
)

@Composable
fun DesktopScreen(state: DesktopState) {
    val pal = animatePalette(paletteFor(state.theme))
    val ctx = LocalContext.current
    // Proses masuk: muat daftar aplikasi lalu tampilkan layar pemuatan (minimal ~2 detik, hanya sekali).
    var installed by remember { mutableStateOf(emptyList<AppInfo>()) }
    var progress by remember { mutableStateOf(if (state.booted) 1f else 0.1f) }
    var bootLabel by remember { mutableStateOf("Menyiapkan tampilan") }
    LaunchedEffect(Unit) {
        val t0 = SystemClock.elapsedRealtime()
        installed = withContext(Dispatchers.IO) { AppRepository.load(ctx.packageManager, ctx.packageName) }
        if (!state.booted) {
            bootLabel = "Memuat aplikasi"; progress = 0.5f; delay(500)
            bootLabel = "Menyiapkan wallpaper"; progress = 0.8f; delay(500)
            bootLabel = "Hampir selesai"; progress = 1f
            val left = 2200L - (SystemClock.elapsedRealtime() - t0)
            if (left > 0) delay(left)
            state.booted = true
            state.touch()
        }
    }
    // Kunci layar otomatis saat tidak disentuh selama waktu yang diatur.
    LaunchedEffect(state.idleSec, state.locked, state.inForeground, state.booted) {
        while (state.idleSec > 0 && !state.locked && state.inForeground && state.booted) {
            delay(1000)
            if (state.idleMs() >= state.idleSec * 1000L) state.lock()
        }
    }

    // Launcher tidak boleh keluar saat Back: tutup menu, lalu minimize window aktif.
    BackHandler {
        if (state.locked) state.unlock()
        else if (state.startOpen || state.panel != Panel.NONE || state.menuAt != null) state.closeOverlays()
        else state.activeId?.let { state.minimize(it) }
    }

    // Skala UI dari Pengaturan > Tampilan > Skala.
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(base.density * state.uiScale, base.fontScale),
        LocalPalette provides pal,
    ) {
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                // Setiap sentuhan mereset waktu diam (tanpa mengonsumsi event).
                awaitPointerEventScope {
                    while (true) { awaitPointerEvent(PointerEventPass.Initial); state.touch() }
                }
            }
        ) {
            // Wallpaper berganti dengan crossfade saat tema diubah.
            // Animasi dijeda otomatis saat ada window layar penuh (hemat baterai).
            val live = state.wallAnim && state.inForeground &&
                (state.locked || state.windows.none { it.maximized && !it.minimized && !it.closing })
            Crossfade(
                targetState = WKey(state.wallpaper, if (state.wallpaper == WallpaperStyle.TEMA) state.theme else null,
                    if (state.wallpaper == WallpaperStyle.SAYA) state.customWall else null),
                animationSpec = tween(450), label = "wallpaper",
            ) { k -> Wallpaper(k, live) }
            // Saat terkunci, desktop disembunyikan sehingga hanya wallpaper dan jam yang terlihat.
            val uiAlpha by animateFloatAsState(if (state.locked) 0f else 1f, tween(400), label = "uiAlpha")
            Column(Modifier.fillMaxSize().graphicsLayer { alpha = uiAlpha }.systemBarsPadding()) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().displayCutoutPadding()) {
                    val d = LocalDensity.current.density
                    SideEffect {
                        state.density = d
                        state.areaW = maxWidth.value
                        state.areaH = maxHeight.value
                    }
                    // Tahan area kosong desktop untuk membuka menu konteks.
                    Box(
                        Modifier.fillMaxSize().pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { o -> state.closeOverlays(); state.menuAt = o },
                                onTap = { state.closeOverlays() },
                            )
                        }
                    )
                    ClockWidget(state, Modifier.align(Alignment.TopEnd).padding(16.dp))
                    // Ikon mengisi kolom ke bawah, lalu pindah ke kolom berikutnya.
                    val rows = ((maxHeight.value - 12f) / 100f).toInt().coerceAtLeast(1)
                    deskIcons.forEachIndexed { i, ic ->
                        DeskIconView(
                            ic, i,
                            Offset((8f + (i / rows) * 92f) * d, (8f + (i % rows) * 100f) * d),
                            state,
                        ) {
                            if (ic.id == "apps") state.startOpen = true
                            else AppRepository.internal.find { it.pkg == ic.id }
                                ?.let { state.open(it.pkg, it.label, it.emoji ?: "") }
                        }
                    }
                    for (w in state.windows) key(w.id) { WindowFrame(w, state) }
                    if (state.startOpen || state.panel != Panel.NONE || state.menuAt != null) {
                        Box(
                            Modifier.fillMaxSize().clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { state.closeOverlays() }
                        )
                    }
                    StartMenu(state, installed, Modifier.align(Alignment.BottomCenter))
                    QuickPanel(state, Modifier.align(Alignment.CenterEnd))
                    WidgetsPanel(state, Modifier.align(Alignment.CenterStart))
                    CalendarPopup(state, Modifier.align(Alignment.BottomEnd))
                    DesktopContextMenu(state)
                }
                Taskbar(state)
            }
            LockScreen(state)
            BootScreen(visible = !state.booted, progress = progress, label = bootLabel)
        }
    }
}

@Composable
private fun DeskIconView(
    icon: DeskIcon,
    index: Int,
    default: Offset,
    state: DesktopState,
    onOpen: () -> Unit,
) {
    var off by remember(state.arrangeKey) {
        mutableStateOf(state.prefs.pos(icon.id)?.let { Offset(it.first, it.second) } ?: default)
    }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 70L); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(350), label = "appear")

    Column(
        Modifier
            .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
            .graphicsLayer { alpha = a; translationY = (1f - a) * 40f; scaleX = press; scaleY = press }
            .width(84.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (pressed) Color.White.copy(alpha = .14f) else Color.Transparent)
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = { state.prefs.savePos(icon.id, off.x, off.y) }) { c, d ->
                    c.consume(); off += d
                }
            }
            .clickable(interactionSource = src, indication = null, onClick = onOpen)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Glyph(icon.id, 48.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            icon.label, color = Color.White, fontSize = 12.sp, maxLines = 1,
            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = .7f), Offset(0f, 2f), 6f)),
        )
    }
}
