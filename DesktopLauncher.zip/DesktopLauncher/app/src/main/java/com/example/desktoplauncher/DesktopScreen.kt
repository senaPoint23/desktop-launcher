package com.example.desktoplauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private data class DeskIcon(val id: String, val label: String, val emoji: String)

private val deskIcons = listOf(
    DeskIcon("files", "Files", "📁"),
    DeskIcon("settings", "Settings", "⚙️"),
    DeskIcon("apps", "Apps", "📱"),
)

@Composable
fun DesktopScreen(state: DesktopState) {
    val pal = animatePalette(paletteFor(state.theme))
    val ctx = LocalContext.current
    val installed = remember { AppRepository.load(ctx.packageManager, ctx.packageName) }

    // Launcher tidak boleh keluar saat Back: tutup menu, lalu minimize window aktif.
    BackHandler {
        if (state.startOpen || state.panel != Panel.NONE || state.menuAt != null) state.closeOverlays()
        else state.activeId?.let { state.minimize(it) }
    }

    CompositionLocalProvider(LocalPalette provides pal) {
        Box(Modifier.fillMaxSize()) {
            // Wallpaper berganti dengan crossfade saat tema diubah.
            Crossfade(targetState = state.theme, animationSpec = tween(450), label = "wallpaper") { t ->
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(paletteFor(t).wallpaper)))
            }
            Column(Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding()) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val d = LocalDensity.current.density
                    SideEffect {
                        state.density = d
                        state.areaW = maxWidth.value
                        state.areaH = maxHeight.value
                    }
                    // Tahan area kosong desktop untuk membuka menu konteks.
                    Box(
                        Modifier.fillMaxSize().pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { o -> state.closeOverlays(); state.menuAt = o },
                                onTap = { state.closeOverlays() },
                            )
                        }
                    )
                    ClockWidget(state, Modifier.align(Alignment.TopEnd).padding(16.dp))
                    // Ikon mengisi kolom ke bawah, lalu pindah ke kolom berikutnya (cocok untuk landscape).
                    val rows = ((maxHeight.value - 12f) / 92f).toInt().coerceAtLeast(1)
                    deskIcons.forEachIndexed { i, ic ->
                        DeskIconView(
                            ic, i,
                            Offset((12f + (i / rows) * 84f) * d, (12f + (i % rows) * 92f) * d),
                            state,
                        ) {
                            if (ic.id == "apps") state.startOpen = true
                            else state.open(ic.id, ic.label, ic.emoji)
                        }
                    }
                    for (w in state.windows) key(w.id) { WindowFrame(w, state) }
                    if (state.startOpen || state.panel != Panel.NONE || state.menuAt != null) {
                        Box(
                            Modifier.fillMaxSize().clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { state.closeOverlays() }
                        )
                    }
                    StartMenu(state, installed, Modifier.align(Alignment.BottomStart))
                    QuickPanel(state, Modifier.align(Alignment.CenterEnd))
                    CalendarPopup(state, Modifier.align(Alignment.BottomEnd))
                    DesktopContextMenu(state)
                }
                Taskbar(state)
            }
        }
    }
}

@Composable
private fun DeskIconView(
    icon: DeskIcon,
    index: Int,
    default: Offset,
    state: DesktopState,
    onOpen: () -> Unit,
) {
    var off by remember(state.arrangeKey) {
        mutableStateOf(state.prefs.pos(icon.id)?.let { Offset(it.first, it.second) } ?: default)
    }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(
        if (pressed) 0.92f else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 70L); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(350), label = "appear")

    Column(
        Modifier
            .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
            .graphicsLayer { alpha = a; translationY = (1f - a) * 40f; scaleX = press; scaleY = press }
            .width(76.dp)
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = { state.prefs.savePos(icon.id, off.x, off.y) }) { c, d ->
                    c.consume(); off += d
                }
            }
            .clickable(interactionSource = src, indication = null, onClick = onOpen)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .18f)),
            contentAlignment = Alignment.Center,
        ) { Text(icon.emoji, fontSize = 28.sp) }
        Spacer(Modifier.height(4.dp))
        Text(icon.label, color = Color.White, fontSize = 12.sp, maxLines = 1)
    }
}
