package com.example.desktoplauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private data class DeskIcon(val id: String, val label: String)

private val deskIcons = listOf(
    DeskIcon("pc", "PC Ini"),
    DeskIcon("files", "Files"),
    DeskIcon("settings", "Pengaturan"),
    DeskIcon("terminal", "Terminal"),
    DeskIcon("apps", "Aplikasi"),
)

@Composable
fun DesktopScreen(state: DesktopState) {
    val pal = animatePalette(paletteFor(state.theme))
    val ctx = LocalContext.current
    val installed = remember { AppRepository.load(ctx.packageManager, ctx.packageName) }

    // Launcher tidak boleh keluar saat Back: tutup menu, lalu minimize window aktif.
    BackHandler {
        if (state.startOpen || state.panel != Panel.NONE || state.menuAt != null) state.closeOverlays()
        else state.activeId?.let { state.minimize(it) }
    }

    // Skala UI dari Pengaturan > Tampilan > Skala.
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(base.density * state.uiScale, base.fontScale),
        LocalPalette provides pal,
    ) {
        Box(Modifier.fillMaxSize()) {
            // Wallpaper berganti dengan crossfade saat tema diubah.
            // Animasi dijeda otomatis saat ada window layar penuh (hemat baterai).
            val live = state.wallAnim && state.inForeground && state.windows.none { it.maximized && !it.minimized && !it.closing }
            Crossfade(
                targetState = WKey(state.wallpaper, if (state.wallpaper == WallpaperStyle.TEMA) state.theme else null,
                    if (state.wallpaper == WallpaperStyle.SAYA) state.customWall else null),
                animationSpec = tween(450), label = "wallpaper",
            ) { k -> Wallpaper(k, live) }
            Column(Modifier.fillMaxSize().systemBarsPadding().displayCutoutPadding()) {
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val d = LocalDensity.current.density
                    SideEffect {
                        state.density = d
                        state.areaW = maxWidth.value
                        state.areaH = maxHeight.value
                    }
                    // Tahan area kosong desktop untuk membuka menu konteks.
                    Box(
                        Modifier.fillMaxSize().pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { o -> state.closeOverlays(); state.menuAt = o },
                                onTap = { state.closeOverlays() },
                            )
                        }
                    )
                    ClockWidget(state, Modifier.align(Alignment.TopEnd).padding(16.dp))
                    // Ikon mengisi kolom ke bawah, lalu pindah ke kolom berikutnya.
                    val rows = ((maxHeight.value - 12f) / 100f).toInt().coerceAtLeast(1)
                    deskIcons.forEachIndexed { i, ic ->
                        DeskIconView(
                            ic, i,
                            Offset((8f + (i / rows) * 92f) * d, (8f + (i % rows) * 100f) * d),
                            state,
                        ) {
                            if (ic.id == "apps") state.startOpen = true
                            else AppRepository.internal.find { it.pkg == ic.id }
                                ?.let { state.open(it.pkg, it.label, it.emoji ?: "") }
                        }
                    }
                    for (w in state.windows) key(w.id) { WindowFrame(w, state) }
                    if (state.startOpen || state.panel != Panel.NONE || state.menuAt != null) {
                        Box(
                            Modifier.fillMaxSize().clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { state.closeOverlays() }
                        )
                    }
                    StartMenu(state, installed, Modifier.align(Alignment.BottomCenter))
                    QuickPanel(state, Modifier.align(Alignment.CenterEnd))
                    CalendarPopup(state, Modifier.align(Alignment.BottomEnd))
                    DesktopContextMenu(state)
                }
                Taskbar(state)
            }
        }
    }
}

@Composable
private fun DeskIconView(
    icon: DeskIcon,
    index: Int,
    default: Offset,
    state: DesktopState,
    onOpen: () -> Unit,
) {
    var off by remember(state.arrangeKey) {
        mutableStateOf(state.prefs.pos(icon.id)?.let { Offset(it.first, it.second) } ?: default)
    }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 70L); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(350), label = "appear")

    Column(
        Modifier
            .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
            .graphicsLayer { alpha = a; translationY = (1f - a) * 40f; scaleX = press; scaleY = press }
            .width(84.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (pressed) Color.White.copy(alpha = .14f) else Color.Transparent)
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = { state.prefs.savePos(icon.id, off.x, off.y) }) { c, d ->
                    c.consume(); off += d
                }
            }
            .clickable(interactionSource = src, indication = null, onClick = onOpen)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Glyph(icon.id, 48.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            icon.label, color = Color.White, fontSize = 12.sp, maxLines = 1,
            style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = .7f), Offset(0f, 2f), 6f)),
        )
    }
}
