package com.example.desktoplauncher

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel

/** Satu window di desktop. x/y dalam px, w/h dalam dp. */
class Win(val id: String, val title: String, val emoji: String, val seq: Int, x: Float, y: Float) {
    var x by mutableStateOf(x)
    var y by mutableStateOf(y)
    var w by mutableStateOf(320f)
    var h by mutableStateOf(380f)
    var minimized by mutableStateOf(false)
    var maximized by mutableStateOf(false)
}

class DesktopState(val prefs: Prefs) {
    /** Urutan list = urutan z (terakhir = paling depan). */
    val windows = mutableStateListOf<Win>()
    var activeId by mutableStateOf<String?>(null)
    var startOpen by mutableStateOf(false)
    var theme by mutableStateOf(prefs.theme)
    private var seq = 0

    fun open(id: String, title: String, emoji: String) {
        startOpen = false
        val ex = windows.find { it.id == id }
        if (ex != null) { ex.minimized = false; focus(id); return }
        val off = windows.size * 64f
        windows.add(Win(id, title, emoji, seq++, 96f + off, 120f + off))
        activeId = id
    }

    fun focus(id: String) {
        val w = windows.find { it.id == id } ?: return
        if (windows.last() !== w) { windows.remove(w); windows.add(w) }
        activeId = id
    }

    fun minimize(id: String) {
        windows.find { it.id == id }?.minimized = true
        if (activeId == id) activeId = null
    }

    fun close(id: String) {
        windows.removeAll { it.id == id }
        if (activeId == id) activeId = null
    }

    /** Ketuk ikon di taskbar: restore -> fokus -> minimize. */
    fun toggle(id: String) {
        val w = windows.find { it.id == id } ?: return
        when {
            w.minimized -> { w.minimized = false; focus(id) }
            activeId == id -> minimize(id)
            else -> focus(id)
        }
    }

    fun setTheme(m: ThemeMode) { theme = m; prefs.theme = m }
}

class DesktopViewModel(app: Application) : AndroidViewModel(app) {
    val state = DesktopState(Prefs(app))
}
