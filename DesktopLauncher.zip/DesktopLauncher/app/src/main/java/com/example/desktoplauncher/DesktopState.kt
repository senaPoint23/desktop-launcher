package com.example.desktoplauncher

import android.app.Application
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel

enum class Panel { NONE, NOTIF, CALENDAR }

/** Satu window di desktop. x/y dalam px, w/h dalam dp. */
class Win(val id: String, val title: String, val emoji: String, val seq: Int, x: Float, y: Float, w: Float, h: Float) {
    var x by mutableStateOf(x)
    var y by mutableStateOf(y)
    var w by mutableStateOf(w)
    var h by mutableStateOf(h)
    var minimized by mutableStateOf(false)
    var maximized by mutableStateOf(false)
    var closing by mutableStateOf(false)
}

class DesktopState(val prefs: Prefs) {
    /** Urutan list = urutan z (terakhir = paling depan). */
    val windows = mutableStateListOf<Win>()
    var activeId by mutableStateOf<String?>(null)
    var startOpen by mutableStateOf(false)
    var theme by mutableStateOf(prefs.theme)

    var panel by mutableStateOf(Panel.NONE)
    var menuAt by mutableStateOf<Offset?>(null)
    var arrangeKey by mutableStateOf(0)
    var widgetOn by mutableStateOf(prefs.widget)

    // Ukuran area desktop (dp) dan density, diisi oleh DesktopScreen.
    var density = 1f
    var areaW by mutableStateOf(0f)
    var areaH by mutableStateOf(0f)
    private var seq = 0

    fun closeOverlays() { startOpen = false; panel = Panel.NONE; menuAt = null }

    fun openPanel(p: Panel) {
        val next = if (panel == p) Panel.NONE else p
        closeOverlays()
        panel = next
    }

    fun open(id: String, title: String, emoji: String) {
        closeOverlays()
        val ex = windows.find { it.id == id }
        if (ex != null) { ex.closing = false; ex.minimized = false; focus(id); return }
        val n = windows.size % 6
        val w = (areaW * 0.6f).coerceIn(300f, 640f).coerceAtMost(areaW.coerceAtLeast(300f))
        val h = (areaH * 0.82f).coerceIn(200f, 480f)
        windows.add(Win(id, title, emoji, seq++, (24f + n * 28f) * density, (12f + n * 24f) * density, w, h))
        activeId = id
    }

    fun focus(id: String) {
        val w = windows.find { it.id == id } ?: return
        if (windows.last() !== w) { windows.remove(w); windows.add(w) }
        activeId = id
    }

    fun minimize(id: String) {
        windows.find { it.id == id }?.minimized = true
        if (activeId == id) activeId = null
    }

    /** Menandai window menutup; WindowFrame menghapusnya setelah animasi selesai. */
    fun close(id: String) {
        windows.find { it.id == id }?.closing = true
        if (activeId == id) activeId = null
    }

    fun remove(w: Win) { windows.remove(w) }

    /** Ketuk ikon di taskbar: restore -> fokus -> minimize. */
    fun toggle(id: String) {
        val w = windows.find { it.id == id } ?: return
        when {
            w.minimized -> { w.minimized = false; focus(id) }
            activeId == id -> minimize(id)
            else -> focus(id)
        }
    }

    fun changeTheme(m: ThemeMode) { theme = m; prefs.theme = m }

    fun setWidget(v: Boolean) { widgetOn = v; prefs.widget = v }

    fun arrangeIcons() {
        prefs.clearPos(listOf("files", "settings", "apps"))
        arrangeKey++
    }
}

class DesktopViewModel(app: Application) : AndroidViewModel(app) {
    val state = DesktopState(Prefs(app))
}
