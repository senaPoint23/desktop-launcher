package com.example.desktoplauncher

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel

enum class Panel { NONE, NOTIF, CALENDAR, WIDGETS }

/** Satu window di desktop. x/y dalam px, w/h dalam dp. */
class Win(val id: String, val title: String, val emoji: String, val seq: Int, x: Float, y: Float, w: Float, h: Float) {
    var x by mutableStateOf(x)
    var y by mutableStateOf(y)
    var w by mutableStateOf(w)
    var h by mutableStateOf(h)
    var minimized by mutableStateOf(false)
    var maximized by mutableStateOf(false)
    var closing by mutableStateOf(false)
    var snapped by mutableStateOf(false)
    var prevW = 320f
    var prevH = 380f
}

class DesktopState(val prefs: Prefs) {
    /** Urutan list = urutan z (terakhir = paling depan). */
    val windows = mutableStateListOf<Win>()
    var activeId by mutableStateOf<String?>(null)
    var startOpen by mutableStateOf(false)
    var theme by mutableStateOf(prefs.theme)

    // Tema sistem (paket): null = tampilan klasik. packTarget = tujuan selama layar pemuatan berjalan.
    var pack by mutableStateOf(themePacks.find { it.id == prefs.pack })
    var packTarget by mutableStateOf<String?>(null)
    var packBusy by mutableStateOf(false)
    var iconModern by mutableStateOf(prefs.iconModern)

    var panel by mutableStateOf(Panel.NONE)
    var menuAt by mutableStateOf<Offset?>(null)
    var appMenu by mutableStateOf<AppMenu?>(null)
    var arrangeKey by mutableStateOf(0)
    var widgetOn by mutableStateOf(prefs.widget)

    // Pengaturan Tampilan
    var uiScale by mutableStateOf(prefs.uiScale)
    var wallpaper by mutableStateOf(runCatching { WallpaperStyle.valueOf(prefs.wallpaper) }.getOrDefault(WallpaperStyle.BLOOM))
    var wallAnim by mutableStateOf(prefs.wallAnim)
    var customWall by mutableStateOf(prefs.customWall)
    var inForeground by mutableStateOf(true)

    // Layar kunci otomatis dan layar pemuatan
    var locked by mutableStateOf(false)
    var booted by mutableStateOf(false)
    var showWelcome by mutableStateOf(false)
    var idleSec by mutableStateOf(prefs.idleSec)

    // Aplikasi terpasang yang disematkan, dan pilihan jendela mengambang
    val deskPins = mutableStateListOf<String>().apply { addAll(prefs.deskPins) }
    val taskPins = mutableStateListOf<String>().apply { addAll(prefs.taskPins) }
    var floatApps by mutableStateOf(prefs.floatApps)
    var shizukuWin by mutableStateOf(prefs.shizukuWin)
    private var lastTouch = SystemClock.elapsedRealtime()
    var orient by mutableStateOf(prefs.orient)
    var rotLock by mutableStateOf(prefs.rotLock)
    var hideNav by mutableStateOf(prefs.hideNav)
    var hideStatus by mutableStateOf(prefs.hideStatus)

    // Ukuran area desktop (dp) dan density, diisi oleh DesktopScreen.
    var density = 1f
    var areaW by mutableStateOf(0f)
    var areaH by mutableStateOf(0f)
    private var seq = 0

    fun touch() { lastTouch = SystemClock.elapsedRealtime() }

    fun pinDesktop(pkg: String) {
        if (pkg !in deskPins) { deskPins.add(pkg); prefs.deskPins = deskPins.toList() }
    }
    fun unpinDesktop(pkg: String) {
        deskPins.remove(pkg); prefs.deskPins = deskPins.toList(); prefs.clearPos(listOf("app:$pkg"))
    }
    fun pinTaskbar(pkg: String) {
        if (pkg !in taskPins) { taskPins.add(pkg); prefs.taskPins = taskPins.toList() }
    }
    fun unpinTaskbar(pkg: String) { taskPins.remove(pkg); prefs.taskPins = taskPins.toList() }
    fun updateFloat(v: Boolean) { floatApps = v; prefs.floatApps = v }
    fun updateShizuku(v: Boolean) { shizukuWin = v; prefs.shizukuWin = v }

    private var hiddenIds: List<String> = emptyList()

    /** Tombol di ujung kanan taskbar: sembunyikan semua window; tekan lagi untuk mengembalikan. */
    fun toggleDesktop() {
        closeOverlays()
        val visible = windows.filter { !it.minimized && !it.closing }
        if (visible.isNotEmpty()) {
            hiddenIds = visible.map { it.id }
            visible.forEach { it.minimized = true }
            activeId = null
        } else {
            windows.filter { it.id in hiddenIds }.forEach { it.minimized = false }
            windows.lastOrNull { it.id in hiddenIds }?.let { activeId = it.id }
        }
    }

    /** Dipanggil saat window selesai digeser; (px, py) = posisi jari relatif ke area desktop. */
    fun snapIfNeeded(w: Win, px: Float, py: Float) {
        val edge = 18f * density
        when {
            py < edge -> { w.snapped = false; w.maximized = true }
            px < edge -> snap(w, 0f, areaW / 2)
            px > areaW * density - edge -> snap(w, areaW / 2 * density, areaW / 2)
        }
    }

    private fun snap(w: Win, xPx: Float, widthDp: Float) {
        if (!w.snapped) { w.prevW = w.w; w.prevH = w.h }
        w.snapped = true
        w.x = xPx
        w.y = 0f
        w.w = widthDp
        w.h = areaH
    }
    fun idleMs(): Long = SystemClock.elapsedRealtime() - lastTouch
    fun lock() { closeOverlays(); locked = true }
    fun unlock() { locked = false; touch() }
    fun dismissWelcome() { showWelcome = false; prefs.welcomeSeen = true; touch() }
    fun replayWelcome() { closeOverlays(); showWelcome = true }
    fun updateIdle(v: Int) { idleSec = v; prefs.idleSec = v }

    fun closeOverlays() { startOpen = false; panel = Panel.NONE; menuAt = null; appMenu = null }

    fun openPanel(p: Panel) {
        val next = if (panel == p) Panel.NONE else p
        closeOverlays()
        panel = next
    }

    fun open(id: String, title: String, emoji: String) {
        closeOverlays()
        val ex = windows.find { it.id == id }
        if (ex != null) { ex.closing = false; ex.minimized = false; focus(id); return }
        val n = windows.size % 6
        val wide = id == "browser" || id == "files" || id.startsWith("vd:")
        val w = (areaW * (if (wide) 0.8f else 0.6f)).coerceIn(300f, if (wide) 960f else 640f).coerceAtMost(areaW.coerceAtLeast(300f))
        val h = (areaH * (if (wide) 0.9f else 0.82f)).coerceIn(200f, 560f)
        windows.add(Win(id, title, emoji, seq++, (24f + n * 28f) * density, (12f + n * 24f) * density, w, h))
        activeId = id
    }

    fun focus(id: String) {
        val w = windows.find { it.id == id } ?: return
        if (windows.last() !== w) { windows.remove(w); windows.add(w) }
        activeId = id
    }

    fun minimize(id: String) {
        windows.find { it.id == id }?.minimized = true
        if (activeId == id) activeId = null
    }

    /** Menandai window menutup; WindowFrame menghapusnya setelah animasi selesai. */
    fun close(id: String) {
        windows.find { it.id == id }?.closing = true
        if (activeId == id) activeId = null
    }

    fun remove(w: Win) {
        windows.remove(w)
        if (w.id == "browser") BrowserSession.shutdown()
        if (w.id.startsWith("vd:")) VirtualApps.release(w.id)
    }

    /** Ketuk ikon di taskbar: restore -> fokus -> minimize. */
    fun toggle(id: String) {
        val w = windows.find { it.id == id } ?: return
        when {
            w.minimized -> { w.minimized = false; focus(id) }
            activeId == id -> minimize(id)
            else -> focus(id)
        }
    }

    fun chooseCustom(name: String) {
        customWall = name; prefs.customWall = name
        wallpaper = WallpaperStyle.SAYA; prefs.wallpaper = WallpaperStyle.SAYA.name
    }
    fun chooseWallpaper(w: WallpaperStyle) { wallpaper = w; prefs.wallpaper = w.name }
    fun updateWallAnim(v: Boolean) { wallAnim = v; prefs.wallAnim = v }
    fun setScale(v: Float) { uiScale = v; prefs.uiScale = v }
    fun updateOrient(v: String) { orient = v; prefs.orient = v }
    fun updateRotLock(v: Boolean) { rotLock = v; prefs.rotLock = v }
    fun updateHideNav(v: Boolean) { hideNav = v; prefs.hideNav = v }
    fun updateHideStatus(v: Boolean) { hideStatus = v; prefs.hideStatus = v }

    fun setIconModern(v: Boolean) { iconModern = v; prefs.iconModern = v }
    fun changeTheme(m: ThemeMode) { theme = m; prefs.theme = m }

    /** Mulai layar pemuatan lalu ganti tema sistem; null = kembali ke klasik. */
    fun applyPack(id: String?) {
        if (packBusy || pack?.id == id) return
        closeOverlays()
        packTarget = id
        packBusy = true
    }
    fun commitPack() { pack = themePacks.find { it.id == packTarget }; prefs.pack = packTarget ?: "" }

    fun setWidget(v: Boolean) { widgetOn = v; prefs.widget = v }

    fun arrangeIcons() {
        prefs.clearPos(listOf("pc", "files", "browser", "settings", "terminal", "apps") + deskPins.map { "app:$it" })
        arrangeKey++
    }
}

class DesktopViewModel(app: Application) : AndroidViewModel(app) {
    // Paket tema berbasis theme.json dibaca dulu, sebelum state membaca tema tersimpan.
    val state = run { ThemeRegistry.load(app); DesktopState(Prefs(app)) }
}
