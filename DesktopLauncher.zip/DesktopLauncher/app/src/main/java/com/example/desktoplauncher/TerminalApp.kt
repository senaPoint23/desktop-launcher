package com.example.desktoplauncher

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.OutputStreamWriter

/** Sesi shell (sh) yang tetap hidup selama aplikasi berjalan, sehingga cd dan variabel bertahan. */
object TerminalSession {
    private const val MARK = "__DESKTOP_CWD__"
    val lines = mutableStateListOf<String>()
    var cwd by mutableStateOf("~")
    private var proc: Process? = null
    private var out: OutputStreamWriter? = null
    private var appCtx: Context? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private fun post(s: String) {
        lines.add(s)
        if (lines.size > 2000) repeat(500) { lines.removeAt(0) }
    }

    fun ensure(ctx: Context) {
        appCtx = ctx.applicationContext
        if (proc?.isAlive == true) return
        start()
    }

    private fun start() {
        val ctx = appCtx ?: return
        runCatching {
            val home = ctx.filesDir
            val dir = if (FileOps.hasAccess(ctx)) FileOps.root() else home
            val pb = ProcessBuilder("sh").directory(dir).redirectErrorStream(true)
            pb.environment()["HOME"] = home.absolutePath
            pb.environment()["TERM"] = "dumb"
            val p = pb.start()
            proc = p
            out = OutputStreamWriter(p.outputStream)
            post("Desktop Terminal (sh). Contoh: ls, pwd, uname -a, cat /proc/cpuinfo")
            scope.launch {
                runCatching {
                    p.inputStream.bufferedReader().forEachLine { line ->
                        if (line.startsWith(MARK)) cwd = line.removePrefix(MARK) else post(line)
                    }
                }
                post("[sesi berakhir]")
            }
            send("echo \"$MARK\$PWD\"")
        }.onFailure { post("Gagal memulai shell: ${it.message}") }
    }

    private fun send(cmd: String) {
        val w = out ?: return
        scope.launch { runCatching { w.write(cmd + "\n"); w.flush() } }
    }

    fun run(cmd: String) {
        if (cmd == "clear") { lines.clear(); return }
        if (proc?.isAlive != true) start()
        post("$cwd $ $cmd")
        send(cmd)
        send("echo \"$MARK\$PWD\"")
    }

    /** Hentikan sesi (termasuk proses yang menggantung) lalu mulai shell baru. */
    fun restart() {
        proc?.destroyForcibly()
        proc = null
        post("[sesi dihentikan, memulai ulang]")
        start()
    }
}

@Composable
fun TerminalApp() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { TerminalSession.ensure(ctx) }
    val lines = TerminalSession.lines
    val listState = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) listState.scrollToItem(lines.size - 1) }

    var input by remember { mutableStateOf("") }
    val history = remember { mutableStateListOf<String>() }
    var hIdx by remember { mutableStateOf(-1) }

    fun submit() {
        val c = input.trim()
        if (c.isEmpty()) return
        history.add(c)
        input = ""
        hIdx = -1
        TerminalSession.run(c)
    }

    val mono = FontFamily.Monospace
    Column(
        Modifier.fillMaxSize().clip(RoundedCornerShape(6.dp)).background(Color(0xFF0C0C0C)).padding(8.dp),
    ) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            items(lines.size) { i ->
                Text(lines[i], color = Color(0xFFE6E6E6), fontFamily = mono, fontSize = 12.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(TerminalSession.cwd.takeLast(22) + " $", color = Color(0xFF6BDB6B), fontFamily = mono, fontSize = 12.sp)
            BasicTextField(
                value = input,
                onValueChange = { input = it; hIdx = -1 },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontFamily = mono, fontSize = 12.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() }),
                modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
            )
            KeyBtn("↑") {
                if (history.isNotEmpty()) {
                    hIdx = if (hIdx < 0) history.size - 1 else (hIdx - 1).coerceAtLeast(0)
                    input = history[hIdx]
                }
            }
            KeyBtn("Stop") { TerminalSession.restart() }
        }
    }
}

@Composable
private fun KeyBtn(label: String, onClick: () -> Unit) {
    Text(
        label, color = Color(0xFFE6E6E6), fontSize = 12.sp,
        modifier = Modifier.padding(start = 4.dp).clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF2A2A2A)).clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp),
    )
}
