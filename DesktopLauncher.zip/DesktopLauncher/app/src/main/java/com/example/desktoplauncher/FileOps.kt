package com.example.desktoplauncher

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

/** Operasi berkas untuk File Manager (memakai akses semua file, bukan SAF). */
object FileOps {
    fun root(): File = Environment.getExternalStorageDirectory()

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun places(): List<Pair<String, File>> = listOf(
        "Beranda" to root(),
        "Unduhan" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Dokumen" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
        "Gambar" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
        "Kamera" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
        "Musik" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
        "Video" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
    ).filter { it.first == "Beranda" || it.second.exists() }

    /** Folder dulu, lalu nama; berkas tersembunyi (diawali titik) tidak ditampilkan. */
    fun list(dir: File): List<File> =
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { !it.name.startsWith(".") }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))

    fun uniqueChild(dir: File, base: String): File {
        var f = File(dir, base)
        var i = 2
        while (f.exists()) { f = File(dir, "$base $i"); i++ }
        return f
    }

    private fun copyName(dir: File, src: File): File {
        val first = File(dir, src.name)
        if (!first.exists()) return first
        val ext = if (src.isFile && src.extension.isNotEmpty()) "." + src.extension else ""
        val stem = if (ext.isEmpty()) src.name else src.nameWithoutExtension
        var i = 1
        while (true) {
            val f = File(dir, "$stem - Salinan" + (if (i > 1) " $i" else "") + ext)
            if (!f.exists()) return f
            i++
        }
    }

    /** Salin atau pindahkan [src] ke folder [dir]. Mengembalikan false jika gagal. */
    fun paste(src: File, dir: File, cut: Boolean): Boolean = runCatching {
        if (cut && src.parentFile == dir) return@runCatching false
        if (src.isDirectory && dir.canonicalPath.startsWith(src.canonicalPath)) return@runCatching false
        val dest = copyName(dir, src)
        if (cut) {
            if (!src.renameTo(dest)) {
                src.copyRecursively(dest, false)
                src.deleteRecursively()
            }
        } else {
            src.copyRecursively(dest, false)
        }
        true
    }.getOrDefault(false)

    fun open(ctx: Context, f: File) {
        runCatching {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    fun isImage(f: File): Boolean = f.extension.lowercase() in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
}
