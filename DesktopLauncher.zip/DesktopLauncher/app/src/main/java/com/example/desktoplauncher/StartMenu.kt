package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput

@Composable
fun StartMenu(state: DesktopState, installed: List<AppInfo>, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    AnimatedVisibility(
        visible = state.startOpen,
        modifier = modifier,
        enter = fadeIn(tween(160)) + slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it / 5 } +
            scaleIn(tween(200), initialScale = 0.94f, transformOrigin = TransformOrigin(0.5f, 1f)),
        exit = fadeOut(tween(120)) + slideOutVertically(tween(150)) { it / 6 } +
            scaleOut(tween(150), targetScale = 0.96f, transformOrigin = TransformOrigin(0.5f, 1f)),
    ) {
        var q by remember { mutableStateOf("") }
        var actions by remember { mutableStateOf<AppInfo?>(null) }
        val list = remember(q, installed) {
            (AppRepository.internal + installed).filter { it.label.contains(q.trim(), ignoreCase = true) }
        }
        val shape = RoundedCornerShape(18.dp)
        Column(
            Modifier.padding(8.dp).widthIn(max = 440.dp).fillMaxWidth(0.95f).fillMaxHeight(0.85f)
                .clip(shape).background(pal.panel).border(1.dp, pal.line, shape).padding(14.dp)
        ) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Cari aplikasi dan file") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = pal.text, unfocusedTextColor = pal.text,
                    focusedBorderColor = pal.accent, unfocusedBorderColor = pal.line,
                    cursorColor = pal.accent,
                    focusedPlaceholderColor = pal.sub, unfocusedPlaceholderColor = pal.sub,
                ),
            )
            LazyVerticalGrid(GridCells.Adaptive(84.dp), Modifier.weight(1f).padding(top = 10.dp)) {
                items(list, key = { it.pkg }) { app ->
                    AppTile(app, state, onLong = { if (app.emoji == null) actions = app })
                }
            }
            actions?.let { AppActions(it, state) { actions = null } }
        }
    }
}

@Composable
private fun AppTile(app: AppInfo, state: DesktopState, onLong: () -> Unit) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    // Ikon dimuat saat tile tampil (LazyGrid), jadi RAM tetap rendah.
    val icon = remember(app.pkg) {
        if (app.emoji != null) null
        else runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).pointerInput(app.pkg) {
            detectTapGestures(
                onTap = {
                    if (app.emoji != null) state.open(app.pkg, app.label, app.emoji)
                    else AppLauncher.launch(ctx, state, app.pkg)
                },
                onLongPress = { onLong() },
            )
        }.padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (app.emoji != null) Glyph(app.pkg, 40.dp)
        else if (icon != null) Image(icon, contentDescription = null, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(4.dp))
        Text(app.label, color = pal.text, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

/** Aksi untuk aplikasi yang ditahan di Start Menu: sematkan ke desktop/taskbar, info aplikasi. */
@Composable
private fun AppActions(app: AppInfo, state: DesktopState, onDone: () -> Unit) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val onDesk = app.pkg in state.deskPins
    val onTask = app.pkg in state.taskPins
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(app.label, color = pal.sub, fontSize = 12.sp, maxLines = 1)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            ActionChip(if (onDesk) "Lepas dari desktop" else "Sematkan ke desktop") {
                if (onDesk) state.unpinDesktop(app.pkg) else state.pinDesktop(app.pkg)
                onDone()
            }
            ActionChip(if (onTask) "Lepas dari taskbar" else "Sematkan ke taskbar") {
                if (onTask) state.unpinTaskbar(app.pkg) else state.pinTaskbar(app.pkg)
                onDone()
            }
            ActionChip("Info aplikasi") {
                ctx.launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
                onDone()
            }
            ActionChip("Batal") { onDone() }
        }
    }
}

@Composable
private fun ActionChip(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Text(
        label, color = pal.text, fontSize = 12.sp, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(pal.text.copy(alpha = .08f))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 7.dp),
    )
}
