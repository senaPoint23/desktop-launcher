package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

@Composable
fun StartMenu(state: DesktopState, installed: List<AppInfo>, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    AnimatedVisibility(
        visible = state.startOpen,
        modifier = modifier,
        enter = fadeIn(tween(180)) + slideInHorizontally(tween(180)) { -it / 10 },
        exit = fadeOut(tween(120)) + slideOutHorizontally(tween(120)) { -it / 10 },
    ) {
        var q by remember { mutableStateOf("") }
        val list = remember(q, installed) {
            (AppRepository.internal + installed).filter { it.label.contains(q.trim(), ignoreCase = true) }
        }
        val shape = RoundedCornerShape(18.dp)
        Column(
            Modifier.padding(8.dp).widthIn(max = 380.dp).fillMaxWidth(0.95f).fillMaxHeight(0.75f)
                .clip(shape).background(pal.panel).border(1.dp, pal.line, shape).padding(14.dp)
        ) {
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                placeholder = { Text("Cari aplikasi dan file") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = pal.text, unfocusedTextColor = pal.text,
                    focusedBorderColor = pal.accent, unfocusedBorderColor = pal.line,
                    cursorColor = pal.accent,
                    focusedPlaceholderColor = pal.sub, unfocusedPlaceholderColor = pal.sub,
                ),
            )
            LazyVerticalGrid(GridCells.Adaptive(84.dp), Modifier.weight(1f).padding(top = 10.dp)) {
                items(list, key = { it.pkg }) { app -> AppTile(app, state) }
            }
        }
    }
}

@Composable
private fun AppTile(app: AppInfo, state: DesktopState) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    // Ikon dimuat saat tile tampil (LazyGrid), jadi RAM tetap rendah.
    val icon = remember(app.pkg) {
        if (app.emoji != null) null
        else runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable {
            if (app.emoji != null) state.open(app.pkg, app.label, app.emoji)
            else ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let {
                state.startOpen = false
                ctx.startActivity(it)
            }
        }.padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (app.emoji != null) Text(app.emoji, fontSize = 30.sp)
        else if (icon != null) Image(icon, contentDescription = null, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(4.dp))
        Text(app.label, color = pal.text, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}
