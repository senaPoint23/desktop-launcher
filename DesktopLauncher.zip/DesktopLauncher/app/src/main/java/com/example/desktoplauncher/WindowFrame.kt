package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun WindowFrame(w: Win, state: DesktopState) {
    val pal = LocalPalette.current
    val density = LocalDensity.current.density
    val active = state.activeId == w.id
    val shape = RoundedCornerShape(if (w.maximized) 0.dp else 8.dp)

    // Hapus window dari daftar setelah animasi tutup selesai.
    LaunchedEffect(w.closing) {
        if (w.closing) { delay(170); state.remove(w) }
    }

    AnimatedVisibility(
        visible = !w.minimized && !w.closing,
        enter = fadeIn(tween(160)) +
            scaleIn(spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.88f),
        exit = fadeOut(tween(140)) + scaleOut(tween(150), targetScale = 0.9f) +
            slideOutVertically(tween(150)) { it / 4 },
    ) {
        val frame = if (w.maximized) Modifier.fillMaxSize()
        else Modifier.offset { IntOffset(w.x.roundToInt(), w.y.roundToInt()) }.size(w.w.dp, w.h.dp)

        Box(
            frame
                .shadow(if (active) 16.dp else 6.dp, shape)
                .clip(shape)
                .background(pal.window)
                .border(1.dp, if (active) pal.accent.copy(alpha = .5f) else pal.line, shape)
                .pointerInput(Unit) { detectTapGestures(onPress = { state.focus(w.id) }) }
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().height(36.dp).background(pal.panel)
                        .pointerInput(w.maximized) {
                            if (!w.maximized) {
                                var ax = 0f
                                var ay = 0f
                                detectDragGestures(
                                    onDragStart = { o ->
                                        // Menarik window yang menempel ke tepi mengembalikan ukuran semula.
                                        if (w.snapped) {
                                            w.snapped = false
                                            w.w = w.prevW
                                            w.h = w.prevH
                                            w.x = w.x + o.x - w.w * state.density / 2
                                        }
                                        ax = w.x + o.x
                                        ay = w.y + o.y
                                    },
                                    onDragEnd = { state.snapIfNeeded(w, ax, ay) },
                                    onDragCancel = { },
                                ) { c, d ->
                                    c.consume()
                                    w.x += d.x
                                    w.y = (w.y + d.y).coerceAtLeast(0f)
                                    ax += d.x
                                    ay += d.y
                                }
                            }
                        }
                        .pointerInput(Unit) { detectTapGestures(onDoubleTap = { w.maximized = !w.maximized }) }
                        .padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Glyph(w.id, 16.dp, pal.text)
                    Text(
                        w.title, color = pal.text, fontSize = 13.sp, maxLines = 1,
                        modifier = Modifier.weight(1f).padding(start = 8.dp),
                    )
                    CtrlBtn("—", false) { state.minimize(w.id) }
                    CtrlBtn(if (w.maximized) "❐" else "□", false) { w.maximized = !w.maximized }
                    CtrlBtn("✕", true) { state.close(w.id) }
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) { WindowContent(w.id, state) }
            }
            if (!w.maximized) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(28.dp).pointerInput(Unit) {
                        detectDragGestures { c, d ->
                            c.consume()
                            w.w = (w.w + d.x / density).coerceAtLeast(220f)
                            w.h = (w.h + d.y / density).coerceAtLeast(160f)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun CtrlBtn(label: String, danger: Boolean, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val bg = when {
        pressed && danger -> Color(0xFFC42B1C)
        pressed -> pal.text.copy(alpha = .12f)
        else -> Color.Transparent
    }
    Box(
        Modifier.size(46.dp, 36.dp).background(bg)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (pressed && danger) Color.White else pal.text, fontSize = 13.sp) }
}
