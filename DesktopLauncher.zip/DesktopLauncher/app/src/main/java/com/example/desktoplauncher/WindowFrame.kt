package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun WindowFrame(w: Win, state: DesktopState) {
    val pal = LocalPalette.current
    val density = LocalDensity.current.density
    val active = state.activeId == w.id
    val shape = RoundedCornerShape(if (w.maximized) 0.dp else 12.dp)

    // Minimize/restore dan open memakai scale + fade yang singkat.
    AnimatedVisibility(
        visible = !w.minimized,
        enter = fadeIn(tween(150)) + scaleIn(tween(150), initialScale = 0.96f),
        exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.9f),
    ) {
        val frame = if (w.maximized) Modifier.fillMaxSize()
        else Modifier.offset { IntOffset(w.x.roundToInt(), w.y.roundToInt()) }.size(w.w.dp, w.h.dp)

        Box(
            frame
                .shadow(8.dp, shape)
                .clip(shape)
                .background(pal.window)
                .border(1.dp, if (active) pal.accent else pal.line, shape)
                .pointerInput(Unit) { detectTapGestures(onPress = { state.focus(w.id) }) }
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().height(40.dp).background(pal.panel)
                        .pointerInput(w.maximized) {
                            if (!w.maximized) detectDragGestures { c, d ->
                                c.consume(); w.x += d.x; w.y = (w.y + d.y).coerceAtLeast(0f)
                            }
                        }
                        .padding(start = 12.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${w.emoji} ${w.title}", color = pal.text, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
                    CtrlBtn("—") { state.minimize(w.id) }
                    CtrlBtn(if (w.maximized) "❐" else "□") { w.maximized = !w.maximized }
                    CtrlBtn("×") { state.close(w.id) }
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) { WindowContent(w.id, state) }
            }
            if (!w.maximized) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(28.dp).pointerInput(Unit) {
                        detectDragGestures { c, d ->
                            c.consume()
                            w.w = (w.w + d.x / density).coerceAtLeast(220f)
                            w.h = (w.h + d.y / density).coerceAtLeast(160f)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun CtrlBtn(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    Box(
        Modifier.size(34.dp, 30.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = pal.text) }
}
