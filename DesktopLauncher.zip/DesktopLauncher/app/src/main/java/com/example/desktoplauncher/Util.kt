package com.example.desktoplauncher

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Build
import android.provider.Settings

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun Context.launch(i: Intent) { runCatching { startActivity(i) } }

fun internetIntent(): Intent =
    if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
    else Intent(Settings.ACTION_WIRELESS_SETTINGS)
