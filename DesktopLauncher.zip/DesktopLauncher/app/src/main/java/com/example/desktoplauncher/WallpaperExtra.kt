package com.example.desktoplauncher

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// Wallpaper live tambahan: Hujan, Salju, Galaksi, Kunang-kunang, Senja, Synthwave.
// Semua digambar di fase draw dengan waktu t (detik), sama seperti wallpaper lainnya.

// ---------- Hujan ----------
private class Drop(val x: Float, val sp: Float, val len: Float, val off: Float, val a: Float)

private val drops = Random(11).let { r ->
    List(110) { Drop(r.nextFloat(), .7f + r.nextFloat() * .9f, .04f + r.nextFloat() * .06f, r.nextFloat(), .25f + r.nextFloat() * .5f) }
}

internal fun DrawScope.drawRain(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0A1220), Color(0xFF1B2A41))))
    val slant = .12f
    drops.forEach { d ->
        val p = (d.off + t * d.sp * .5f) % 1f
        val y = p * h * 1.15f - h * .1f
        val x = d.x * w + y * slant
        drawLine(
            Color(0xFFBFD7FF).copy(alpha = d.a),
            Offset(x, y), Offset(x + h * d.len * slant, y + h * d.len),
            strokeWidth = 1.5f * u,
        )
    }
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x2260A5FA)), startY = h * .6f, endY = h))
    // Kilat pendek setiap 9 detik.
    val ph = t % 9f
    if (ph < .12f) drawRect(Color.White.copy(alpha = .14f * (1f - ph / .12f)))
}

// ---------- Salju ----------
private class Flake(val x: Float, val sp: Float, val r: Float, val off: Float, val sw: Float, val ph: Float)

private val flakes = Random(5).let { r ->
    List(100) { Flake(r.nextFloat(), .6f + r.nextFloat() * 1.0f, 1f + r.nextFloat() * 2.5f, r.nextFloat(), .4f + r.nextFloat() * 1.2f, r.nextFloat() * 6.28f) }
}

internal fun DrawScope.drawSnow(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1B33), Color(0xFF1E3A5F))))
    flakes.forEach { f ->
        val p = (f.off + t * f.sp * .06f) % 1f
        val y = p * (h + 20f * u) - 10f * u
        val x = f.x * w + sin(t * f.sw + f.ph) * 18f * u
        drawCircle(Color.White.copy(alpha = (.35f + .1f * f.r).coerceAtMost(.95f)), f.r * u, Offset(x, y))
    }
    drawOval(Color(0x24FFFFFF), Offset(-w * .2f, h * .92f), Size(w * 1.4f, h * .3f))
    drawOval(Color(0x18FFFFFF), Offset(w * .3f, h * .95f), Size(w * 1.2f, h * .25f))
}

// ---------- Galaksi ----------
private class Gal(val arm: Int, val r: Float, val jit: Float, val sz: Float, val a: Float)

private val galaxy = Random(23).let { r ->
    List(520) {
        val rr = r.nextFloat().let { v -> v * v }
        Gal(r.nextInt(3), rr, (r.nextFloat() - .5f) * .35f, .6f + r.nextFloat() * 1.6f, .35f + r.nextFloat() * .6f)
    }
}

internal fun DrawScope.drawGalaxy(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    val c = Offset(w * .5f, h * .5f)
    drawRect(Brush.radialGradient(listOf(Color(0xFF1B1038), Color(0xFF03030C)), center = c, radius = w * .7f))
    drawRect(Brush.radialGradient(listOf(Color(0x66C084FC), Color.Transparent), center = c, radius = h * .5f))
    val spin = t * .05f
    val inner = Color(0xFFFFD9A0)
    val outer = Color(0xFF8AB4FF)
    galaxy.forEach { g ->
        val theta = g.arm * 2.0944f + g.r * 5.2f + spin + g.jit
        val rad = g.r * h * .62f
        val px = c.x + cos(theta) * rad * 1.35f
        val py = c.y + sin(theta) * rad * .5f
        drawCircle(lerp(inner, outer, g.r).copy(alpha = g.a * (1f - g.r * .4f)), g.sz * u, Offset(px, py))
    }
    drawCircle(Color(0x33FFFFFF), h * .05f, c)
    drawCircle(Color(0x66FFF3D6), h * .02f, c)
}

// ---------- Kunang-kunang ----------
private class Fly(val x: Float, val y: Float, val fx: Float, val fy: Float, val ph: Float, val r: Float, val sp: Float)

private val flies = Random(31).let { r ->
    List(34) { Fly(.05f + r.nextFloat() * .9f, .1f + r.nextFloat() * .8f, .2f + r.nextFloat() * .3f, .2f + r.nextFloat() * .3f, r.nextFloat() * 6.28f, 1.2f + r.nextFloat() * 1.6f, .8f + r.nextFloat() * 1.4f) }
}

internal fun DrawScope.drawFireflies(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF03120C), Color(0xFF0B2A1A))))
    flies.forEach { f ->
        val cx = w * (f.x + .06f * sin(t * f.fx + f.ph))
        val cy = h * (f.y + .06f * cos(t * f.fy + f.ph * 1.3f))
        val g = .5f + .5f * sin(t * f.sp + f.ph)
        val a = g * g
        val col = Color(0xFFFDE68A)
        val o = Offset(cx, cy)
        drawCircle(col.copy(alpha = .06f * a), f.r * u * 5f, o)
        drawCircle(col.copy(alpha = .16f * a), f.r * u * 2.6f, o)
        drawCircle(col.copy(alpha = .15f + .85f * a), f.r * u, o)
    }
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC020A06)), startY = h * .8f, endY = h))
}

// ---------- Senja ----------
private val cloudBase = listOf(.05f, .35f, .6f, .85f)
private val cloudY = listOf(.18f, .30f, .22f, .36f)
private val cloudSp = listOf(.010f, .014f, .008f, .012f)

internal fun DrawScope.drawSunset(t: Float) {
    val w = size.width
    val h = size.height
    val hor = h * .64f
    drawRect(
        Brush.verticalGradient(
            listOf(Color(0xFF1E1B4B), Color(0xFFBE185D), Color(0xFFFB923C), Color(0xFFFDE68A)),
            startY = 0f, endY = hor,
        )
    )
    val sc = Offset(w * .5f, hor - h * .06f + h * .008f * sin(t * .2f))
    val sr = h * .15f
    drawCircle(Brush.radialGradient(listOf(Color(0x66FDBA74), Color.Transparent), center = sc, radius = h * .5f), h * .5f, sc)
    drawCircle(Brush.verticalGradient(listOf(Color(0xFFFEF08A), Color(0xFFFB923C)), startY = sc.y - sr, endY = sc.y + sr), sr, sc)
    cloudBase.forEachIndexed { i, b ->
        val x = ((b + t * cloudSp[i]) % 1.4f - .2f) * w
        drawOval(Color(0x44FDBA74), Offset(x, h * cloudY[i]), Size(w * .26f, h * .045f))
        drawOval(Color(0x33FFFFFF), Offset(x + w * .04f, h * cloudY[i] - h * .015f), Size(w * .16f, h * .035f))
    }
    fun mountain(base: Float, amp: Float, k: Float, ph: Float, color: Color) {
        val path = Path().apply {
            moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                lineTo(x, h * base + h * amp * (sin(x / w * k + ph) + .5f * sin(x / w * k * 2.3f + ph * 1.7f)))
                x += 10f
            }
            lineTo(w, h)
            close()
        }
        drawPath(path, color)
    }
    mountain(.72f, .05f, 7f, 0f, Color(0xFF2A1240))
    mountain(.82f, .045f, 9f, 2f, Color(0xFF140A24))
}

// ---------- Synthwave ----------
internal fun DrawScope.drawSynthwave(t: Float) {
    val w = size.width
    val h = size.height
    val u = size.minDimension / 380f
    val hor = h * .55f
    val cx = w * .5f
    drawRect(
        Brush.verticalGradient(
            listOf(Color(0xFF14002E), Color(0xFF3B0764), Color(0xFF9D174D)),
            startY = 0f, endY = hor,
        )
    )
    val sr = h * .22f
    drawCircle(Brush.radialGradient(listOf(Color(0x66F472B6), Color.Transparent), center = Offset(cx, hor), radius = h * .55f), h * .55f, Offset(cx, hor))
    drawCircle(Brush.verticalGradient(listOf(Color(0xFFFDE047), Color(0xFFEC4899)), startY = hor - sr, endY = hor + sr), sr, Offset(cx, hor))
    drawRect(Color(0xFF12001F), Offset(0f, hor), Size(w, h - hor))
    // Garis mendatar bergerak mendekat (perspektif), garis tegak mengerucut ke cakrawala.
    val frac = (t * .6f) % 1f
    val n = 14
    for (i in 0 until n) {
        val z = (i + frac) / n
        val y = hor + (h - hor) * z * z
        drawLine(Color(0xFFF0ABFC).copy(alpha = .25f + .6f * z), Offset(0f, y), Offset(w, y), strokeWidth = (1f + 2f * z) * u)
    }
    for (j in -10..10) {
        drawLine(
            Color(0xFFF0ABFC).copy(alpha = .5f),
            Offset(cx + j * w * .012f, hor), Offset(cx + j * w * .12f, h),
            strokeWidth = 1.5f * u,
        )
    }
    drawRect(Brush.verticalGradient(listOf(Color(0x55F472B6), Color.Transparent), startY = hor, endY = hor + h * .12f), Offset(0f, hor), Size(w, h * .12f))
}
