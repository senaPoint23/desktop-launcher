package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/**
 * Muncul saat tidak disentuh: lapisan hitam transparan di atas wallpaper live,
 * dengan jam besar. Ketuk di mana saja untuk membuka.
 */
@Composable
fun LockScreen(state: DesktopState) {
    AnimatedVisibility(
        visible = state.locked,
        enter = fadeIn(tween(500)),
        exit = fadeOut(tween(300)),
    ) {
        val loc = remember { Locale("id", "ID") }
        val time by produceState("") {
            while (true) { value = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm")); delay(1000) }
        }
        val date by produceState("") {
            while (true) { value = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", loc)); delay(30_000) }
        }
        val pulse by rememberInfiniteTransition(label = "hint").animateFloat(
            initialValue = 0.45f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "hintAlpha",
        )
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = .72f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { state.unlock() },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(time, color = Color.White, fontSize = 104.sp, fontWeight = FontWeight.SemiBold)
                Text(date, color = Color.White.copy(alpha = .85f), fontSize = 18.sp)
                Spacer(Modifier.height(22.dp))
                Text("Ketuk untuk membuka", color = Color.White.copy(alpha = pulse), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** Layar pemuatan saat masuk ke launcher: logo, animasi titik berputar, langkah, dan bilah progres. */
@Composable
fun BootScreen(visible: Boolean, progress: Float, label: String) {
    AnimatedVisibility(
        visible = visible,
        exit = fadeOut(tween(600)) + scaleOut(tween(600), targetScale = 1.08f),
    ) {
        val inf = rememberInfiniteTransition(label = "boot")
        val phase by inf.animateFloat(
            initialValue = 0f, targetValue = 8f,
            animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
            label = "spin",
        )
        val breathe by inf.animateFloat(
            initialValue = 0.96f, targetValue = 1.04f,
            animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "breathe",
        )
        val p by animateFloatAsState(progress, tween(400), label = "bootProgress")
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF030814), Color(0xFF0A1B3D))))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.graphicsLayer { scaleX = breathe; scaleY = breathe }) { Glyph("windows", 80.dp) }
                Spacer(Modifier.height(14.dp))
                Text("Desktop Launcher", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.height(16.dp))
                Spinner(phase)
                Spacer(Modifier.height(12.dp))
                Text(label, color = Color(0xFFA0A0A8), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.width(180.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x33FFFFFF))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(p).background(Color(0xFF60CDFF)))
                }
            }
        }
    }
}

/** Delapan titik; satu titik terang berputar dengan ekor memudar (seperti pemuatan Windows). */
@Composable
private fun Spinner(phase: Float) {
    Canvas(Modifier.size(32.dp)) {
        val u = size.minDimension / 32f
        val c = Offset(size.width / 2, size.height / 2)
        for (i in 0 until 8) {
            val ang = Math.toRadians((i * 45f - 90f).toDouble()).toFloat()
            val d = ((phase - i) % 8f + 8f) % 8f
            val a = (1f - d / 8f).coerceIn(0.15f, 1f)
            drawCircle(
                Color.White.copy(alpha = a),
                radius = (1.6f + 1.6f * a) * u,
                center = Offset(c.x + 12f * u * cos(ang), c.y + 12f * u * sin(ang)),
            )
        }
    }
}
