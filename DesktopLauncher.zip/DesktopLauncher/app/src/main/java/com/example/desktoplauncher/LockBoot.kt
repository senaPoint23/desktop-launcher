package com.example.desktoplauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

/**
 * Muncul saat tidak disentuh: lapisan hitam transparan di atas wallpaper live,
 * dengan jam besar. Ketuk di mana saja untuk membuka.
 */
@Composable
fun LockScreen(state: DesktopState) {
    AnimatedVisibility(
        visible = state.locked,
        enter = fadeIn(tween(500)),
        exit = fadeOut(tween(300)),
    ) {
        val loc = remember { Locale("id", "ID") }
        val time by produceState("") {
            while (true) { value = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm")); delay(1000) }
        }
        val date by produceState("") {
            while (true) { value = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", loc)); delay(30_000) }
        }
        val pulse by rememberInfiniteTransition(label = "hint").animateFloat(
            initialValue = 0.45f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "hintAlpha",
        )
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = .72f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { state.unlock() },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(time, color = Color.White, fontSize = 104.sp, fontWeight = FontWeight.SemiBold)
                Text(date, color = Color.White.copy(alpha = .85f), fontSize = 18.sp)
                Spacer(Modifier.height(22.dp))
                Text("Ketuk untuk membuka", color = Color.White.copy(alpha = pulse), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private class Spark(val x: Float, val y: Float, val k: Int, val m: Int, val r: Float, val ph: Float)

/**
 * Layar pemuatan saat masuk ke launcher: logo menyala dengan tiga cincin berputar,
 * partikel yang melayang naik, judul, langkah pemuatan, dan bilah progres bergradien.
 */
@Composable
fun BootScreen(visible: Boolean, progress: Float, label: String) {
    AnimatedVisibility(
        visible = visible,
        exit = fadeOut(tween(700)) + scaleOut(tween(700), targetScale = 1.15f),
    ) {
        val inf = rememberInfiniteTransition(label = "boot")
        // t berulang 0..1 tiap 6 detik; semua gerak memakai kelipatan bulat agar mulus saat mengulang.
        val t = inf.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
            label = "t",
        )
        val pulse = inf.animateFloat(
            initialValue = 0.92f, targetValue = 1.08f,
            animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "pulse",
        )
        val p by animateFloatAsState(progress, tween(500), label = "bootProgress")
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        val intro by animateFloatAsState(if (shown) 1f else 0f, tween(1000, easing = FastOutSlowInEasing), label = "intro")
        val sparks = remember {
            val r = java.util.Random(7)
            List(36) {
                Spark(r.nextFloat(), r.nextFloat(), 1 + r.nextInt(3), 1 + r.nextInt(3), 0.6f + r.nextFloat() * 1.8f, r.nextFloat() * 6.28f)
            }
        }
        val w = (2.0 * PI).toFloat()

        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF030814), Color(0xFF0A1B3D))))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            contentAlignment = Alignment.Center,
        ) {
            // Partikel cahaya yang melayang pelan ke atas dan berkelip.
            Canvas(Modifier.fillMaxSize()) {
                val tt = t.value
                sparks.forEach { sp ->
                    val yy = (((sp.y - tt * sp.k) % 1f) + 1f) % 1f
                    val xx = sp.x + 0.015f * sin(w * tt * sp.m + sp.ph)
                    val a = (0.2f + 0.55f * (0.5f + 0.5f * sin(w * tt * sp.m * 2 + sp.ph))) * intro
                    drawCircle(
                        Color(0xFF9FD8FF).copy(alpha = a),
                        radius = sp.r * density,
                        center = Offset(xx * size.width, yy * size.height),
                    )
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Logo: cahaya lembut, tiga cincin berputar, dan ikon jendela bergradien.
                Canvas(
                    Modifier.size(170.dp).graphicsLayer {
                        val sc = 0.6f + 0.4f * intro
                        scaleX = sc; scaleY = sc; alpha = intro
                    }
                ) {
                    val tt = t.value
                    val pl = pulse.value
                    val u = size.minDimension
                    val c = center

                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0x6660CDFF), Color.Transparent),
                            center = c, radius = u * 0.5f * pl,
                        ),
                        radius = u * 0.5f * pl, center = c,
                    )
                    drawCircle(Color(0x1AFFFFFF), radius = u * 0.46f, center = c, style = Stroke(u * 0.006f))

                    fun ring(rad: Float, start: Float, sweep: Float, color: Color, width: Float) {
                        drawArc(
                            color = color, startAngle = start, sweepAngle = sweep, useCenter = false,
                            topLeft = Offset(c.x - rad, c.y - rad), size = Size(rad * 2, rad * 2),
                            style = Stroke(width, cap = StrokeCap.Round),
                        )
                    }
                    ring(u * 0.46f, tt * 360f, 110f, Color(0xFF60CDFF), u * 0.018f)
                    ring(u * 0.46f, tt * 360f + 180f, 40f, Color(0x8060CDFF), u * 0.018f)
                    ring(u * 0.38f, -tt * 720f, 80f, Color(0xFF8B7CFF), u * 0.016f)
                    ring(u * 0.31f, tt * 1080f, 55f, Color(0xCCFFFFFF), u * 0.014f)

                    // Ikon inti: kotak bulat bergradien dengan empat panel jendela yang berdenyut bergantian.
                    val cs = u * 0.26f * (1f + (pl - 1f) * 0.5f)
                    val tl = Offset(c.x - cs / 2, c.y - cs / 2)
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(Color(0xFF60CDFF), Color(0xFF3B82F6), Color(0xFF8B5CF6)),
                            start = tl, end = Offset(tl.x + cs, tl.y + cs),
                        ),
                        topLeft = tl, size = Size(cs, cs), cornerRadius = CornerRadius(cs * 0.24f),
                    )
                    val pad = cs * 0.2f
                    val gap = cs * 0.06f
                    val ps = (cs - 2 * pad - gap) / 2f
                    for (i in 0 until 4) {
                        val a = 0.55f + 0.45f * (0.5f + 0.5f * sin(w * tt * 3 - i * 0.9f))
                        drawRoundRect(
                            color = Color.White.copy(alpha = a),
                            topLeft = Offset(tl.x + pad + (i % 2) * (ps + gap), tl.y + pad + (i / 2) * (ps + gap)),
                            size = Size(ps, ps), cornerRadius = CornerRadius(ps * 0.18f),
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "DESKTOP LAUNCHER", color = Color.White.copy(alpha = intro),
                    fontSize = 20.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp,
                )
                Text("Developer: Riyo", color = Color(0xFFA0A0A8).copy(alpha = intro), fontSize = 12.sp)
                Spacer(Modifier.height(26.dp))
                Box(Modifier.width(220.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x22FFFFFF))) {
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(p.coerceIn(0f, 1f))
                            .background(Brush.horizontalGradient(listOf(Color(0xFF60CDFF), Color(0xFF8B5CF6))))
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Crossfade(label, animationSpec = tween(300), label = "bootLabel") {
                        Text(it, color = Color(0xFFA0A0A8), fontSize = 13.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("${(p.coerceIn(0f, 1f) * 100).toInt()}%", color = Color(0xFF60CDFF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
