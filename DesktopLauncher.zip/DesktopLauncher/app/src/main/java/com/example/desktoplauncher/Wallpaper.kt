package com.example.desktoplauncher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate

private class Petal(val rot: Float, val dx: Float, val dy: Float, val w: Float, val h: Float, val a: Color, val b: Color)

private val petals = listOf(
    Petal(-30f, -.05f, .05f, 1.00f, .34f, Color(0xD92F6BFF), Color(0xD90A2A9A)),
    Petal(20f, .08f, -.05f, .95f, .30f, Color(0xCC3C8CFF), Color(0xCC1238B5)),
    Petal(75f, 0f, 0f, .90f, .28f, Color(0xB31E5BFF), Color(0xB30A1F70)),
    Petal(-75f, .05f, .10f, .85f, .26f, Color(0xB32B7BFF), Color(0xB30B2480)),
    Petal(-10f, .12f, .08f, .70f, .22f, Color(0x995AA9FF), Color(0x991444C8)),
    Petal(45f, -.10f, -.02f, .60f, .20f, Color(0x8038B6FF), Color(0x800E2C9A)),
)

/** Wallpaper: tema Bloom menggambar bunga biru ala Windows 11, tema lain memakai gradasi. */
@Composable
fun Wallpaper(mode: ThemeMode) {
    if (mode == ThemeMode.BLOOM) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(Brush.verticalGradient(listOf(Color(0xFF030814), Color(0xFF0A1B3D))))
            val c = Offset(w * .55f, h * .5f)
            drawRect(Brush.radialGradient(listOf(Color(0x661D4ED8), Color.Transparent), center = c, radius = h * 1.1f))
            petals.forEach { p ->
                val pc = Offset(c.x + p.dx * h, c.y + p.dy * h)
                val sz = Size(p.w * h, p.h * h)
                val tl = Offset(pc.x - sz.width / 2, pc.y - sz.height / 2)
                rotate(p.rot, pc) {
                    drawOval(Brush.linearGradient(listOf(p.a, p.b), tl, Offset(tl.x + sz.width, tl.y + sz.height)), tl, sz)
                }
            }
        }
    } else {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(paletteFor(mode).wallpaper)))
    }
}
