package com.example.desktoplauncher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class WallpaperStyle(val label: String) {
    BLOOM("Bloom"), AURORA("Aurora"), BINTANG("Bintang"), GELOMBANG("Gelombang"),
    HUJAN("Hujan"), SALJU("Salju"), GALAKSI("Galaksi"), KUNANG("Kunang-kunang"), SENJA("Senja"), SYNTHWAVE("Synthwave"),
    SAYA("Wallpaper saya"), TEMA("Ikuti tema")
}

/** Kunci untuk Crossfade: gaya wallpaper, plus tema jika gaya "Ikuti tema". */
data class WKey(val style: WallpaperStyle, val theme: ThemeMode?, val custom: String? = null, val pack: String? = null)

/**
 * Wallpaper live. Waktu [t] naik ~30 fps hanya saat [running] true,
 * dan digambar di fase draw sehingga tidak merekomposisi UI.
 */
@Composable
fun Wallpaper(k: WKey, running: Boolean) {
    var t by remember { mutableStateOf(0f) }
    LaunchedEffect(running) {
        if (running) {
            var prev = 0L
            while (true) {
                withFrameNanos { n ->
                    if (prev == 0L) prev = n
                    else {
                        val dt = (n - prev) / 1_000_000_000f
                        if (dt >= 0.033f) { t += dt; prev = n }
                    }
                }
            }
        }
    }
    val pk = k.pack?.let { id -> themePacks.find { it.id == id } }
    if (pk != null) PackWallpaper(pk) { t } else when (k.style) {
        WallpaperStyle.BLOOM -> Canvas(Modifier.fillMaxSize()) { drawBloom(t, true) }
        WallpaperStyle.AURORA -> Canvas(Modifier.fillMaxSize()) { drawAurora(t) }
        WallpaperStyle.BINTANG -> Canvas(Modifier.fillMaxSize()) { drawStars(t) }
        WallpaperStyle.GELOMBANG -> Canvas(Modifier.fillMaxSize()) { drawWaves(t) }
        WallpaperStyle.HUJAN -> Canvas(Modifier.fillMaxSize()) { drawRain(t) }
        WallpaperStyle.SALJU -> Canvas(Modifier.fillMaxSize()) { drawSnow(t) }
        WallpaperStyle.GALAKSI -> Canvas(Modifier.fillMaxSize()) { drawGalaxy(t) }
        WallpaperStyle.KUNANG -> Canvas(Modifier.fillMaxSize()) { drawFireflies(t) }
        WallpaperStyle.SENJA -> Canvas(Modifier.fillMaxSize()) { drawSunset(t) }
        WallpaperStyle.SYNTHWAVE -> Canvas(Modifier.fillMaxSize()) { drawSynthwave(t) }
        WallpaperStyle.SAYA -> CustomWallpaper(k.custom, running)
        WallpaperStyle.TEMA ->
            if (k.theme == ThemeMode.BLOOM) Canvas(Modifier.fillMaxSize()) { drawBloom(0f, false) }
            else Box(Modifier.fillMaxSize().background(Brush.linearGradient(paletteFor(k.theme ?: ThemeMode.DARK).wallpaper)))
    }
}

// ---------- Bloom ----------
private class Petal(val rot: Float, val dx: Float, val dy: Float, val w: Float, val h: Float, val a: Color, val b: Color)

private val petals = listOf(
    Petal(-30f, -.05f, .05f, 1.00f, .34f, Color(0xD92F6BFF), Color(0xD90A2A9A)),
    Petal(20f, .08f, -.05f, .95f, .30f, Color(0xCC3C8CFF), Color(0xCC1238B5)),
    Petal(75f, 0f, 0f, .90f, .28f, Color(0xB31E5BFF), Color(0xB30A1F70)),
    Petal(-75f, .05f, .10f, .85f, .26f, Color(0xB32B7BFF), Color(0xB30B2480)),
    Petal(-10f, .12f, .08f, .70f, .22f, Color(0x995AA9FF), Color(0x991444C8)),
    Petal(45f, -.10f, -.02f, .60f, .20f, Color(0x8038B6FF), Color(0x800E2C9A)),
)

private fun DrawScope.drawBloom(t: Float, anim: Boolean) {
    val w = size.width
    val h = size.height
    val k = if (anim) 1f else 0f
    drawRect(Brush.verticalGradient(listOf(Color(0xFF030814), Color(0xFF0A1B3D))))
    val c = Offset(w * .55f + k * w * .01f * sin(t * .12f), h * .5f)
    val glow = h * (1.1f + k * .08f * sin(t * .35f))
    drawRect(Brush.radialGradient(listOf(Color(0x661D4ED8), Color.Transparent), center = c, radius = glow))
    petals.forEachIndexed { i, p ->
        val pc = Offset(c.x + p.dx * h, c.y + p.dy * h)
        val sc = 1f + k * .05f * sin(t * .3f + i)
        val sz = Size(p.w * h * sc, p.h * h * sc)
        val tl = Offset(pc.x - sz.width / 2, pc.y - sz.height / 2)
        rotate(p.rot + k * 10f * sin(t * .18f + i * 1.3f), pc) {
            drawOval(Brush.linearGradient(listOf(p.a, p.b), tl, Offset(tl.x + sz.width, tl.y + sz.height)), tl, sz)
        }
    }
}

// ---------- Aurora ----------
private class Blob(val c: Color, val fx: Float, val fy: Float, val ph: Float, val r: Float)

private val blobs = listOf(
    Blob(Color(0xFF14B8A6), .21f, .17f, 0f, 1.0f),
    Blob(Color(0xFF6366F1), .17f, .23f, 2f, 1.1f),
    Blob(Color(0xFFA855F7), .13f, .19f, 4f, .9f),
    Blob(Color(0xFF22D3EE), .25f, .15f, 5.5f, .8f),
)

private fun DrawScope.drawAurora(t: Float) {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF050B1A), Color(0xFF0B1230))))
    blobs.forEach { b ->
        val cx = w * (.5f + .38f * sin(t * b.fx + b.ph))
        val cy = h * (.5f + .32f * cos(t * b.fy + b.ph * 1.3f))
        drawRect(Brush.radialGradient(listOf(b.c.copy(alpha = .5f), Color.Transparent), center = Offset(cx, cy), radius = h * b.r))
    }
}

// ---------- Bintang ----------
private class Star(val x: Float, val y: Float, val r: Float, val ph: Float, val sp: Float)

private val stars = Random(7).let { rnd ->
    List(140) { Star(rnd.nextFloat(), rnd.nextFloat(), .6f + rnd.nextFloat() * 1.4f, rnd.nextFloat() * 6.28f, .6f + rnd.nextFloat() * 1.8f) }
}

private fun DrawScope.drawStars(t: Float) {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF02040C), Color(0xFF0B1B3A))))
    drawRect(Brush.radialGradient(listOf(Color(0x332B5BFF), Color.Transparent), center = Offset(w * .8f, h * .2f), radius = h * .9f))
    val u = size.minDimension / 380f
    stars.forEach { s ->
        val a = .3f + .7f * (.5f + .5f * sin(t * s.sp + s.ph))
        drawCircle(Color.White.copy(alpha = a), s.r * u, Offset(s.x * w, s.y * h))
    }
    // Bintang jatuh setiap 7 detik.
    val cyc = (t / 7f).toInt()
    val ph = (t % 7f) / 7f
    if (ph < .1f) {
        val p = ph / .1f
        val sx = w * (.15f + ((cyc * 37) % 50) / 100f)
        val sy = h * (.05f + ((cyc * 53) % 30) / 100f)
        val dx = w * .25f
        val dy = h * .3f
        val head = Offset(sx + dx * p, sy + dy * p)
        val tail = Offset(head.x - dx * .25f, head.y - dy * .25f)
        drawLine(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = 1f - p)), tail, head), tail, head, strokeWidth = 2f * u)
    }
}

// ---------- Gelombang ----------
private fun DrawScope.drawWaves(t: Float) {
    val w = size.width
    val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF0B3B6B), Color(0xFF041229))))
    for (i in 0 until 3) {
        val base = h * (.52f + .13f * i)
        val amp = h * (.05f - .01f * i)
        val freq = 1.4f + i * .7f
        val sp = (.55f + i * .25f) * (if (i % 2 == 0) 1f else -1f)
        val path = Path().apply {
            moveTo(0f, h)
            var x = 0f
            while (x <= w) {
                lineTo(x, base + amp * sin(x / w * 6.2832f * freq + t * sp + i * 1.7f))
                x += 8f
            }
            lineTo(w, h)
            close()
        }
        drawPath(path, Color(0xFF38BDF8).copy(alpha = .16f + .1f * i))
    }
}
