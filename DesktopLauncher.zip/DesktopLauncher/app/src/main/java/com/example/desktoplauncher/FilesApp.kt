package com.example.desktoplauncher

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.text.format.Formatter
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** File Manager ala Explorer: sidebar akses cepat, daftar berkas, salin/potong/tempel, ganti nama, hapus. */
@Composable
fun FilesApp() {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(FileOps.hasAccess(ctx)) }
    LaunchedEffect(granted) {
        while (!granted) { delay(1000); granted = FileOps.hasAccess(ctx) }
    }
    if (!granted) { NoAccess(); return }

    val root = remember { FileOps.root() }
    val places = remember { FileOps.places() }
    var cwd by remember { mutableStateOf(root) }
    var sel by remember { mutableStateOf<File?>(null) }
    var renaming by remember { mutableStateOf<File?>(null) }
    var confirm by remember { mutableStateOf(false) }
    var clip by remember { mutableStateOf<File?>(null) }
    var clipCut by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val items = remember(cwd, refresh) { FileOps.list(cwd) }

    LaunchedEffect(msg) { if (msg != null) { delay(2500); msg = null } }

    fun clearSel() { sel = null; renaming = null; confirm = false }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 480.dp
        Row(Modifier.fillMaxSize()) {
            Column(
                Modifier.width(if (compact) 48.dp else 130.dp).fillMaxHeight().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                places.forEach { (label, dir) ->
                    val on = cwd == dir
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                            .background(if (on) pal.text.copy(alpha = .08f) else Color.Transparent)
                            .clickable { cwd = dir; clearSel() }.padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Glyph("files", 22.dp)
                        if (!compact) Text(label, color = pal.text, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }

            Column(Modifier.weight(1f).fillMaxHeight().padding(start = 6.dp)) {
                // Toolbar
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val canUp = cwd != root
                    Box(
                        Modifier.size(34.dp).clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = canUp) { cwd = cwd.parentFile ?: cwd; clearSel() },
                        contentAlignment = Alignment.Center,
                    ) { Glyph("chevron", 18.dp, if (canUp) pal.text else pal.sub.copy(alpha = .4f)) }
                    val rel = cwd.absolutePath.removePrefix(root.absolutePath).trim('/')
                    val crumb = if (rel.isEmpty()) "Penyimpanan internal" else "Penyimpanan internal › " + rel.replace("/", " › ")
                    Text(
                        crumb, color = pal.text, fontSize = 13.sp, maxLines = 1,
                        modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                    )
                    if (clip != null) {
                        TextBtn("Tempel") {
                            val c = clip ?: return@TextBtn
                            val cut = clipCut
                            msg = "Memproses…"
                            scope.launch {
                                val ok = withContext(Dispatchers.IO) { FileOps.paste(c, cwd, cut) }
                                if (ok && cut) clip = null
                                msg = if (ok) "Selesai" else "Gagal menempel"
                                refresh += 1
                            }
                        }
                    }
                    TextBtn("＋ Folder") {
                        val f = FileOps.uniqueChild(cwd, "Folder baru")
                        if (f.mkdirs()) { refresh += 1; sel = f; renaming = f } else msg = "Gagal membuat folder"
                    }
                }

                // Aksi untuk item terpilih
                val s = sel
                if (s != null) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        TextBtn("Buka") { if (s.isDirectory) { cwd = s; clearSel() } else FileOps.open(ctx, s) }
                        TextBtn("Ganti nama") { renaming = s }
                        TextBtn("Salin") { clip = s; clipCut = false; msg = "Disalin: ${s.name}"; clearSel() }
                        TextBtn("Potong") { clip = s; clipCut = true; msg = "Dipotong: ${s.name}"; clearSel() }
                        TextBtn(if (confirm) "Yakin hapus?" else "Hapus") {
                            if (!confirm) confirm = true
                            else {
                                scope.launch {
                                    val ok = withContext(Dispatchers.IO) { runCatching { s.deleteRecursively() }.getOrDefault(false) }
                                    msg = if (ok) "Dihapus" else "Gagal menghapus"
                                    refresh += 1
                                }
                                clearSel()
                            }
                        }
                        TextBtn("Batal") { clearSel() }
                    }
                }
                if (msg != null) Text(msg ?: "", color = pal.accent, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp))

                if (items.isEmpty()) {
                    Text("Folder ini kosong", color = pal.sub, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(items, key = { it.absolutePath }) { f ->
                        FileRow(
                            f = f,
                            selected = sel == f,
                            renaming = renaming == f,
                            onTap = {
                                if (renaming == null) {
                                    if (f.isDirectory) { cwd = f; clearSel() } else FileOps.open(ctx, f)
                                }
                            },
                            onLong = { sel = f; renaming = null; confirm = false },
                            onRename = { name ->
                                val n = name?.trim().orEmpty()
                                if (n.isNotEmpty() && n != f.name && !n.contains('/')) {
                                    val dest = File(f.parentFile, n)
                                    if (dest.exists()) msg = "Nama sudah dipakai"
                                    else if (!f.renameTo(dest)) msg = "Gagal mengganti nama"
                                }
                                clearSel()
                                refresh += 1
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FileRow(
    f: File, selected: Boolean, renaming: Boolean,
    onTap: () -> Unit, onLong: () -> Unit, onRename: (String?) -> Unit,
) {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    val info = remember(f.absolutePath, f.lastModified()) {
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date(f.lastModified()))
        date + " · " + (if (f.isDirectory) "Folder" else Formatter.formatShortFileSize(ctx, f.length()))
    }
    val kind = when {
        f.isDirectory -> "files"
        FileOps.isImage(f) -> "image"
        else -> "doc"
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
            .background(if (selected) pal.accent.copy(alpha = .15f) else Color.Transparent)
            .pointerInput(f.absolutePath) { detectTapGestures(onTap = { onTap() }, onLongPress = { onLong() }) }
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Glyph(kind, 28.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            if (renaming) RenameField(f.name, onRename)
            else Text(f.name, color = pal.text, fontSize = 14.sp, maxLines = 1)
            Text(info, color = pal.sub, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun RenameField(initial: String, onDone: (String?) -> Unit) {
    val pal = LocalPalette.current
    var text by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, initial.length))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BasicTextField(
        value = text, onValueChange = { text = it }, singleLine = true,
        textStyle = TextStyle(color = pal.text, fontSize = 14.sp),
        cursorBrush = SolidColor(pal.accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone(text.text) }),
        modifier = Modifier.fillMaxWidth().focusRequester(focus)
            .background(pal.text.copy(alpha = .08f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp),
    )
}

@Composable
private fun TextBtn(label: String, onClick: () -> Unit) {
    val pal = LocalPalette.current
    val shape = RoundedCornerShape(6.dp)
    Text(
        label, color = pal.text, fontSize = 13.sp, maxLines = 1,
        modifier = Modifier.clip(shape).background(pal.text.copy(alpha = .08f))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 7.dp),
    )
}

@Composable
private fun NoAccess() {
    val pal = LocalPalette.current
    val ctx = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("File Manager", color = pal.text, fontSize = 18.sp)
        Text(
            "Izinkan akses ke semua file agar File Manager dapat menampilkan dan mengelola penyimpanan perangkat.",
            color = pal.sub, fontSize = 13.sp,
        )
        Button(
            onClick = {
                val uri = Uri.parse("package:" + ctx.packageName)
                val i = if (Build.VERSION.SDK_INT >= 30) Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)
                else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
                ctx.launch(i)
            },
            colors = ButtonDefaults.buttonColors(containerColor = pal.accent, contentColor = Color.Black),
        ) { Text("Izinkan akses") }
    }
}
