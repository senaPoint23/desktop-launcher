package com.example.desktoplauncher

import android.content.Context

/** Penyimpanan lokal sederhana: tema dan posisi ikon desktop. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("desktop", Context.MODE_PRIVATE)

    var theme: ThemeMode
        get() = runCatching { ThemeMode.valueOf(sp.getString("theme", "BLOOM")!!) }.getOrDefault(ThemeMode.BLOOM)
        set(v) { sp.edit().putString("theme", v.name).apply() }

    fun pos(id: String): Pair<Float, Float>? =
        if (sp.contains("$id.x")) sp.getFloat("$id.x", 0f) to sp.getFloat("$id.y", 0f) else null

    fun savePos(id: String, x: Float, y: Float) {
        sp.edit().putFloat("$id.x", x).putFloat("$id.y", y).apply()
    }

    var widget: Boolean
        get() = sp.getBoolean("widget", false)
        set(v) { sp.edit().putBoolean("widget", v).apply() }

    fun clearPos(ids: List<String>) {
        val e = sp.edit()
        ids.forEach { e.remove("$it.x").remove("$it.y") }
        e.apply()
    }

    var uiScale: Float
        get() = sp.getFloat("uiScale", 0.6f)
        set(v) { sp.edit().putFloat("uiScale", v).apply() }

    var orient: String
        get() = sp.getString("orient", "landscape") ?: "landscape"
        set(v) { sp.edit().putString("orient", v).apply() }

    var rotLock: Boolean
        get() = sp.getBoolean("rotLock", false)
        set(v) { sp.edit().putBoolean("rotLock", v).apply() }

    var hideNav: Boolean
        get() = sp.getBoolean("hideNav", false)
        set(v) { sp.edit().putBoolean("hideNav", v).apply() }

    var hideStatus: Boolean
        get() = sp.getBoolean("hideStatus", false)
        set(v) { sp.edit().putBoolean("hideStatus", v).apply() }

    var wallpaper: String
        get() = sp.getString("wallpaper", "BLOOM") ?: "BLOOM"
        set(v) { sp.edit().putString("wallpaper", v).apply() }

    var wallAnim: Boolean
        get() = sp.getBoolean("wallAnim", true)
        set(v) { sp.edit().putBoolean("wallAnim", v).apply() }

    var customWall: String
        get() = sp.getString("customWall", "") ?: ""
        set(v) { sp.edit().putString("customWall", v).apply() }

    var idleSec: Int
        get() = sp.getInt("idleSec", 90)
        set(v) { sp.edit().putInt("idleSec", v).apply() }

    var deskPins: List<String>
        get() = (sp.getString("deskPins", "") ?: "").split("\n").filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("deskPins", v.joinToString("\n")).apply() }

    var taskPins: List<String>
        get() = (sp.getString("taskPins", "") ?: "").split("\n").filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("taskPins", v.joinToString("\n")).apply() }

    var floatApps: Boolean
        get() = sp.getBoolean("floatApps", false)
        set(v) { sp.edit().putBoolean("floatApps", v).apply() }

    var iconModern: Boolean
        get() = sp.getBoolean("iconModern", true)
        set(v) { sp.edit().putBoolean("iconModern", v).apply() }

    var pack: String
        get() = sp.getString("pack", "") ?: ""
        set(v) { sp.edit().putString("pack", v).apply() }

    var welcomeSeen: Boolean
        get() = sp.getBoolean("welcomeSeen", false)
        set(v) { sp.edit().putBoolean("welcomeSeen", v).apply() }

    var shizukuWin: Boolean
        get() = sp.getBoolean("shizukuWin", false)
        set(v) { sp.edit().putBoolean("shizukuWin", v).apply() }
}
