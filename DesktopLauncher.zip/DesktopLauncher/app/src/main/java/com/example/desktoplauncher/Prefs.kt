package com.example.desktoplauncher

import android.content.Context

/** Penyimpanan lokal sederhana: tema dan posisi ikon desktop. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("desktop", Context.MODE_PRIVATE)

    var theme: ThemeMode
        get() = runCatching { ThemeMode.valueOf(sp.getString("theme", "DARK")!!) }.getOrDefault(ThemeMode.DARK)
        set(v) { sp.edit().putString("theme", v.name).apply() }

    fun pos(id: String): Pair<Float, Float>? =
        if (sp.contains("$id.x")) sp.getFloat("$id.x", 0f) to sp.getFloat("$id.y", 0f) else null

    fun savePos(id: String, x: Float, y: Float) {
        sp.edit().putFloat("$id.x", x).putFloat("$id.y", y).apply()
    }
}
