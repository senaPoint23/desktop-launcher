# Desktop Launcher (Fase 3: kerangka Kotlin + Jetpack Compose)

Launcher Android bergaya desktop. Kerangka ini memindahkan inti prototipe HTML ke Android asli.

## Cara menjalankan
1. Buka folder ini di Android Studio (Koala atau lebih baru, JDK 17).
2. Tunggu Gradle sync selesai.
3. Jalankan di perangkat atau emulator (minSdk 26).
4. Tekan Home, lalu pilih "Desktop" > "Selalu" untuk menjadikannya launcher default.
   Bisa juga lewat Settings > Pilih launcher default di dalam aplikasi.

Ganti `com.example.desktoplauncher` (namespace dan applicationId) sesuai milikmu.

## Sudah ada
- Home activity (kategori HOME), Back tidak keluar dari launcher
- Desktop: wallpaper gradient, ikon yang bisa digeser dan posisinya tersimpan
- Taskbar: Start, aplikasi berjalan (ketuk: fokus / minimize), jam, baterai
- Start Menu: pencarian, aplikasi internal + semua aplikasi terpasang (buka via PackageManager)
- Window Manager: geser, resize, minimize, maximize, close, fokus, animasi scale + fade
- 6 tema, default "Bloom" bergaya Windows 11 (taskbar tengah, kolom Cari, ikon vektor, window dengan tombol tutup merah)
- Landscape terkunci (sensorLandscape), ikon desktop mengisi kolom sesuai tinggi layar
- Animasi: ikon muncul bertahap, tekan ikon memantul, window open/close/minimize memakai spring

- Notification Center (butuh izin "Akses notifikasi"), Quick Settings (volume, kecerahan, pintasan Wi-Fi/Bluetooth/dll)
- Kalender (ketuk jam), widget jam, menu konteks desktop (tahan area kosong)
- Pengaturan ala Windows 11: Sistem > Tampilan (skala UI kustom, orientasi, kunci rotasi, sembunyikan navigasi, bilah status), Personalisasi, dll
- File Manager sungguhan (butuh izin "Akses semua file"): akses cepat, buka berkas, buat folder, ganti nama, salin/potong/tempel, hapus
- Wallpaper live: Bloom (bergerak pelan), Aurora, Bintang (berkelip + bintang jatuh), Gelombang; jeda otomatis saat window layar penuh
- Wallpaper saya: tambah video (MP4/WebM, diputar loop tanpa suara), GIF/WebP animasi, atau gambar dari HP lewat Pengaturan > Personalisasi
- Kunci layar otomatis (screensaver): tidak disentuh 90 detik (bisa diatur) -> lapisan hitam transparan di atas wallpaper live + jam besar; ketuk untuk membuka
- Panel Widget (tombol kiri taskbar): jam, baterai + suhu, penyimpanan, RAM
- Browser (WebView): banyak tab, kolom alamat + pencarian Google, maju/mundur/muat ulang/beranda, mode PC, unduhan
- Aplikasi terpasang: tahan di Start Menu untuk sematkan ke desktop/taskbar (ikon asli); dibuka sebagai jendela mengambang jika freeform diaktifkan di Opsi pengembang
- Snap window: seret ke tepi kiri/kanan = separuh layar, ke atas = layar penuh; klik ganda judul = maximize; strip kanan taskbar = tampilkan desktop
- Layar pemuatan saat masuk (logo, spinner, langkah, progres)
- Terminal (shell sh Android): perintah dasar, cd bertahan, riwayat, tombol Stop untuk memulai ulang

## Belum ada (urutan berikutnya)
- File Manager (Storage Access Framework)
- Daftar aplikasi otomatis refresh saat install/uninstall
- Terminal + Python (Fase 4)

Catatan: kode ini belum dikompilasi. Jika Gradle sync atau build menampilkan error, kirim pesannya dan akan diperbaiki.
