# Desktop Launcher (Fase 3: kerangka Kotlin + Jetpack Compose)

Launcher Android bergaya desktop. Kerangka ini memindahkan inti prototipe HTML ke Android asli.

## Cara menjalankan
1. Buka folder ini di Android Studio (Koala atau lebih baru, JDK 17).
2. Tunggu Gradle sync selesai.
3. Jalankan di perangkat atau emulator (minSdk 26).
4. Tekan Home, lalu pilih "Desktop" > "Selalu" untuk menjadikannya launcher default.
   Bisa juga lewat Settings > Pilih launcher default di dalam aplikasi.

Ganti `com.example.desktoplauncher` (namespace dan applicationId) sesuai milikmu.

## Sudah ada
- Home activity (kategori HOME), Back tidak keluar dari launcher
- Desktop: wallpaper gradient, ikon yang bisa digeser dan posisinya tersimpan
- Taskbar: Start, aplikasi berjalan (ketuk: fokus / minimize), jam, baterai
- Start Menu: pencarian, aplikasi internal + semua aplikasi terpasang (buka via PackageManager)
- Window Manager: geser, resize, minimize, maximize, close, fokus, animasi scale + fade
- 5 tema (palet dan wallpaper berpindah halus)
- Landscape terkunci (sensorLandscape), ikon desktop mengisi kolom sesuai tinggi layar
- Animasi: ikon muncul bertahap, tekan ikon memantul, window open/close/minimize memakai spring

- Notification Center (butuh izin "Akses notifikasi"), Quick Settings (volume, kecerahan, pintasan Wi-Fi/Bluetooth/dll)
- Kalender (ketuk jam), widget jam, menu konteks desktop (tahan area kosong)

## Belum ada (urutan berikutnya)
- File Manager (Storage Access Framework)
- Daftar aplikasi otomatis refresh saat install/uninstall
- Terminal + Python (Fase 4)

Catatan: kode ini belum dikompilasi. Jika Gradle sync atau build menampilkan error, kirim pesannya dan akan diperbaiki.
